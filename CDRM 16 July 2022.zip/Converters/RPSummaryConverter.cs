﻿class RPSummaryConverter : IValueConverter
{
    public object Convert(object value, Type targetType, object parameter, CultureInfo culture) {
        int payment, receipt;
        payment = receipt = 0;
        var items = (ReadOnlyObservableCollection<object>)value;
        foreach (SumReceiptPayment e in items) {
            payment += e.Payment;
            receipt += e.Receipt;
        }
        return new Tuple<int, int>(payment, receipt);
    }
    public object ConvertBack(object value, Type targetTypes, object parameter, CultureInfo culture) {
        throw new NotImplementedException();
    }
}
