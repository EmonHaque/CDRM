﻿class Converters
{
    public static HeadIdToNameConverter headId2Name = new();
    public static SiteIdToNameConverter siteId2Name = new();
    public static PartyIdToNameConverter partyId2Name = new();
    public static UnitIdToNameConverter unitId2Name = new();
    public static IsCashToIconConverter isCash2Icon = new();
    public static IsCashToFillConverter isCash2Fill = new();
    public static IsConstructionToIconConverter isContruction2Icon = new();
    public static GroupSummaryConverter groupSummary = new();
    public static RPSummaryConverter rpSummary = new();
    public static RPSecondarySumConverter rpSecondarySum = new();
}
