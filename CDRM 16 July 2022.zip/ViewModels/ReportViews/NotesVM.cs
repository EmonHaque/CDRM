﻿class NotesVM : Notifiable
{
}
