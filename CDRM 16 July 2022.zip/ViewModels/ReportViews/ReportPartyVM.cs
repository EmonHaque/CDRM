﻿class ReportPartyVM : Notifiable
{
    List<ReportEntry> reserved, reportables;
    int? id;
    public int? Id {
        get { return id; }
        set {
            if (id != value) {
                id = value;
                updateReportables();
                IsRefreshValid = value != null;
                OnPropertyChanged(nameof(IsRefreshValid));
            }
        }
    }
    string partyQuery;
    public string PartyQuery {
        get { return partyQuery; }
        set {
            if (partyQuery != value) {
                partyQuery = value;
                SelectionView.Refresh();
            }
        }
    }
    string reportrQuery;
    public string ReportQuery {
        get { return reportrQuery; }
        set { reportrQuery = value; Reportables.Refresh(); }
    }

    public string Header { get; set; }
    public ReportDates Dates { get; set; }
    public Tuple<int, int> Summary { get; set; }
    public Action RefreshReport { get; set; }
    public Action ExportCSV { get; set; }
    public Action PrintReport { get; set; }
    public bool IsRefreshValid { get; set; }
    public bool IsPrintOrExportValid { get; set; }
    public ICollectionView SelectionView { get; set; }
    public ICollectionView Reportables { get; set; }
    public string Title { get; set; }

    public ReportPartyVM() {
        Dates = new ReportDates();
        RefreshReport = refreshReport;
        ExportCSV = exportCSV;
        PrintReport = printReport;
        SelectionView = CollectionViewSource.GetDefaultView(AppData.parties);
        SelectionView.Filter = partyFilter;
    }
    
    bool partyFilter(object o) {
        if (string.IsNullOrWhiteSpace(PartyQuery)) return true;
        return ((IHaveName)o).Name.Contains(PartyQuery, StringComparison.InvariantCultureIgnoreCase);
    }
    bool reportFilter(object o) {
        if (string.IsNullOrWhiteSpace(ReportQuery)) return true;
        return ((ReportEntry)o).Particulars.Contains(ReportQuery, StringComparison.InvariantCultureIgnoreCase);
    }
    void refreshReport() {
        BusyWindow.Activate("Refreshing ...");
        if (reserved == null) {
            updateReportables();
            BusyWindow.Terminate();
            return;
        }
        else if (reserved.First().Date == Dates.From && reserved.Last().Date == Dates.To) {
            updateReportables();
            BusyWindow.Terminate();
            return;
        }
        
        int totalReceipt, totalPayment, balance;
        totalReceipt = totalPayment = balance = 0;
        var newReportables = new List<ReportEntry>();
        var lastEntry = reserved.LastOrDefault(x => x.Date < Dates.From);
        if (lastEntry != null) {
            balance = lastEntry.NetPayable;
            if(balance != 0) {
                newReportables.Add(new ReportEntry() {
                    Date = Dates.From,
                    NetPayable = balance,
                    Particulars = "balance b/d"
                });
            }
        }
        foreach (var e in reserved) {
            if (e.Date >= Dates.From && e.Date <= Dates.To) {
                newReportables.Add(e);
                totalReceipt += e.ReceivablePayment;
                totalPayment += e.PayableReceipt;
            }
        }
        reportables = newReportables;
        Reportables = CollectionViewSource.GetDefaultView(reportables);
        Reportables.Filter = reportFilter;
        Summary = new Tuple<int, int>(totalReceipt, totalPayment);

        OnPropertyChanged(nameof(Summary));
        OnPropertyChanged(nameof(Reportables));
        BusyWindow.Terminate();
    }
    void exportCSV() {
        var dialog = new SaveFileDialog() {
            FileName = "Report",
            Filter = "CSV files (.csv)|*.csv"
        };
        if (dialog.ShowDialog() != true) return;
        BusyWindow.Activate("Exporting ...");

        var builder = new StringBuilder();
        builder.Append("Date, Particulars, Receipt, Payment").AppendLine();
        foreach (var item in reportables) {
            builder
                .Append(item.Date.ToShortDateString()).Append(",")
                .Append("\"").Append(item.Particulars).Append("\"").Append(",")
                .Append(item.ReceivablePayment).Append(",")
                .Append(item.PayableReceipt).AppendLine();
        }
        System.IO.File.WriteAllText(System.IO.Path.GetFullPath(dialog.FileName), builder.ToString());
        BusyWindow.Terminate();
    }
    void printReport() {
        var dialog = new PrintDialog();
        if (dialog.ShowDialog() != true) return;
        BusyWindow.Activate("Printing ...");
        var size = new Size(dialog.PrintableAreaWidth, dialog.PrintableAreaHeight);
        var document = new FixedDocument();
        var pages = new List<LedgerPage>();
        var page = getPage(document, null);
        pages.Add(page);
        for (int i = 0; i < reportables.Count; i++) {
            if (!page.AddEntry(reportables[i])) {
                page.IsComplete = true;
                page.LastEntry = reportables[i - 1];
                page = getPage(document, page);
                page.AddEntry(reportables[i]);
                pages.Add(page);
            }
        }
        page.IsComplete = true;
        foreach (var p in pages) {
            p.NumberOfPage = document.Pages.Count;
        }
        document.DocumentPaginator.PageSize = size;
        dialog.PrintDocument(document.DocumentPaginator, "");
        BusyWindow.Terminate();
    }
    void updateReportables() {
        if (Id == null) {
            clearReportables();
            return;
        }
        int totalReceipt, totalPayment;
        totalReceipt = totalPayment = 0;
        reserved = new List<ReportEntry>();
        lock (SQL.key) {
            SQL.command.CommandText = $@"WITH t1(Date, Particulars, Receivable, Payable) AS(
                                        	SELECT Date, si.Name || ' - ' || he.Name || coalesce( ' - ' || sh.Name, '') || 
                                        		coalesce( ' - ' || Quantity, '') || coalesce( ' ' || un.Name, '') || 
                                        		coalesce( ' - ' || Narration, ''),
                                        		CASE WHEN IsSell = 1 THEN Amount ELSE 0 END,
                                        		CASE WHEN IsSell = 0 THEN Amount ELSE 0 END
                                        	FROM Dues t
                                        	LEFT JOIN Sites si ON t.SiteId = si.Id
                                        	LEFT JOIN Heads he ON t.HeadId = he.Id
                                        	LEFT JOIN SubHeads sh ON t.SubHeadId = sh.Id
                                        	LEFT JOIN Units un ON t.UnitId = un.Id
                                        	WHERE PartyId = {Id}
                                        ),
                                        t2(Date, Particulars, Receivable, Payable) AS(
                                        	SELECT Date, he.Name || ' - ' || 
                                        		CASE IsCash WHEN 0 THEN 'Cash' WHEN 1 THEN 'Mobile' WHEN 2 THEN 'Discount' END,
                                                CASE WHEN IsReceipt = 0 THEN Amount ELSE 0 END,
                                        		CASE WHEN IsReceipt = 1 THEN Amount ELSE 0 END
                                            FROM ReceiptPayments t
                                            LEFT JOIN Heads he ON t.HeadId = he.Id
                                            WHERE PartyId = {Id}
                                        ),
                                        t3 AS (SELECT * FROM t1 UNION ALL SELECT * FROM t2)
                                        SELECT * FROM t3 ORDER BY Date";
            var reader = SQL.command.ExecuteReader();
            int balance = 0;
            while (reader.Read()) {
                var e = new ReportEntry() {
                    Date = reader.GetDateTime(0),
                    Particulars = reader.GetString(1),
                    ReceivablePayment = reader.GetInt32(2),
                    PayableReceipt = reader.GetInt32(3)
                };
                balance += e.PayableReceipt;
                balance -= e.ReceivablePayment;
                e.NetPayable = balance;
                reserved.Add(e);
                totalReceipt += e.ReceivablePayment;
                totalPayment += e.PayableReceipt;
            }
            reader.Close();
            reader.DisposeAsync();
        }
        if (reserved.Count > 0) {
            reportables = reserved;
            Reportables = CollectionViewSource.GetDefaultView(reserved);
            Reportables.Filter = reportFilter;
            Dates.Start = Dates.From = reserved.First().Date;
            Dates.End = Dates.To = reserved.Last().Date;
            Header = $"available from {Dates.From.ToString("dd MMMM, yyyy")} to {Dates.To.ToString("dd MMMM, yyyy")}";
            Summary = new Tuple<int, int>(totalReceipt, totalPayment);
            IsPrintOrExportValid = true;

            OnPropertyChanged(nameof(Reportables));
            OnPropertyChanged(nameof(Dates));
            OnPropertyChanged(nameof(Header));
            OnPropertyChanged(nameof(Summary));
            OnPropertyChanged(nameof(IsPrintOrExportValid));
        }
        else clearReportables();

    }
    void clearReportables() {
        Dates.Start = Dates.End = Dates.From = Dates.To = DateTime.Today;
        Summary = new Tuple<int, int>(0, 0);
        Header = string.Empty;
        reserved = null;
        reportables = null;
        Reportables = null;
        IsRefreshValid = IsPrintOrExportValid = false;

        OnPropertyChanged(nameof(Reportables));
        OnPropertyChanged(nameof(Dates));
        OnPropertyChanged(nameof(Header));
        OnPropertyChanged(nameof(Summary));
        OnPropertyChanged(nameof(IsPrintOrExportValid));
        OnPropertyChanged(nameof(IsRefreshValid));
    }
    LedgerPage getPage(FixedDocument doc, LedgerPage previousPage) {
        LedgerPage page;
        if (previousPage == null) {
            page = new LedgerPage(doc.DocumentPaginator.PageSize) {
                Title = AppData.parties.First(x => x.Id == Id).Name,
                Period = $"period from {Dates.From.ToString("dd MMMM, yyyy")} to {Dates.To.ToString("dd MMMM, yyyy")}",
                FootNote = $"Generated on {DateTime.Now.ToString("dd MMMM, yyyy | hh:mm:ss tt")}",
            };
        }
        else page = new LedgerPage(previousPage);
        doc.Pages.Add(new PageContent() { Child = page.Page });
        return page;
    }
}
