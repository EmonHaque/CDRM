﻿class EditHeadVM : EditBaseVM<Head>
{
    protected override CollectionViewSource cvs => new CollectionViewSource() {
        Source = AppData.heads,
        IsLiveSortingRequested = true,
        LiveSortingProperties = { nameof(IHaveName.Name) }
    };
    public EditHeadVM() {
        Edited = new Head();
    }
    protected override void insert() {
        lock (SQL.key) {
            SQL.command.CommandText = $"UPDATE Heads SET Name = @Name WHERE Id = {Selected.Id}";
            SQL.command.Parameters.AddWithValue("@Name", Edited.Name);
            SQL.command.ExecuteNonQuery();
            SQL.command.Parameters.Clear();
        }
        Selected.Name = Edited.Name;
        Selected.OnPropertyChanged(nameof(Head.Name));
    }
}
