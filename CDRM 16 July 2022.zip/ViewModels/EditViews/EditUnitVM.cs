﻿class EditUnitVM : EditBaseVM<Unit>
{
    protected override CollectionViewSource cvs => new CollectionViewSource() {
        Source = AppData.units,
        IsLiveSortingRequested = true,
        LiveSortingProperties = { nameof(IHaveName.Name) }
    };
    public EditUnitVM() : base() {
        Edited = new Unit();
    }
    protected override void insert() {
        lock (SQL.key) {
            SQL.command.CommandText = $"UPDATE Units SET Name = @Name WHERE Id = {Selected.Id}";
            SQL.command.Parameters.AddWithValue("@Name", Edited.Name);
            SQL.command.ExecuteNonQuery();
            SQL.command.Parameters.Clear();
        }
        Selected.Name = Edited.Name;
        Selected.OnPropertyChanged(nameof(Unit.Name));
    }

}

