﻿class EntryNoteVM : Notifiable
{
    public EntryNoteVM() {

    }
}
