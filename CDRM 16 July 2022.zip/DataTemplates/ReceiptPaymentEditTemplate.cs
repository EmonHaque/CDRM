﻿class ReceiptPaymentEditTemplate : DataTemplate
{
    public ReceiptPaymentEditTemplate() {
        var grid = new FrameworkElementFactory(typeof(Grid));
        var col1 = new FrameworkElementFactory(typeof(ColumnDefinition));
        var col2 = new FrameworkElementFactory(typeof(ColumnDefinition));
        var col3 = new FrameworkElementFactory(typeof(ColumnDefinition));
        var icon = new FrameworkElementFactory(typeof(PathIcon));
        var party = new FrameworkElementFactory(typeof(TextBlock));
        var amount = new FrameworkElementFactory(typeof(TextBlock));

        col2.SetValue(ColumnDefinition.WidthProperty, new GridLength(Constants.AmountColumnWidth));
        col3.SetValue(ColumnDefinition.WidthProperty, GridLength.Auto);

        icon.SetValue(PathIcon.MarginProperty, new Thickness(5, 0, 0, 0));
        amount.SetValue(TextBlock.HorizontalAlignmentProperty, HorizontalAlignment.Right);


        icon.SetBinding(PathIcon.IconProperty, new Binding(nameof(EntryReceiptPaymentText.IsCash)) {
            Converter = Converters.isCash2Icon
        });
        party.SetBinding(TextBlock.TextProperty, new Binding(nameof(EntryReceiptPaymentText.Party)));
        amount.SetBinding(TextBlock.TextProperty, new Binding(nameof(EntryReceiptPaymentText.Amount)));
        icon.SetValue(Grid.ColumnProperty, 2);
        amount.SetValue(Grid.ColumnProperty, 1);

        grid.AppendChild(col1);
        grid.AppendChild(col2);
        grid.AppendChild(col3);
        grid.AppendChild(icon);
        grid.AppendChild(party);
        grid.AppendChild(amount);

        VisualTree = grid;
    }
}
