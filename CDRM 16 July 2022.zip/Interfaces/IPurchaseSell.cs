﻿interface IPurchaseSell
{
    string GroupName { get; set; }
    int Purchase { get; set; }
    int Sell { get; set; }
}
