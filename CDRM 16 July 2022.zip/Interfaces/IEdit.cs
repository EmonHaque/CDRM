﻿interface IEdit<T>
{
    T Selected { get; set; }
    string Query { get; set; }
    ICollectionView Editables { get; set; }
}
