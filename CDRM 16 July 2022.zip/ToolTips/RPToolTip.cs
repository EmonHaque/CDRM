﻿class RPToolTip : ToolTip
{
    public RPToolTip() {
        var date = new TextBlock() { Text = "Particulars" };
        var payment = new TextBlock() { Text = "Payment", HorizontalAlignment = HorizontalAlignment.Right };
        var receipt = new TextBlock() { Text = "Receipt", HorizontalAlignment = HorizontalAlignment.Right };
        var separator = new Separator() { Height = Constants.BottomLineThickness };
        
        Grid.SetColumn(payment, 1);
        Grid.SetColumn(receipt, 2);
        Grid.SetRow(separator, 1);
        Grid.SetColumnSpan(separator, 3);
        var header = new Grid() {
            ColumnDefinitions = {
                new ColumnDefinition(),
                new ColumnDefinition(){Width = new GridLength(Constants.AmountColumnWidth)},
                new ColumnDefinition(){Width = new GridLength(Constants.AmountColumnWidth)},
            },
            RowDefinitions = {
                new RowDefinition(){Height = GridLength.Auto},
                new RowDefinition(){Height = GridLength.Auto}
            },
            Children = { date, payment, receipt, separator },
            Resources = {
                {
                    typeof(TextBlock),
                    new Style(typeof(TextBlock)) {
                        Setters = {
                            new Setter(TextBlock.ForegroundProperty, Brushes.LightGray)
                        }
                    }
                }
            }
        };

        var box = new ItemsControl() { 
            ItemTemplate = new RPToolTipTemplate(),
            AlternationCount = 2
        };
        box.SetBinding(ItemsControl.ItemsSourceProperty, new Binding(nameof(SumReceiptPayment.Entries)));
        Grid.SetRow(box, 1);
        Content = new Grid() {
            RowDefinitions = {
                new RowDefinition(){Height = GridLength.Auto},
                new RowDefinition(),
            },
            Children = { header, box }
        };
    }
}
