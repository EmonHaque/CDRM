﻿enum TransactionType
{
    Purchase,
    Sell,
    Payment,
    Receipt
}
