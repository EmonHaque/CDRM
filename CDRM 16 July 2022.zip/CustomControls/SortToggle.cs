﻿class SortToggle : Grid
{
    TextBlock block;
    Path icon;
    string text;
    public string Text {
        get { return text; }
        set { text = block.Text = value; }
    }
    public string Icon { get; set; }
    public bool IsRightAligned { get; set; }
    public Action Command { get; set; }

    public SortToggle() {
        Background = Brushes.Transparent;
        IsRightAligned = false;
        ColumnDefinitions.Add(new ColumnDefinition());
        ColumnDefinitions.Add(new ColumnDefinition());
        icon = new Path() {
            Width = 12,
            Height = 12,
            Stretch = Stretch.Uniform,
            Fill = Brushes.LightGray,
            Margin = new Thickness(0,0,5,0)
        };
        block = new TextBlock();
        SetColumn(block, 1);
        Children.Add(icon);
        Children.Add(block);
        Loaded += onLoaded;
        Unloaded += onUnloaded;
    }

    void onLoaded(object sender, RoutedEventArgs e) {
        if (IsRightAligned) {
            ColumnDefinitions[1].Width = GridLength.Auto;
            icon.HorizontalAlignment = HorizontalAlignment.Right;
        }
        else ColumnDefinitions[0].Width = GridLength.Auto;

        block.Text = string.IsNullOrWhiteSpace(Text) ? "" : Text;
        if (!string.IsNullOrWhiteSpace(Icon)) {
            icon.Data = Geometry.Parse(Icon);
        }
    }
    void onUnloaded(object sender, RoutedEventArgs e) {
        Loaded -= onLoaded;
        Unloaded -= onUnloaded;
    }

    protected override void OnMouseEnter(MouseEventArgs e) {
        icon.Fill = Brushes.CornflowerBlue;
        block.Foreground = Brushes.White;
    }
    protected override void OnMouseLeave(MouseEventArgs e) {
        icon.Fill = Brushes.LightGray;
        block.Foreground = Brushes.LightGray;
    }
    protected override void OnPreviewMouseLeftButtonUp(MouseButtonEventArgs e) => Command?.Invoke();
}
