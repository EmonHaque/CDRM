﻿class MultiState : Grid
{
    Path icon;
    TextBlock block;
    SolidColorBrush brush;
    Color normalColor, highlightColor, downColor;
    ColorAnimation anim;
    int maxState;

    public string[] Tips { get; set; }
    public bool IsIconInfront { get; set; }
    public MultiState() {
        Focusable = true;
        normalColor = Colors.LightGray;
        highlightColor = Colors.Coral;
        downColor = Colors.LightGreen;
        brush = new SolidColorBrush(normalColor);
        block = new TextBlock() { VerticalAlignment = VerticalAlignment.Center };
        icon = new Path() {
            Height = 12,
            Width = 12,
            Stretch = Stretch.Uniform,
            Fill = brush,
            VerticalAlignment = VerticalAlignment.Center,
            Margin = new Thickness(5, 0, 0, 0)
        };
        SetColumn(icon, 1);
        Background = Brushes.Transparent;
        ColumnDefinitions.Add(new ColumnDefinition() { Width = GridLength.Auto });
        ColumnDefinitions.Add(new ColumnDefinition() { Width = GridLength.Auto });
        Children.Add(block);
        Children.Add(icon);

        anim = new ColorAnimation() {
            Duration = TimeSpan.FromMilliseconds(250),
            EasingFunction = new CubicEase() { EasingMode = EasingMode.EaseInOut }
        };
        Loaded += onLoaded;
        Unloaded += onUnloaded;
    }
    void onUnloaded(object sender, RoutedEventArgs e) {
        Loaded -= onLoaded;
        Unloaded -= onUnloaded;
    }
    void onLoaded(object sender, RoutedEventArgs e) {
        if (Icons is not null) {
            icon.Data = Geometry.Parse(Icons[0]);
            maxState = Icons.Length - 1;
        }
        if (Tips is not null) ToolTip = Tips[0];
        if (Texts is not null) block.Text = Texts[0];
        if (IsIconInfront) {
            icon.Margin = new Thickness(0, 0, 5, 0);
            Grid.SetColumn(icon, 0);
            Grid.SetColumn(block, 1);
        }
    }
    void animateBrush(Color c) {
        anim.To = c;
        brush.BeginAnimation(SolidColorBrush.ColorProperty, anim);
    }
    void resetState() {
        if (State == maxState) State = 0;
        else State++;
    }
    protected override void OnMouseEnter(MouseEventArgs e) => animateBrush(highlightColor);
    protected override void OnMouseLeave(MouseEventArgs e) => animateBrush(normalColor);
    protected override void OnMouseDown(MouseButtonEventArgs e) => animateBrush(downColor);
    protected override void OnPreviewGotKeyboardFocus(KeyboardFocusChangedEventArgs e) => animateBrush(highlightColor);
    protected override void OnPreviewLostKeyboardFocus(KeyboardFocusChangedEventArgs e) => animateBrush(normalColor);
    protected override void OnMouseLeftButtonUp(MouseButtonEventArgs e) => resetState();
    protected override void OnKeyUp(KeyEventArgs e) {
        if (e.Key != Key.Space) return;
        resetState();
    }

    #region DependencyProperties
    public int State {
        get { return (int)GetValue(StateProperty); }
        set { SetValue(StateProperty, value); }
    }
    public string[] Texts {
        get { return (string[])GetValue(TextsProperty); }
        set { SetValue(TextsProperty, value); }
    }

    public string[] Icons {
        get { return (string[])GetValue(IconsProperty); }
        set { SetValue(IconsProperty, value); }
    }

    public static readonly DependencyProperty StateProperty =
        DependencyProperty.Register("State", typeof(int), typeof(MultiState), new FrameworkPropertyMetadata() {
            DefaultValue = 0,
            BindsTwoWayByDefault = true,
            PropertyChangedCallback = onStateChanged
        });

    public static readonly DependencyProperty TextsProperty =
    DependencyProperty.Register("Texts", typeof(string[]), typeof(MultiState), new FrameworkPropertyMetadata() {
        DefaultValue = null,
        BindsTwoWayByDefault = true,
        PropertyChangedCallback = onTextsChanged
    });

    public static readonly DependencyProperty IconsProperty =
        DependencyProperty.Register("Icons", typeof(string[]), typeof(MultiState), new FrameworkPropertyMetadata() {
            DefaultValue = null,
            BindsTwoWayByDefault = true,
            PropertyChangedCallback = onStateChanged
        });

    static void onStateChanged(DependencyObject d, DependencyPropertyChangedEventArgs e) {
        var o = (MultiState)d;
        o.icon.Data = Geometry.Parse(o.Icons[o.State]);
        if (o.Tips is not null) o.ToolTip = o.Tips[o.State];
        if (o.Texts is not null) o.block.Text = o.Texts[o.State];
    }

    static void onTextsChanged(DependencyObject d, DependencyPropertyChangedEventArgs e) {
        var o = (MultiState)d;
        if (o.Tips is not null) o.ToolTip = o.Tips[o.State];
        o.block.Text = o.Texts[o.State];
    }
    #endregion
}
