﻿class AppData
{
    static Site theSite;
    static Party theParty;
    static Head theHead;
    static SubHead theSubHead;
    static Unit theUnit;
    static int maxSiteId, maxPartyId, maxHeadId, maxSubHeadId, maxUnitId;

    public static ObservableCollection<Site> sites = new();
    public static ObservableCollection<Party> parties = new();
    public static ObservableCollection<Head> heads = new();
    public static ObservableCollection<SubHead> subHeads = new();
    public static ObservableCollection<Unit> units = new();

    public AppData() => checkDatabase();

    void checkDatabase() {
        bool isInitialized = false;
        if (!System.IO.File.Exists(Constants.DBName)) {
            createDatabase();
            isInitialized = true;
        }
        if (!isInitialized) SQL.Initialize();
        populateCollections();
    }
    void createDatabase() {
        using var stream = Assembly.GetExecutingAssembly().GetManifestResourceStream("CDRM.Resources.dBase.sql");
        using var sReader = new System.IO.StreamReader(stream);

        SQL.Initialize();
        SQL.command.CommandText = sReader.ReadToEnd();
        SQL.command.ExecuteNonQuery();

        stream.Close();
        sReader.Close();
        stream.Dispose();
        sReader.Dispose();
    }
    void populateCollections() {
        SQL.command.CommandText = @"SELECT * FROM Sites;
                                    SELECT * FROM Heads;
                                    SELECT * FROM SubHeads;
                                    SELECT * FROM Parties;
                                    SELECT * FROM Units;";
        var reader = SQL.command.ExecuteReader();
        while (reader.Read()) {
            sites.Add(new Site() {
                Id = reader.GetInt32(0),
                Name = reader.GetString(1),
                Address = reader.GetString(2)
            });
        }
        reader.NextResult();
        while (reader.Read()) {
            heads.Add(new Head() {
                Id = reader.GetInt32(0),
                Name = reader.GetString(1)
            });
        }
        reader.NextResult();
        while (reader.Read()) {
            subHeads.Add(new SubHead() {
                Id = reader.GetInt32(0),
                Name = reader.GetString(1)
            });
        }
        reader.NextResult();
        while (reader.Read()) {
            parties.Add(new Party() {
                Id = reader.GetInt32(0),
                Name = reader.GetString(1),
                Address = reader.IsDBNull(2) ? "" : reader.GetString(2),
                Phone = reader.IsDBNull(3) ? "" : reader.GetString(3)
            });
        }
        reader.NextResult();
        while (reader.Read()) {
            units.Add(new Unit() {
                Id = reader.GetInt32(0),
                Name = reader.GetString(1)
            });
        }
        reader.Close();
        reader.DisposeAsync();

        maxHeadId = heads.Count == 0 ? 0 : heads.Max(x => x.Id);
        maxUnitId = units.Count == 0 ? 0 : units.Max(x => x.Id);
        maxSiteId = sites.Count == 0 ? 0 : sites.Count == 0 ? 0 : sites.Max(x => x.Id);
        maxPartyId = parties.Count == 0 ? 0 : parties.Max(x => x.Id);
        maxSubHeadId = subHeads.Count == 0 ? 0 : subHeads.Max(x => x.Id);
    }

    public static bool HasSite(string name) {
        theSite = sites.FirstOrDefault(x => x.Name.Equals(name.Trim(), StringComparison.InvariantCultureIgnoreCase));
        return theSite is not null;
    }
    public static bool HasParty(string name) {
        theParty = parties.FirstOrDefault(x => x.Name.Equals(name.Trim(), StringComparison.InvariantCultureIgnoreCase));
        return theParty is not null;
    }
    public static bool HasHead(string name) {
        theHead = heads.FirstOrDefault(x => x.Name.Equals(name.Trim(), StringComparison.InvariantCultureIgnoreCase));
        return theHead is not null;
    }
    public static bool HasSubHead(string name) {
        theSubHead = subHeads.FirstOrDefault(x => x.Name.Equals(name.Trim(), StringComparison.InvariantCultureIgnoreCase));
        return theSubHead is not null;
    }
    public static bool HasUnit(string name) {
        theUnit = units.FirstOrDefault(x => x.Name.Equals(name.Trim(), StringComparison.InvariantCultureIgnoreCase));
        return theUnit is not null;
    }

    public static void InsertSite(Site o) {
        lock (SQL.key) {
            SQL.command.CommandText = "INSERT INTO Sites(Name, Address) VALUES(@Name, @Address)";
            SQL.command.Parameters.AddWithValue("@Name", o.Name);
            SQL.command.Parameters.AddWithValue("@Address", o.Address);
            SQL.command.ExecuteNonQuery();
            SQL.command.Parameters.Clear();
        }
        o.Id = ++maxSiteId;
        sites.Add(o);
        theSite = o;
    }
    public static void InsertParty(Party o) {
        object address = string.IsNullOrWhiteSpace(o.Address) ? DBNull.Value : o.Address;
        object phone = string.IsNullOrWhiteSpace(o.Phone) ? DBNull.Value : o.Phone;
        lock (SQL.key) {
            SQL.command.CommandText = "INSERT INTO Parties(Name, Address, Phone) VALUES(@Name, @Address, @Phone)";
            SQL.command.Parameters.AddWithValue("@Name", o.Name);
            SQL.command.Parameters.AddWithValue("@Address", address);
            SQL.command.Parameters.AddWithValue("@Phone", phone);
            SQL.command.ExecuteNonQuery();
            SQL.command.Parameters.Clear();
        }
        o.Id = ++maxPartyId;
        parties.Add(o);
        theParty = o;
    }
    public static void InsertHead(string name) {
        lock (SQL.key) {
            SQL.command.CommandText = "INSERT INTO Heads(Name) VALUES(@Name)";
            SQL.command.Parameters.AddWithValue("@Name", name);
            SQL.command.ExecuteNonQuery();
            SQL.command.Parameters.Clear();
        }
        var head = new Head() {
            Id = ++maxHeadId,
            Name = name
        };
        heads.Add(head);
        theHead = head;
    }
    public static void InsertSubHead(string name) {
        lock (SQL.key) {
            SQL.command.CommandText = "INSERT INTO SubHeads(Name) VALUES(@Name)";
            SQL.command.Parameters.AddWithValue("@Name", name);
            SQL.command.ExecuteNonQuery();
            SQL.command.Parameters.Clear();
        }
        var subHead = new SubHead() {
            Id = ++maxSubHeadId,
            Name = name
        };
        subHeads.Add(subHead);
        theSubHead = subHead;
    }
    public static void InsertUnit(string name) {
        lock (SQL.key) {
            SQL.command.CommandText = "INSERT INTO Units(Name) VALUES(@Name)";
            SQL.command.Parameters.AddWithValue("@Name", name);
            SQL.command.ExecuteNonQuery();
            SQL.command.Parameters.Clear();
        }
        var unit = new Unit() {
            Id = ++maxUnitId,
            Name = name
        };
        units.Add(unit);
        theUnit = unit;
    }
    public static void UpdateReceiptPayment(EntryReceiptPayment e) {
        object narration = string.IsNullOrWhiteSpace(e.Narration) ? DBNull.Value : e.Narration;
        lock (SQL.key) {
            SQL.command.CommandText = $@"UPDATE ReceiptPayments SET Date = @Date, Amount = {e.Amount}, PartyId = {e.PartyId},
                                        HeadId = {e.HeadId}, IsReceipt = {e.IsReceipt}, IsCash = {e.IsCash}, Narration = @Narration
                                        WHERE Id = @Id";
            SQL.command.Parameters.AddWithValue(@"Date", e.Date);
            SQL.command.Parameters.AddWithValue(@"Narration", narration);
            SQL.command.Parameters.AddWithValue(@"Id", e.Id);
            SQL.command.ExecuteNonQuery();
            SQL.command.Parameters.Clear();
        }
    }
    public static void UpdatePurchaseSell(EntryPurchaseSell e) {
        object subHead = e.SubHeadId > 0 ? e.SubHeadId : DBNull.Value;
        object unit = e.UnitId > 0 ? e.UnitId : DBNull.Value;
        object quantity = e.Quantity > 0 ? e.Quantity : DBNull.Value;
        object narration = string.IsNullOrWhiteSpace(e.Narration) ? DBNull.Value : e.Narration;
        lock (SQL.key) {
            SQL.command.CommandText = $@"UPDATE Dues SET Date = @Date, Amount = {e.Amount}, IsSell = {e.IsSell}, 
                                        IsConstruction = {e.IsConstruction}, SiteId = {e.SiteId}, PartyId = {e.PartyId}, 
                                        HeadId = {e.HeadId}, SubHeadId = @SubHead, UnitId = @Unit, Quantity = @Quantity, 
                                        Narration = @Narration WHERE Id = @Id";
            SQL.command.Parameters.AddWithValue(@"Date", e.Date);
            SQL.command.Parameters.AddWithValue(@"SubHead", subHead);
            SQL.command.Parameters.AddWithValue(@"Unit", unit);
            SQL.command.Parameters.AddWithValue(@"Quantity", quantity);
            SQL.command.Parameters.AddWithValue(@"Narration", narration);
            SQL.command.Parameters.AddWithValue(@"Id", e.Id);
            SQL.command.ExecuteNonQuery();
            SQL.command.Parameters.Clear();
        }
    }
    public static void DeleteReceiptPayment(int id) {
        lock (SQL.key) {
            SQL.command.CommandText = $"DELETE From ReceiptPayments WHERE Id = {id}";
            SQL.command.ExecuteNonQuery();
        }
    }
    public static void DeletePurchaseSell(int id) {
        lock (SQL.key) {
            SQL.command.CommandText = $"DELETE From Dues WHERE Id = {id}";
            SQL.command.ExecuteNonQuery();
        }
    }
    public static Site GetSite() => theSite;
    public static Party GetParty() => theParty;
    public static Head GetHead() => theHead;
    public static SubHead GetSubHead() => theSubHead;
    public static Unit GetUnit() => theUnit;
}
