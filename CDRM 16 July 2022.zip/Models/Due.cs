﻿class Due
{
    public DateTime Date { get; set; }
    public string Site { get; set; }
    public string Party { get; set; }
    public string Head { get; set; }
    public string SubHead { get; set; }
    public double Quantity { get; set; }
    public string Unit { get; set; }
    public string Narration { get; set; }
    public byte IsSell { get; set; }
    public byte IsConstruction { get; set; }
    public int Purchase { get; set; }
    public int Sell { get; set; }
}
