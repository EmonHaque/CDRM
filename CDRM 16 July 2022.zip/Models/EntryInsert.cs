﻿class EntryInsert
{
    public int Id { get; set; }
    public string Date { get; set; }
    public int Amount { get; set; }
    public byte IsCash { get; set; }
    public byte IsSell { get; set; }
    public byte IsConstruction { get; set; }
    public byte IsReceipt { get; set; }
    public int SiteId { get; set; }
    public int PartyId { get; set; }
    public int HeadId { get; set; }
    public int SubHeadId { get; set; }
    public int UnitId { get; set; }
    public double Quantity { get; set; }
    public string Narration { get; set; }
    public bool IsTopLevel { get; set; }
    public List<EntryReceiptPayment> ReceiptPayments { get; set; }
    public EntryInsert() {
        ReceiptPayments = new();
    }
}
