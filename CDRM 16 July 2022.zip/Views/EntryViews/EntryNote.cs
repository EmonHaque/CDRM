﻿class EntryNote : CardView
{
    public override string Header => "Notes";
    public override string Icon => Icons.NoteBookPlus;
}
