﻿class EditParty : EditBase<Party>
{
    public override string Header => "Party";
    public override string Icon => Icons.Tenant;

    EditPartyVM vm = new();
    EditPartyControl party = new();
    protected override IEdit<Party> viewModel => vm;

    protected override FrameworkElement editElement => party;

    protected override void bind() {
        base.bind();
        party.SetBinding(EditPartyControl.NameProperty, new Binding($"{nameof(vm.Selected)}.{nameof(Party.Name)}"));
        party.SetBinding(EditPartyControl.EditedNameProperty, new Binding($"{nameof(vm.Edited)}.{nameof(Party.Name)}"));
        party.SetBinding(EditPartyControl.AddressProperty, new Binding($"{nameof(vm.Selected)}.{nameof(Party.Address)}"));
        party.SetBinding(EditPartyControl.EditedAddressProperty, new Binding($"{nameof(vm.Edited)}.{nameof(Party.Address)}"));
        party.SetBinding(EditPartyControl.PhoneProperty, new Binding($"{nameof(vm.Selected)}.{nameof(Party.Phone)}"));
        party.SetBinding(EditPartyControl.EditedPhoneProperty, new Binding($"{nameof(vm.Edited)}.{nameof(Party.Phone)}"));
        party.SetBinding(EditPartyControl.IsOnEditProperty, new Binding(nameof(vm.IsOnEdit)));
    }
}
