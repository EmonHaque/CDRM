﻿class AllSitewisePurchase : AllPurchaseBase
{
    public override string Icon => Icons.Plot;
    //public override string Header => "Site";
    protected override string searchHint => "Site";
    AllSitewisePurchaseVM viewModel = new();
    protected override AllPurchaseBaseVM vm => viewModel;

}
