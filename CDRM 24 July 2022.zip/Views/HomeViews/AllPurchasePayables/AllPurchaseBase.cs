﻿abstract class AllPurchaseBase : CardView
{
    DayPicker from, to;
    EditText search;
    ActionButton sortPurchase, refresh;
    protected Grid secondRow;
    FrameworkElement chart;
    protected abstract string searchHint { get; }
    protected abstract AllPurchaseBaseVM vm { get; }

    public AllPurchaseBase() {
        DataContext = vm;
        initializeUI();
        bind();
    }

    void initializeUI() {
        #region First Row
        from = new DayPicker() {
            DateFormat = "dd/MM/yyyy",
            Hint = "from"
        };
        to = new DayPicker() {
            DateFormat = "dd/MM/yyyy",
            Hint = "to"
        };
        refresh = new ActionButton() {
            Margin = new Thickness(5, 0, 0, 0),
            Icon = Icons.Refresh,
            Command = vm.Refresh,
            VerticalAlignment = VerticalAlignment.Center
        };
        Grid.SetColumn(to, 1);
        Grid.SetColumn(refresh, 2);
        var firstRow = new Grid() {
            Margin = new Thickness(0, 5, 0, 0),
            ColumnDefinitions = {
                new ColumnDefinition(),
                new ColumnDefinition(),
                new ColumnDefinition(){Width = GridLength.Auto }
            },
            Children = { from, to, refresh }
        };
        #endregion

        #region Second Row
        search = new EditText() {
            Icon = Icons.Search,
            Hint = searchHint,
            IsTrimBottomRequested = true
        };
        sortPurchase = new ActionButton() {
            ToolTip = "Purchase",
            Margin = new Thickness(5, 0, 0, 0),
            Icon = Icons.SortSwap,
            Command = vm.SortPurchase,
            VerticalAlignment = VerticalAlignment.Center
        };

        Grid.SetColumn(sortPurchase, 1);
        secondRow = new Grid() {
            ColumnDefinitions = {
                new ColumnDefinition(),
                new ColumnDefinition(){Width = GridLength.Auto}
            },
            Children = { search, sortPurchase }
        };
        #endregion

        if (vm is AllPartyTransactionVM) {
            chart = new HorizontalPinLineBarChart() { Margin = new Thickness(5, 0, 5, 0) };
        }
        else {
            chart = new HorizontalBarChart() { Margin = new Thickness(5, 0, 5, 0) };
        }
        Grid.SetRow(secondRow, 1);
        Grid.SetRow(chart, 2);
        var grid = new Grid() {
            RowDefinitions = {
                new RowDefinition(){Height = GridLength.Auto},
                new RowDefinition(){Height = GridLength.Auto},
                new RowDefinition()
            },
            Children = { firstRow, secondRow, chart }
        };
        setContent(grid);
    }
    void bind() {
        DependencyProperty property = null;
        if (vm is AllPartyTransactionVM) {
            var pvm = (AllPartyTransactionVM)vm;
            chart.SetBinding(HorizontalPinLineBarChart.ItemsSourceProperty, new Binding(nameof(vm.Data)));
            chart.SetBinding(HorizontalPinLineBarChart.SelectedProperty, new Binding(nameof(vm.Selected)) { Mode = BindingMode.OneWayToSource});
        }
        else {
            chart.SetBinding(HorizontalBarChart.ItemsSourceProperty, new Binding(nameof(vm.Data)));
            chart.SetBinding(HorizontalBarChart.SelectedProperty, new Binding(nameof(vm.Selected)) { Mode = BindingMode.OneWayToSource });
        }
        from.SetBinding(DayPicker.SelectedDateProperty, new Binding($"{nameof(vm.Dates)}.{nameof(ReportDates.From)}"));
        to.SetBinding(DayPicker.SelectedDateProperty, new Binding($"{nameof(vm.Dates)}.{nameof(ReportDates.To)}"));
        search.SetBinding(EditText.TextProperty, new Binding(nameof(vm.Query)) { Mode = BindingMode.OneWayToSource });
    }
}
