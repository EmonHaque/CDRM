﻿class SingleSitewisePurchase : SinglePurchasePayables<Site>
{
    public override string Icon => Icons.Plot;
    SingleSitewisePurchaseVM viewModel = new();
    PinChart pin = new();
    protected override SinglePurchasePayableBaseVM<Site> vm => viewModel;
    protected override string hint => "Site";
}
