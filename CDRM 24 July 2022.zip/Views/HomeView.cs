﻿class HomeView : View
{
    public override string Icon => Icons.Home;
    public override FrameworkElement container => grid;
    Grid grid;
    public HomeView() {

        var singlePurchase = new ViewContainer(NavPosition.TopRightVertical, NavOverlap.Right) {
            IconSize = 12,
            IconGap = 5,
            Children = {
                new SingleSitewisePurchase(),
                new SingleHeadwisePurchase(),
                new SinglePartyTransaction()
            }
        };
        var purchasePayments = new ViewContainer(NavPosition.BottomRightVertical, NavOverlap.Right) {
            IconSize = 12,
            IconGap = 5,
            Children = {
                new AllPayment(),
                new AllSite()
            }
        };
        var allPurchase = new ViewContainer(NavPosition.LeftCenter, NavOverlap.Left) {
            IsMarginLess = true,
            IconSize = 12,
            IconGap = 5,
            Children = {
                new AllSitewisePurchase(),
                new AllHeadwisePurchase(),
                new AllPartyTransaction()
            }
        };
        var detail = new DetailPurchasePayable();
        Grid.SetColumn(detail, 2);
        Grid.SetRowSpan(detail, 2);

        Grid.SetRow(purchasePayments, 1);
        Grid.SetColumn(allPurchase, 1);
        Grid.SetRowSpan(allPurchase, 2);
        grid = new Grid() {
            RowDefinitions = {
                    new RowDefinition(),
                    new RowDefinition(),
                },
            ColumnDefinitions = {
                    new ColumnDefinition(),
                    new ColumnDefinition(),
                    new ColumnDefinition(),
                },
            Children = { singlePurchase, purchasePayments, allPurchase, detail }
        };
        AddVisualChild(grid);
    }
}
