﻿class EditUnit : EditBase<Unit>
{
    public override string Header => "Unit";
    public override string Icon => Icons.Accounts;

    EditUnitVM vm = new();
    EditNameControl name = new();
    protected override IEdit<Unit> viewModel => vm;
    protected override EditNameControl editElement => name;
}
