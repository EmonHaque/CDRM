﻿class EditSubHead : EditBase<SubHead>
{
    public override string Header => "Subhead";
    public override string Icon => Icons.Head;

    EditSubHeadVM vm = new();
    EditNameControl name = new();
    protected override IEdit<SubHead> viewModel => vm;
    protected override EditNameControl editElement => name;
}
