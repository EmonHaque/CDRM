﻿class EditParty : EditBase<Party>
{
    public override string Header => "Party";
    public override string Icon => Icons.Tenant;

    EditPartyVM vm = new();
    EditPartyControl party = new();
    protected override IEdit<Party> viewModel => vm;
    protected override EditNameControl editElement => party;
}
