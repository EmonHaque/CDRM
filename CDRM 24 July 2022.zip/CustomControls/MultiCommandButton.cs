﻿class MultiCommandButton : CommandButton
{
    public Action BeforeCommand { get; set; }
    public MultiCommandButton() : base() { }

    protected override void OnKeyUp(KeyEventArgs e) {
        if (e.Key != Key.Space) return;
        BeforeCommand.Invoke();
        Command.Invoke();
    }
    protected override void OnMouseLeftButtonUp(MouseButtonEventArgs e) {
        BeforeCommand.Invoke();
        Command.Invoke();
    }
}
