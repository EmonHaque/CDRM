﻿class PurchaseSellGroupTemplate : DataTemplate
{
    public PurchaseSellGroupTemplate() {
        var grid = new FrameworkElementFactory(typeof(Grid));
        var header = new FrameworkElementFactory(typeof(TextBlock));
        header.SetBinding(TextBlock.TextProperty, new Binding(nameof(CollectionViewGroup.Name)));
        grid.AppendChild(header);
        VisualTree = grid;
    }
}
