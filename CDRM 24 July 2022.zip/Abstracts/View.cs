﻿abstract class View : FrameworkElement, IHaveIcon
{
    public virtual string Icon { get; }
    public abstract FrameworkElement container { get; }
    protected override Size MeasureOverride(Size availableSize) {
        container.Measure(availableSize);
        return container.DesiredSize;
    }
    protected override Size ArrangeOverride(Size finalSize) {
        container.Arrange(new Rect(container.DesiredSize));
        return finalSize;
    }
    protected override Visual GetVisualChild(int index) => container;
    protected override int VisualChildrenCount => 1;
}
