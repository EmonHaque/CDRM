﻿abstract class CardView : View
{
    public virtual string Header { get; }
    protected virtual bool DoesHandleRelocation { get; }
    protected virtual Action RelocationAction { get; }
    public override FrameworkElement container => card;
    Card card;

    public CardView() {
        card = new Card() { Header = Header };
        AddVisualChild(card);
        KeyboardNavigation.SetTabNavigation(this, KeyboardNavigationMode.Cycle);
        FocusManager.SetIsFocusScope(this, true);
        Loaded += onLoaded;
        Unloaded += onUnloaded;
    }

    void onLoaded(object sender, RoutedEventArgs e) {
        if (DoesHandleRelocation) {
            App.Current.MainWindow.LocationChanged += onLocationChanged;
            App.Current.MainWindow.StateChanged += onWindowStateChanged;
            if (Parent is ViewContainer) {
                ((ViewContainer)Parent).Transitioned += onTransitioned;
            }
            Dispatcher.InvokeAsync(RelocationAction.Invoke, DispatcherPriority.Background);
        }
    }
    void onTransitioned() {
        if (IsVisible) RelocationAction?.Invoke();
    }
    void onLocationChanged(object? sender, EventArgs e) {
        if (IsVisible) RelocationAction?.Invoke();
    }
    void onWindowStateChanged(object? sender, EventArgs e) {
        if (App.Current.MainWindow.WindowState == WindowState.Maximized && IsVisible)
            RelocationAction?.Invoke();
    }
    void onUnloaded(object sender, RoutedEventArgs e) {
        Loaded -= onLoaded;
        Unloaded -= onUnloaded;
        App.Current.MainWindow.LocationChanged -= onLocationChanged;
        App.Current.MainWindow.StateChanged -= onWindowStateChanged;
        if (Parent is ViewContainer) {
            ((ViewContainer)Parent).Transitioned -= onTransitioned;
        }
    }

    protected void setContent(FrameworkElement element) => card.Content = element;
    protected void addActions(ActionButton action) => card.AddActions(action);
    protected override void OnRenderSizeChanged(SizeChangedInfo sizeInfo) {
        base.OnRenderSizeChanged(sizeInfo);
        if (DoesHandleRelocation && IsVisible)
            RelocationAction.Invoke();
    }
}
