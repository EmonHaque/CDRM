﻿class EditSubHeadVM : EditBaseVM<SubHead>
{
    protected override CollectionViewSource cvs => new CollectionViewSource() {
        Source = AppData.subHeads,
        IsLiveSortingRequested = true,
        LiveSortingProperties = { nameof(IHaveName.Name) }
    };

    protected override SubHead clone() {
        return new SubHead() {
            Id = Selected.Id,
            Name = Selected.Name
        };
    }
    protected override void update() {
        lock (SQL.key) {
            SQL.command.CommandText = $"UPDATE SubHeads SET Name = @Name WHERE Id = {Selected.Id}";
            SQL.command.Parameters.AddWithValue("@Name", Edited.Name);
            SQL.command.ExecuteNonQuery();
            SQL.command.Parameters.Clear();
        }
        Selected.Name = Edited.Name;
        Selected.OnPropertyChanged(nameof(SubHead.Name));
    }
}
