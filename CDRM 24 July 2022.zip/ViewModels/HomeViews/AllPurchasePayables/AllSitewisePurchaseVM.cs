﻿class AllSitewisePurchaseVM : AllPurchaseBaseVM
{
    public static event Action<ReportDates, KeyValueSeries> SelectionChanged;
    protected override string command => $@"SELECT Sites.Name, SUM(Amount) FROM Dues
                                       LEFT JOIN Sites ON Sites.Id = Dues.SiteId
                                       WHERE IsSell = 0 AND
                                        Date BETWEEN '{Dates.From.Value.ToString("yyyy-MM-dd")}' AND '{Dates.To.Value.ToString("yyyy-MM-dd")}'
                                       GROUP BY Sites.Name";

    protected override void onSelectedChanged() {
        SelectionChanged?.Invoke(Dates, (KeyValueSeries)Selected);
    }
}
