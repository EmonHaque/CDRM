﻿class DetailPurchasePayableVM : Notifiable
{
    const string site = "Site";
    const string head = "Head";
    const string party = "Party";
    string type, query;
    int id;
    DateTime from, to;

    public ICollectionView Data { get; set; }
    public byte State { get; set; }
    public string[] StateTexts { get; set; }
    public string[] StateIcons { get; set; }
    
    public DetailPurchasePayableVM() {
        type = site;
        StateTexts = new string[] { head, party };
        StateIcons = new string[] { Icons.ControlHead, Icons.Tenant };
        Data = CollectionViewSource.GetDefaultView(new List<KeyValueSeries>());
        AllSitewisePurchaseVM.SelectionChanged += onSiteChanged;
        AllHeadwisePurchaseVM.SelectionChanged += onHeadChanged;
        AllPartyTransactionVM.SelectionChanged += onPartyChanged;
    }
    public void Refresh() {
        setQuery();
        getEntries();
    }
    public void SortName() => sort(nameof(KeyValueSeries.Key));
    public void SortAmount() => sort(nameof(KeyValueSeries.Value));

    void onPartyChanged(ReportDates d, KeyTrippleValueSeries k) {
        if (k is null) return;
        id = AppData.parties.First(x => x.Name.Equals(k.Key)).Id;
        if (!type.Equals(party)) {
            type = party;
            resetIcons(new string[] { site, head }, new string[] { Icons.Plot, Icons.ControlHead });
        }
        update(d);
    }
    void onHeadChanged(ReportDates d, KeyValueSeries k) {
        if (k is null) return;
        id = AppData.heads.First(x => x.Name.Equals(k.Key)).Id;
        if (!type.Equals(head)) {
            type = head;
            resetIcons(new string[] { site, party }, new string[] { Icons.Plot, Icons.Tenant });
        }
        update(d);
    }
    void onSiteChanged(ReportDates d, KeyValueSeries k) {
        if (k is null) return;
        id = AppData.sites.First(x => x.Name.Equals(k.Key)).Id;
        if (!type.Equals(site)) {
            type = site;
            resetIcons(new string[] { head, party }, new string[] { Icons.ControlHead, Icons.Tenant });
        }
        update(d);
    }
    void update(ReportDates d) {
        from = d.From.Value;
        to = d.To.Value;
        setQuery();
        getEntries();
    } 
    void resetIcons(string[] texts, string[] icons) {
        StateTexts = texts;
        StateIcons = icons;
        OnPropertyChanged(nameof(StateIcons));
        OnPropertyChanged(nameof(StateTexts));
    }
    void sort(string property) {
        if (Data is null) return;
        var direction = property.Equals(nameof(KeyValueSeries.Key)) ?
            ListSortDirection.Ascending :
            ListSortDirection.Descending;
        bool hasBeenSorted = false;
        if (Data.SortDescriptions.Count == 0) {
            Data.SortDescriptions.Add(new SortDescription(property, direction));
            return;
        }
        var first = Data.SortDescriptions.First();
        if (first.PropertyName.Equals(property)) {
            direction = first.Direction;
            hasBeenSorted = true;
        }
        if (hasBeenSorted) {
            if (direction == ListSortDirection.Descending) {
                addSortDescription(property, ListSortDirection.Ascending);
            }
            else addSortDescription(property, ListSortDirection.Descending);
        }
        else addSortDescription(property, ListSortDirection.Descending);
    }
    void addSortDescription(string property, ListSortDirection direction) {
        using (Data.DeferRefresh()) {
            Data.SortDescriptions.Clear();
            Data.SortDescriptions.Add(new SortDescription(property, direction));
        }
    }
    void setQuery() {
        switch (type) {
            case "Site":
                switch (State) {
                    case 0: // Head
                        query = $@"SELECT Heads.Name, SUM(Amount), 0, 0 FROM Dues
								LEFT JOIN Heads ON Heads.Id = Dues.HeadId
								WHERE IsSell = 0 AND SiteId = {id} AND
								Date BETWEEN '{from.ToString("yyyy-MM-dd")}' AND '{to.ToString("yyyy-MM-dd")}'
								GROUP BY Heads.Name";
                        break;
                    case 1: // Party
                        query = $@"SELECT Parties.Name, SUM(Amount), 0, 0 FROM Dues
								LEFT JOIN Parties ON Parties.Id = Dues.PartyId
								WHERE IsSell = 0 AND SiteId = {id} AND
								Date BETWEEN '{from.ToString("yyyy-MM-dd")}' AND '{to.ToString("yyyy-MM-dd")}'
								GROUP BY Parties.Name";
                        break;
                }
                break;
            case "Head":
                switch (State) {
                    case 0: // Site
                        query = $@"SELECT Sites.Name, SUM(Amount), 0, 0 FROM Dues
								LEFT JOIN Sites ON Sites.Id = Dues.SiteId
								WHERE IsSell = 0 AND HeadId = {id} AND
								Date BETWEEN '{from.ToString("yyyy-MM-dd")}' AND '{to.ToString("yyyy-MM-dd")}'
								GROUP BY Sites.Name";
                        break;
                    case 1: //Party
                        query = $@"SELECT Parties.Name, SUM(Amount), 0, 0 FROM Dues
								LEFT JOIN Parties ON Parties.Id = Dues.PartyId
								WHERE IsSell = 0 AND HeadId = {id} AND
								Date BETWEEN '{from.ToString("yyyy-MM-dd")}' AND '{to.ToString("yyyy-MM-dd")}'
								GROUP BY Parties.Name";
                        break;
                }
                break;
            case "Party":
                switch (State) {
                    case 0: // Site
                        query = $@"SELECT Sites.Name, SUM(Amount), 0, 0 FROM Dues
								LEFT JOIN Sites ON Sites.Id = Dues.SiteId
								WHERE IsSell = 0 AND PartyId = {id} AND
								Date BETWEEN '{from.ToString("yyyy-MM-dd")}' AND '{to.ToString("yyyy-MM-dd")}'
								GROUP BY Sites.Name";
                        break;
                    case 1: // Head
                        query = $@"SELECT Heads.Name, SUM(Amount), 0, 0 FROM Dues
								LEFT JOIN Heads ON Heads.Id = Dues.HeadId
								WHERE IsSell = 0 AND PartyId = {id} AND
								Date BETWEEN '{from.ToString("yyyy-MM-dd")}' AND '{to.ToString("yyyy-MM-dd")}'
								GROUP BY Heads.Name";
                        break;
                }
                break;
        }
    }
    void getEntries() {
        var list = new List<KeyValueSeries>();
        lock (SQL.key) {
            SQL.command.CommandText = query;
            var reader = SQL.command.ExecuteReader();
            while (reader.Read()) {
                var e = new KeyValueSeries() {
                    Key = reader.GetString(0),
                    Value = reader.GetInt32(1)
                };
                list.Add(e);
            }
            reader.Close();
            reader.DisposeAsync();
        }
        Data = CollectionViewSource.GetDefaultView(list);
        OnPropertyChanged(nameof(Data));
    }
}
