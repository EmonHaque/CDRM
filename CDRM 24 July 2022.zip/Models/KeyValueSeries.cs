﻿class KeyValueSeries
{
    public string Key { get; set; }
    public int Value { get; set; }
}
