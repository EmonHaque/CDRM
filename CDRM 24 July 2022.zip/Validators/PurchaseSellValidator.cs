﻿class PurchaseSellValidator
{
    EntryPurchaseSellText entry;
    public List<ValidationError> Errors { get; set; }
    
    public PurchaseSellValidator() { }
    public PurchaseSellValidator(EntryPurchaseSellText entry) {
        this.entry = entry;
    }
    public bool IsValid() {
        Errors = new List<ValidationError>();
        if (entry.Date is null) {
            Errors.Add(new ValidationError() {
                Head = nameof(entry.Date),
                Error = Constants.CannotBeEmpty
            });
        }
        if (string.IsNullOrWhiteSpace(entry.Site)) {
            Errors.Add(new ValidationError() {
                Head = nameof(entry.Site),
                Error = Constants.CannotBeEmpty
            });
        }
        if (string.IsNullOrWhiteSpace(entry.Party)) {
            Errors.Add(new ValidationError() {
                Head = nameof(entry.Party),
                Error = Constants.CannotBeEmpty
            });
        }
        if (string.IsNullOrWhiteSpace(entry.Head)) {
            Errors.Add(new ValidationError() {
                Head = nameof(entry.Head),
                Error = Constants.CannotBeEmpty
            });
        }
        if (string.IsNullOrWhiteSpace(entry.Amount)) {
            Errors.Add(new ValidationError() {
                Head = nameof(entry.Amount),
                Error = Constants.CannotBeEmpty
            });
        }
        else {
            int x;
            if (!int.TryParse(entry.Amount, NumberStyles.Number, CultureInfo.CurrentCulture.NumberFormat, out x)) {
                Errors.Add(new ValidationError() {
                    Head = nameof(entry.Amount),
                    Error = Constants.IsntValid
                });
            }
            else if (x <= 0) {
                Errors.Add(new ValidationError() {
                    Head = nameof(entry.Amount),
                    Error = Constants.MustBePositive
                });
            }
        }
        if (!string.IsNullOrWhiteSpace(entry.Quantity)) {
            double x;
            if (!double.TryParse(entry.Quantity, out x)) {
                Errors.Add(new ValidationError() {
                    Head = nameof(entry.Quantity),
                    Error = Constants.IsntValid
                });
            }
            else if (x <= 0) {
                Errors.Add(new ValidationError() {
                    Head = nameof(entry.Quantity),
                    Error = Constants.MustBePositive
                });
            }

            if (string.IsNullOrWhiteSpace(entry.Unit)) {
                Errors.Add(new ValidationError() {
                    Head = nameof(entry.Unit),
                    Error = Constants.CannotBeEmpty
                });
            }
        }
        return Errors.Count == 0;
    }
    public bool DoesExist() {
        Errors = new List<ValidationError>();
        if (!AppData.HasSite(entry.Site)) {
            Errors.Add(new ValidationError() {
                Head = nameof(entry.Site),
                Error = Constants.DoesntExist
            });
        }
        if (!AppData.HasParty(entry.Party)) {
            Errors.Add(new ValidationError() {
                Head = nameof(entry.Party),
                Error = Constants.DoesntExist
            });
        }
        if (!AppData.HasHead(entry.Head)) {
            Errors.Add(new ValidationError() {
                Head = nameof(entry.Head),
                Error = Constants.DoesntExist
            });
        }
        if (!string.IsNullOrWhiteSpace(entry.SubHead)) {
            if (!AppData.HasSubHead(entry.SubHead)) {
                Errors.Add(new ValidationError() {
                    Head = nameof(entry.SubHead),
                    Error = Constants.DoesntExist
                });
            }
        }
        if (!string.IsNullOrWhiteSpace(entry.Quantity)) {
            if (!AppData.HasUnit(entry.Unit)) {
                Errors.Add(new ValidationError() {
                    Head = nameof(entry.Unit),
                    Error = Constants.DoesntExist
                });
            }
        }
        return Errors.Count == 0;
    }
    public bool IsEqual(EntryPurchaseSellText e) {
        if (e.IsSell != entry.IsSell) {
            if (e.IsSell == 0) entry.Title = "Sell";
            else entry.Title = "Purchase";
            return false;
        }
        if (e.Date != entry.Date) return false;
        if (e.IsConstruction != entry.IsConstruction) return false;
        if (!e.Site.Equals(entry.Site, StringComparison.InvariantCultureIgnoreCase)) return false;
        if (!e.Party.Equals(entry.Party, StringComparison.InvariantCultureIgnoreCase)) return false;
        if (!e.Head.Equals(entry.Head, StringComparison.InvariantCultureIgnoreCase)) return false;
        if (!e.SubHead.Equals(entry.SubHead, StringComparison.InvariantCultureIgnoreCase)) return false;
        if (!e.Unit.Equals(entry.Unit, StringComparison.InvariantCultureIgnoreCase)) return false;
        if (!e.Narration.Equals(entry.Narration, StringComparison.InvariantCultureIgnoreCase)) return false;

        int originalAmount, editedAmount;
        int.TryParse(e.Amount, NumberStyles.Number, CultureInfo.CurrentCulture.NumberFormat, out originalAmount);
        int.TryParse(entry.Amount, NumberStyles.Number, CultureInfo.CurrentCulture.NumberFormat, out editedAmount);
        if (originalAmount != editedAmount) return false;

        double originalQuantity, editedQuantity;
        double.TryParse(e.Quantity, out originalQuantity);
        double.TryParse(entry.Quantity, out editedQuantity);
        if (originalQuantity != editedQuantity) return false;

        return true;
    }
}
