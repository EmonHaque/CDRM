﻿class NoteValidator
{
    EntryNoteText entry; 
    public List<ValidationError> Errors { get; set; }

    public NoteValidator() { }
    public NoteValidator(EntryNoteText entry) {
        this.entry = entry;
    }
    public bool IsValid() {
        Errors = new List<ValidationError>();
        if(entry.Date is null) {
            Errors.Add(new ValidationError() {
                Head = nameof(entry.Date),
                Error = "cannot be empty"
            });
        }
        if (string.IsNullOrWhiteSpace(entry.NoteType)) {
            Errors.Add(new ValidationError() {
                Head = nameof(entry.NoteType),
                Error = "cannot be empty"
            });
        }
        if (string.IsNullOrWhiteSpace(entry.Site)) {
            Errors.Add(new ValidationError() {
                Head = nameof(entry.Site),
                Error = "cannot be empty"
            });
        }
        if (string.IsNullOrWhiteSpace(entry.Entry)) {
            Errors.Add(new ValidationError() {
                Head = nameof(entry.Entry),
                Error = "cannot be empty"
            });
        }
        return Errors.Count == 0;
    }
    public bool DoesExist() {
        Errors = new List<ValidationError>();
        if (!AppData.HasNoteTye(entry.NoteType)) {
            Errors.Add(new ValidationError() {
                Head = nameof(entry.NoteType),
                Error = Constants.DoesntExist
            });
        }
        if (!AppData.HasSite(entry.Site)) {
            Errors.Add(new ValidationError() {
                Head = nameof(entry.Site),
                Error = Constants.DoesntExist
            });
        }
        return Errors.Count == 0;
    }
    public bool IsEqual(EntryNoteText e) {
        return
            e.Date == entry.Date
            && string.Equals(e.NoteType, entry.NoteType, StringComparison.InvariantCultureIgnoreCase)
            && string.Equals(e.Site, entry.Site, StringComparison.InvariantCultureIgnoreCase)
            && string.Equals(e.Entry, entry.Entry, StringComparison.InvariantCultureIgnoreCase);
    }
}
