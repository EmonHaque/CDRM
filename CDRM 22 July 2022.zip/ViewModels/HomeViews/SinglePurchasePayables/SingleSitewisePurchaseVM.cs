﻿class SingleSitewisePurchaseVM : SinglePurchasePayableBaseVM<Site>
{
    protected override ObservableCollection<Site> source => AppData.sites;
    protected override string datewiseQuery => $@"WITH t AS(
                                        	SELECT Date, SUM(Amount) FROM Dues WHERE SiteId = {Id} AND IsSell = 0
                                        	GROUP BY Date
                                        	ORDER BY Date DESC
                                        	LIMIT {maxDataPoints}
                                        )
                                        SELECT * FROM t ORDER BY Date";
    protected override string monthwiseQuery => $@"WITH t AS(
                                        	SELECT strftime('%Y - %m', Date) Month, SUM(Amount) FROM Dues
                                        	WHERE SiteId = {Id} AND IsSell = 0
                                        	GROUP BY Month
                                        	ORDER BY Month DESC
                                        	LIMIT {maxDataPoints}
                                        )
                                        SELECT * FROM t ORDER BY Month";
}
