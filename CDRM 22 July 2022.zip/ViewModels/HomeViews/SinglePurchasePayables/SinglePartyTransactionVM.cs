﻿class SinglePartyTransactionVM : SinglePurchasePayableBaseVM<Party>
{
    public override string Total => $"Purchase: {purchase.ToString("N0")}, paid: {paid.ToString("N0")}";
    protected override object getData(SqliteDataReader reader) {
        var ktvs = new KeyTrippleValueSeries() {
            Key = reader.GetString(0),
            Value1 = reader.GetInt32(1),
            Value2 = reader.GetInt32(2),
            Value3 = reader.GetInt32(3),
        };
        purchase += ktvs.Value1;
        paid += ktvs.Value2;
        return ktvs;
    }
    protected override ObservableCollection<Party> source => AppData.parties;
    protected override string datewiseQuery => $@"WITH t1(Date, Puchase, Payment, Due) AS(
                                    	SELECT Date, SUM(Amount),0,0 FROM Dues WHERE PartyId = {Id} AND IsSell = 0
                                    	GROUP BY Date
                                    	ORDER BY Date DESC
                                    	LIMIT {maxDataPoints}
                                    ),
                                    t2(Date, Puchase, Payment, Due) AS(
                                    	SELECT (SELECT MIN(Date) FROM t1), 0, 0, 
                                    	(SELECT SUM(Amount) FROM Dues WHERE Date <= (SELECT MIN(Date) FROM t1) AND PartyId = {Id} AND IsSell = 0)
                                    	- (SELECT SUM(Amount) FROM ReceiptPayments WHERE Date <= (SELECT MIN(Date) FROM t1) AND PartyId = {Id} AND IsReceipt = 0)
                                    ),
                                    t3(Date, Puchase, Payment, Due) AS(
                                    	SELECT Date, 0, SUM(Amount),0 FROM ReceiptPayments WHERE PartyId = {Id} AND IsReceipt = 0
                                    	AND Date >= (SELECT MIN(Date) FROM t1)
                                    	GROUP BY Date
                                    ),
                                    t4(Date, Puchase, Payment, Due) AS(
                                    	SELECT * FROM t1
                                    	UNION ALL
                                    	SELECT * FROM t2
                                    	UNION ALL
                                    	SELECT * FROM t3
                                    ),
                                    t5(Date, Puchase, Payment, Due) AS(
                                    	SELECT Date, SUM(Puchase), SUM(Payment), SUM(Due) FROM t4
                                    	GROUP BY Date
                                    ),
                                    t6(RowNum, Date, Puchase, Payment, Due) AS(
                                    	SELECT ROW_NUMBER() OVER(), * FROM t5 ORDER BY Date
                                    )
                                    SELECT Date, Puchase, Payment, 
                                    	CASE RowNum WHEN 1 THEN Due ELSE
                                    	SUM(Due + Puchase - Payment) OVER (ORDER BY RowNum) END Due 
                                    FROM t6 LIMIT {maxDataPoints}";
    protected override string monthwiseQuery => $@"WITH t1(Month, Puchase, Payment, Due) AS(
                                    	SELECT strftime('%Y - %m', Date) Month, SUM(Amount),0,0 FROM Dues WHERE PartyId = {Id} AND IsSell = 0
                                    	GROUP BY Month
                                    	ORDER BY Month DESC
                                    	LIMIT {maxDataPoints}
                                    ),
                                    t2(Month, Puchase, Payment, Due) AS(
                                    	SELECT (SELECT MIN(Month) FROM t1), 0, 0, 
                                    	(SELECT SUM(Amount) FROM Dues WHERE strftime('%Y - %m', Date) <= (SELECT MIN(Month) FROM t1) AND PartyId = {Id} AND IsSell = 0)
                                    	- (SELECT SUM(Amount) FROM ReceiptPayments WHERE strftime('%Y - %m', Date) <= (SELECT MIN(Month) FROM t1) AND PartyId = {Id} AND IsReceipt = 0)
                                    ),
                                    t3(Month, Puchase, Payment, Due) AS(
                                    	SELECT strftime('%Y - %m', Date) Month, 0, SUM(Amount),0 FROM ReceiptPayments WHERE PartyId = {Id} AND IsReceipt = 0
                                    	AND Month >= (SELECT MIN(Month) FROM t1)
                                    	GROUP BY Month
                                    ),
                                    t4(Month, Puchase, Payment, Due) AS(
                                    	SELECT * FROM t1
                                    	UNION ALL
                                    	SELECT * FROM t2
                                    	UNION ALL
                                    	SELECT * FROM t3
                                    ),
                                    t5(Month, Puchase, Payment, Due) AS(
                                    	SELECT Month, SUM(Puchase), SUM(Payment), SUM(Due) FROM t4
                                    	GROUP BY Month
                                    ),
                                    t6(RowNum, Month, Puchase, Payment, Due) AS(
                                    	SELECT ROW_NUMBER() OVER(), * FROM t5 ORDER BY Month
                                    )
                                    SELECT Month, Puchase, Payment, 
                                    	CASE RowNum WHEN 1 THEN Due ELSE
                                    	SUM(Due + Puchase - Payment) OVER (ORDER BY RowNum) END Due 
                                    FROM t6 LIMIT {maxDataPoints}";
}
