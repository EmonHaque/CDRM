﻿class AllSitewisePurchaseVM : AllPurchaseBaseVM
{
    protected override string command => $@"SELECT Sites.Name, SUM(Amount) FROM Dues
                                       LEFT JOIN Sites ON Sites.Id = Dues.SiteId
                                       WHERE IsSell = 0 AND
                                        Date BETWEEN '{From.Value.ToString("yyyy-MM-dd")}' AND '{To.Value.ToString("yyyy-MM-dd")}'
                                       GROUP BY Sites.Name";
}
