﻿class AllPartyTransactionVM : AllPurchaseBaseVM
{
    public int X2Max { get; set; }
    // Due Calculation ok?
    protected override string command => $@"WITH t1 (Party, Purchase, Payment, Due) AS(
											SELECT Parties.Name, SUM(Amount), 0, 0 FROM Dues
											LEFT JOIN Parties ON Parties.Id = Dues.PartyId
											WHERE IsSell = 0 AND
											Date BETWEEN '{From.Value.ToString("yyyy-MM-dd")}' AND '{To.Value.ToString("yyyy-MM-dd")}'
											GROUP BY Parties.Name
										),
										t2(Party, Purchase, Payment, Due) AS(
											SELECT Parties.Name, 0, SUM(Amount), 0 FROM ReceiptPayments rp
											LEFT JOIN Parties ON Parties.Id = rp.PartyId
											WHERE IsReceipt = 0 AND
											Date BETWEEN '{From.Value.ToString("yyyy-MM-dd")}' AND '{To.Value.ToString("yyyy-MM-dd")}'
											GROUP BY Parties.Name
										),
										t3(Party, Purchase, Payment, Due) AS(
											SELECT * FROM t1
											UNION ALL
											SELECT * FROM t2
										),
										t4(Party, Purchase, Payment, Due) AS(
											SELECT Party, SUM(Purchase), SUM(Payment), SUM(Purchase - Payment)
											FROM t3
											GROUP BY Party
										)
										SELECT * FROM t4";
    protected override object getData(SqliteDataReader reader) {
        var e = new KeyTrippleValueSeries() {
            Key = reader.GetString(0),
            Value1 = reader.GetInt32(1),
            Value2 = reader.GetInt32(2),
            Value3 = reader.GetInt32(3)
        };
        if (X1Max < e.Value1) X1Max = e.Value1;
        if (X2Max < e.Value3) X2Max = e.Value3;
        return e;
    }
    protected override void notify() {
        base.notify();
        OnPropertyChanged(nameof(X2Max));
    }
    protected override void getEntries() {
        X2Max = 0;
        base.getEntries();
    }
    protected override bool filter(object o) {
        if (string.IsNullOrWhiteSpace(Query)) return true;
        return ((KeyTrippleValueSeries)o).Key.Contains(Query, StringComparison.InvariantCultureIgnoreCase);
    }

    public override void SortPurchase() => sort(nameof(KeyTrippleValueSeries.Value1));
    public void SortPayment() => sort(nameof(KeyTrippleValueSeries.Value2));
    public void SortDue() => sort(nameof(KeyTrippleValueSeries.Value3));

    void sort(string property) {
        if (Data is null) return;
        var direction = ListSortDirection.Descending;
        bool hasBeenSorted = false;
        if (Data.SortDescriptions.Count == 0) {
            Data.SortDescriptions.Add(new SortDescription(nameof(KeyTrippleValueSeries.Value3), direction));
            return;
        }
        var first = Data.SortDescriptions.First();
        if (first.PropertyName.Equals(property)) {
            direction = first.Direction;
            hasBeenSorted = true;
        }
        if (hasBeenSorted) {
            if (direction == ListSortDirection.Descending) {
                addSortDescription(property, ListSortDirection.Ascending);
            }
            else addSortDescription(property, ListSortDirection.Descending);
        }
        else addSortDescription(property, ListSortDirection.Descending);
    }
    void addSortDescription(string property, ListSortDirection direction) {
        using (Data.DeferRefresh()) {
            Data.SortDescriptions.Clear();
            Data.SortDescriptions.Add(new SortDescription(property, direction));
        }
    }
}
