﻿class AllHeadwisePurchaseVM : AllPurchaseBaseVM
{
    protected override string command => $@"SELECT Heads.Name, SUM(Amount) FROM Dues
                                        LEFT JOIN Heads ON Heads.Id = Dues.HeadId
                                        WHERE IsSell = 0 AND 
                                        Date BETWEEN '{From.Value.ToString("yyyy-MM-dd")}' AND '{To.Value.ToString("yyyy-MM-dd")}'
                                        GROUP BY Heads.Name";
}
