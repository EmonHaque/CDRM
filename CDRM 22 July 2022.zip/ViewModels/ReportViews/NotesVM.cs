﻿class NotesVM : Notifiable
{
    ObservableCollection<EntryNoteText> reportables;
    string query;
    public string Query {
        get { return query; }
        set { query = value; Reportables.Refresh(); }
    }
    EntryNoteText selected;
    public EntryNoteText Selected {
        get { return selected; }
        set { 
            selected = value;
            if (IsOnEdit) {
                IsOnEdit = false;
                OnPropertyChanged(nameof(IsOnEdit));
            }
        }
    }
    public EntryNoteText Edited { get; set; }
    public bool IsOnEdit { get; set; }
    public ICollectionView Reportables { get; set; }

    public double Top { get; set; }
    public double Left { get; set; }
    public double Width { get; set; }
    public double Height { get; set; }

    public NotesVM() {
        reportables = new ObservableCollection<EntryNoteText>();
        Reportables = new CollectionViewSource() {
            Source = reportables,
            IsLiveGroupingRequested = true,
            LiveGroupingProperties = { nameof(EntryNoteText.Site), nameof(EntryNoteText.NoteType) },
            GroupDescriptions = {
                new PropertyGroupDescription(nameof(EntryNoteText.Site)),
                new PropertyGroupDescription(nameof(EntryNoteText.NoteType))
            }
        }.View;
        Reportables.Filter = filter;
        getNotes();
    }

    public void Refresh() {
        getNotes();
    }
    public void Delete() {
        if (Selected is null) return;
        AppData.DeleteNote(Selected.Id);
        reportables.Remove(Selected);
    }
    public void Edit() {
        if (Selected is null) return;
        Edited = new EntryNoteText() {
            Id = Selected.Id,
            Date = Selected.Date,
            NoteType = Selected.NoteType,
            Site = Selected.Site,
            Entry = Selected.Entry
        };
        IsOnEdit = true;
        OnPropertyChanged(nameof(IsOnEdit));
        OnPropertyChanged(nameof(Edited));
    }
    public void Cancel() {
        IsOnEdit = false;
        OnPropertyChanged(nameof(IsOnEdit));
    }
    public void Save() {
        if (Selected is null) return;
        var validator = new NoteValidator(Edited);
        if (!validator.IsValid()) {
            var errorDialog = new ErrorDialog(Left, Top, Width, Height, validator.Errors);
            errorDialog.ShowDialog();
            return;
        }
        if (validator.IsEqual(Selected)) return;

        if (!validator.DoesExist()) {
            var confirmDialog = new ConfirmCreationDialog(Left, Top, Width, Height, validator.Errors);
            var result = confirmDialog.ShowDialog();
            if (!result.HasValue) return;
            if (!result.Value) return;

            foreach (var e in validator.Errors) {
                switch (e.Head) {
                    case nameof(Edited.Site): {
                            var dialog = new CreateSiteDialog(Left, Top, Width, Height, Edited.Site);
                            dialog.ShowDialog();
                            var site = new Site() {
                                Name = Edited.Site.Trim(),
                                Address = dialog.GetAddress().Trim()
                            };
                            AppData.InsertSite(site);
                        }
                        break;

                    case nameof(Edited.NoteType): AppData.InsertNoteType(Edited.NoteType.Trim()); break;
                }
            }
        }
        AppData.UpdateNote(new Note() {
            Id = Edited.Id,
            Date = Edited.Date.Value,
            SiteId = AppData.GetSite().Id,
            NoteTypeId = AppData.GetNoteType().Id,
            Entry = Edited.Entry
        });
        Selected.Date = Edited.Date;
        Selected.Site = Edited.Site;
        Selected.NoteType = Edited.NoteType;
        Selected.Entry = Edited.Entry;
        Selected.OnPropertyChanged(null);
        IsOnEdit = false;
        OnPropertyChanged(nameof(IsOnEdit));
    }

    bool filter(object o) {
        if (string.IsNullOrWhiteSpace(Query)) return true;
        return ((EntryNoteText)o).Entry.Contains(Query, StringComparison.InvariantCultureIgnoreCase);
    }
    void getNotes() {
        reportables.Clear();
        lock (SQL.key) {
            SQL.command.CommandText = @"SELECT Date, nt.Name, si.Name, Entry, n.Id FROM Notes n
                                        LEFT JOIN Sites si ON si.Id = n.SiteId
                                        LEFT JOIN NoteTypes nt ON nt.Id = n.NoteTypeId
                                        ORDER BY Date DESC;";
            var reader = SQL.command.ExecuteReader();
            while (reader.Read()) {
                reportables.Add(new EntryNoteText() {
                    Date = reader.GetDateTime(0),
                    NoteType = reader.GetString(1),
                    Site = reader.GetString(2),
                    Entry = reader.GetString(3),
                    Id = reader.GetInt32(4)
                });
            }
            reader.Close();
            reader.DisposeAsync();
        }
    }
}
