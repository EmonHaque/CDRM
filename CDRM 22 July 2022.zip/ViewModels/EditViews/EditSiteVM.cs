﻿class EditSiteVM : EditBaseVM<Site>
{
    protected override CollectionViewSource cvs => new CollectionViewSource() {
        Source = AppData.sites,
        IsLiveSortingRequested = true,
        LiveSortingProperties = { nameof(IHaveName.Name) }
    };

    protected override Site clone() {
        return new Site() {
            Id = Selected.Id,
            Name = Selected.Name,
            Address = Selected.Address
        };
    }
    protected override void update() {
        lock (SQL.key) {
            SQL.command.CommandText = $"UPDATE Sites SET Name = @Name, Address = @Address WHERE Id = {Selected.Id}";
            SQL.command.Parameters.AddWithValue("@Name", Edited.Name);
            SQL.command.Parameters.AddWithValue("@Address", Edited.Address);
            SQL.command.ExecuteNonQuery();
            SQL.command.Parameters.Clear();
        }
        Selected.Name = Edited.Name;
        Selected.Address = Edited.Address;
        Selected.OnPropertyChanged(nameof(Site.Name));
        Selected.OnPropertyChanged(nameof(Site.Address));
    }
}
