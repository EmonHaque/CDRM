﻿class HorizontalBarChart : FrameworkElement
{
    int numSteps = 5;
    ItemsControl items;
    VisualCollection visuals;
    public DataTemplate ItemTemplate { get; set; }

    public HorizontalBarChart() {
        visuals = new VisualCollection(this);
        addSideLabel();
        addTicks();
        addLines();
        items = new ItemsControl() {
            ItemsPanel = new ItemsPanelTemplate(new FrameworkElementFactory(typeof(VirtualizingStackPanel))),
            Template = new EnumerableBoxTemplate(),
            Resources = {
                {
                    typeof(ScrollViewer),
                    new Style(typeof(ScrollViewer)) {
                        Setters = {
                            new Setter(ScrollViewer.HorizontalScrollBarVisibilityProperty, ScrollBarVisibility.Disabled),
                            new Setter(ScrollViewer.VerticalScrollBarVisibilityProperty, ScrollBarVisibility.Auto),
                            new Setter(ScrollViewer.TemplateProperty, new LedgerScrollTemplate())
                        }
                    }
                }
            }
        };
        visuals.Add(items);
        items.SetBinding(ItemsControl.ItemsSourceProperty, new Binding(nameof(ItemsSource)) { Source = this });
        Loaded += onLoaded;
        Unloaded += onUnloaded;
    }

    void onLoaded(object sender, RoutedEventArgs e) {
        items.ItemTemplate = ItemTemplate;
    }
    void onUnloaded(object sender, RoutedEventArgs e) {
        Loaded -= onLoaded;
        Unloaded -= onUnloaded;
    }
    void addLines() {
        for (int i = 0; i < numSteps; i++) {
            var line = new Line() {
                StrokeThickness = 0.25,
                Stroke = Brushes.CornflowerBlue,
                StrokeDashCap = PenLineCap.Flat,
                StrokeDashArray = new DoubleCollection(new List<double> { 10, 5 }),
                IsHitTestVisible = false
            };
            visuals.Add(line);
        }
    }
    void addTicks() {
        for (int i = 0; i < numSteps; i++) {
            var tick = new TextBlock() {
                Tag = "Tick",
                Margin = new Thickness(1,0,0,0),
                RenderTransform = new RotateTransform(90),
                IsHitTestVisible = false
            };
            visuals.Add(tick);
        }
    }
    void addSideLabel() {
        var label = new TextBlock() {
            Text = "Purchase / Payable",
            FontWeight = FontWeights.Bold,
            Foreground = Brushes.Gray,
            Tag = "X1Label",
            Margin = new Thickness(0, 0, 0, 5),
            IsHitTestVisible = false
        };
        visuals.Add(label);
    }
    protected override Size ArrangeOverride(Size finalSize) {
        double tickHeight = 0;
        double sideLabelHeight = 0;
        double keyWidth = Constants.HorizontalBarKeyWidth;
        double lineX = keyWidth;
        double blockX = keyWidth;
       
        double lineStep = (finalSize.Width - 100 - Constants.ScrollBarThickness - Constants.ScrollPresenterMargin) / (numSteps - 1);

        foreach (UIElement item in visuals) {
            if (item is TextBlock block) {
                if (block.Tag.Equals("Tick")) {
                    block.Measure(finalSize);
                    block.Arrange(new Rect(new Point(blockX + block.DesiredSize.Height, sideLabelHeight), item.DesiredSize));
                    blockX += lineStep;
                    if (tickHeight < block.DesiredSize.Width) {
                        tickHeight = block.DesiredSize.Width;
                    }
                }
                else if (block.Tag.Equals("X1Label")) {
                    block.Measure(finalSize);
                    sideLabelHeight = block.DesiredSize.Height;
                    var x = keyWidth + (finalSize.Width - keyWidth) / 2 - block.DesiredSize.Width / 2;
                    block.Arrange(new Rect(new Point(x, 0), block.DesiredSize));
                }
            }
            else if(item is Line line) {
                line.Y1 = sideLabelHeight;
                line.Y2 = finalSize.Height;
                line.X1 = line.X2 = lineX;
                line.Measure(finalSize);
                line.Arrange(new Rect(line.DesiredSize));
                lineX += lineStep;
            }
            else if (item is ItemsControl control) {
                double marginTop = sideLabelHeight + tickHeight + 10;
                control.Width = finalSize.Width;
                control.Height = finalSize.Height - marginTop;
                control.Measure(finalSize);
                control.Arrange(new Rect(new Point(0, marginTop), control.DesiredSize));
            }
        }
        return finalSize;
    }
    protected override int VisualChildrenCount => visuals.Count;
    protected override Visual GetVisualChild(int index) => visuals[index];

    #region DependencyProperties
    public static readonly DependencyProperty MaxValueProperty;
    public static readonly DependencyProperty ItemsSourceProperty;

    static HorizontalBarChart() {
        MaxValueProperty = DependencyProperty.Register("MaxValue", typeof(int), typeof(HorizontalBarChart), new PropertyMetadata() {
            PropertyChangedCallback = (d, e) => {
                var o = (HorizontalBarChart)d;
                var step = o.MaxValue / 4;
                int current = 0;
                foreach (var item in o.visuals) {
                    if (item is TextBlock block) {
                        if (!block.Tag.Equals("Tick")) continue;
                        block.Text = current.ToString("N0");
                        current += step;
                    }
                }
            }
        });
        ItemsSourceProperty = DependencyProperty.Register("ItemsSource", typeof(IEnumerable), typeof(HorizontalBarChart));
    }
    public IEnumerable ItemsSource {
        get { return (IEnumerable)GetValue(ItemsSourceProperty); }
        set { SetValue(ItemsSourceProperty, value); }
    }
    public int MaxValue {
        get { return (int)GetValue(MaxValueProperty); }
        set { SetValue(MaxValueProperty, value); }
    }
    #endregion
}
