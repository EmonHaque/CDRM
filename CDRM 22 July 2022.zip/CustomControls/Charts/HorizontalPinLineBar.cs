﻿class HorizontalPinLineBar : Grid
{
    HiBlock text;
    TextBlock measuringBlock;
    EllipseGeometry circleGeo;
    Path circle;
    Line lineOfPin, line;
    Border bar;
    Brush barNormal, barHighlight, textNormal, textHighlight, lineOfPinBrush, lineBrush, circleBrush;
    Color lineOfPinNormal, circleNormal, lineOfPinHighlight, circleHighlight, lineNormal, lineHighlight;
    double radius = 3;
    KeyTrippleValueSeries currentData, previousData;

    public HorizontalPinLineBar() {
        Margin = new Thickness(0, 2.5, 0, 2.5);
        //SnapsToDevicePixels = true;
        barNormal = Brushes.LightGray;
        barHighlight = Brushes.CornflowerBlue;
        textNormal = Brushes.LightGray;
        textHighlight = Brushes.Coral;
        lineNormal = Colors.SkyBlue;
        lineHighlight = Colors.Red;
        lineOfPinNormal = Colors.Gray;
        circleNormal = Colors.CornflowerBlue;
        lineOfPinHighlight = Colors.LightGray;
        circleHighlight = Colors.Coral;

        lineOfPinBrush = new SolidColorBrush(lineOfPinNormal);
        circleBrush = new SolidColorBrush(circleNormal);
        lineBrush = new SolidColorBrush(Colors.SkyBlue);

        text = new HiBlock() { TextWrapping = TextWrapping.Wrap };
        bar = new Border() {
            HorizontalAlignment = HorizontalAlignment.Left,
            CornerRadius = new CornerRadius(0, 5, 5, 0),
            Background = barNormal,
            Height = 10
        };
        lineOfPin = new Line() {
            HorizontalAlignment = HorizontalAlignment.Left,
            Stroke = lineOfPinBrush,
            StrokeThickness = 2.5
        };
        circleGeo = new EllipseGeometry() { RadiusX = radius, RadiusY = radius };
        circle = new Path() {
            Fill = circleBrush,
            Data = circleGeo
        };
        line = new Line() {
            Stroke = lineBrush,
            StrokeThickness = 1.5
        };

        ColumnDefinitions.Add(new ColumnDefinition() { Width = new GridLength(Constants.HorizontalBarKeyWidth) });
        ColumnDefinitions.Add(new ColumnDefinition());

        SetColumn(bar, 1);
        SetColumn(lineOfPin, 1);
        SetColumn(circle, 1);
        SetColumn(line, 1);
        Children.Add(text);
        Children.Add(bar);
        Children.Add(lineOfPin);
        Children.Add(line);
        Children.Add(circle);

        measuringBlock = new TextBlock() {
            TextWrapping = TextWrapping.Wrap,
            Width = 100,
            Margin = new Thickness(0, Margin.Top, 0, Margin.Bottom)
        };
       
        Loaded += onLoaded;
        Unloaded += onUnloaded;
    }

    void onLoaded(object sender, RoutedEventArgs e) {
        currentData = (KeyTrippleValueSeries)DataContext;
        previousData = Previous as KeyTrippleValueSeries;

        var chartWidth = ActualWidth - Constants.HorizontalBarKeyWidth;
        text.Text = currentData.Key;
        var newX1Max = X1Max / chartWidth * radius + X1Max;
        lineOfPin.Y1 = lineOfPin.Y2 = ActualHeight / 2;
        lineOfPin.X2 = currentData.Value1 / newX1Max * chartWidth;
        circleGeo.Center = new Point(lineOfPin.X2, lineOfPin.Y2);
        bar.Width = (double)currentData.Value3 / X2Max * chartWidth;

        if (previousData is not null) {
            measuringBlock.Text = previousData.Key;
            measuringBlock.Measure(new Size(ActualWidth, double.PositiveInfinity));
            double previousHeight = measuringBlock.DesiredSize.Height;

            measuringBlock.Text = currentData.Key;
            measuringBlock.Measure(new Size(ActualWidth, double.PositiveInfinity));
            double currentHeight = measuringBlock.DesiredSize.Height;

            line.X1 = previousData.Value2 / newX1Max * chartWidth;
            line.X2 = currentData.Value2 / newX1Max * chartWidth;
            line.Y1 = -(previousHeight / 2 + Margin.Top);
            line.Y2 = currentHeight / 2 - Margin.Top;
        }

        ToolTip = new HorizontalPinLineBarToolTip(currentData); 
        text.SetBinding(HiBlock.QueryProperty, new Binding("DataContext." + nameof(AllHeadwisePurchaseVM.Query)) {
            RelativeSource = new RelativeSource(RelativeSourceMode.FindAncestor, typeof(HorizontalPinLineBarChart), 1)
        });
    }
    void onUnloaded(object sender, RoutedEventArgs e) {
        BindingOperations.ClearAllBindings(text);
        Loaded -= onLoaded;
        Unloaded -= onUnloaded;
    }
    protected override void OnMouseEnter(MouseEventArgs e) {
        bar.Background = barHighlight;
        text.Foreground = textHighlight;
        lineOfPinBrush.SetValue(SolidColorBrush.ColorProperty, lineOfPinHighlight);
        circleBrush.SetValue(SolidColorBrush.ColorProperty, circleHighlight);
        lineBrush.SetValue(SolidColorBrush.ColorProperty, lineHighlight);
    }
    protected override void OnMouseLeave(MouseEventArgs e) {
        bar.Background = barNormal;
        text.Foreground = textNormal;
        lineOfPinBrush.SetValue(SolidColorBrush.ColorProperty, lineOfPinNormal);
        circleBrush.SetValue(SolidColorBrush.ColorProperty, circleNormal);
        lineBrush.SetValue(SolidColorBrush.ColorProperty, lineNormal);
    }
    protected override void OnRenderSizeChanged(SizeChangedInfo sizeInfo) {
        base.OnRenderSizeChanged(sizeInfo);
        if (currentData is null) return;

        var chartWidth = ActualWidth - Constants.HorizontalBarKeyWidth;
        var newBound = X1Max / chartWidth * radius + X1Max;
        lineOfPin.Y1 = lineOfPin.Y2 = ActualHeight / 2;
        lineOfPin.X2 = currentData.Value1 / newBound * chartWidth;
        circleGeo.Center = new Point(lineOfPin.X2, lineOfPin.Y2);
        bar.Width = (double)currentData.Value3 / X2Max * chartWidth;

        if(previousData is not null) {
            line.X1 = previousData.Value2 / newBound * chartWidth;
            line.X2 = currentData.Value2 / newBound * chartWidth;
        }
    }

    #region DependencyProperties
    public static readonly DependencyProperty X1MaxProperty;
    public static readonly DependencyProperty X2MaxProperty;
    public static readonly DependencyProperty PreviousProperty;

    static HorizontalPinLineBar() {
        X1MaxProperty = DependencyProperty.Register("X1Max", typeof(int), typeof(HorizontalPinLineBar));
        X2MaxProperty = DependencyProperty.Register("X2Max", typeof(int), typeof(HorizontalPinLineBar));
        PreviousProperty = DependencyProperty.Register("Previous", typeof(object), typeof(HorizontalPinLineBar));
    }

    public int X1Max {
        get { return (int)GetValue(X1MaxProperty); }
        set { SetValue(X1MaxProperty, value); }
    }
    public int X2Max {
        get { return (int)GetValue(X2MaxProperty); }
        set { SetValue(X2MaxProperty, value); }
    }
    public object Previous {
        get { return (object)GetValue(PreviousProperty); }
        set { SetValue(PreviousProperty, value); }
    }
    #endregion

}

