﻿class HorizontalPinLineBarChart : FrameworkElement
{
    int numSteps = 7;
    ItemsControl items;
    VisualCollection visuals;
    public DataTemplate ItemTemplate { get; set; }

    public HorizontalPinLineBarChart() {
        visuals = new VisualCollection(this);
        addSideLabels();
        addX1Ticks();
        addX2Ticks();
        addLines();
        items = new ItemsControl() {
            ItemsPanel = new ItemsPanelTemplate(new FrameworkElementFactory(typeof(VirtualizingStackPanel))),
            Template = new EnumerableBoxTemplate(),
            Resources = {
                {
                    typeof(ScrollViewer),
                    new Style(typeof(ScrollViewer)) {
                        Setters = {
                            new Setter(ScrollViewer.HorizontalScrollBarVisibilityProperty, ScrollBarVisibility.Disabled),
                            new Setter(ScrollViewer.VerticalScrollBarVisibilityProperty, ScrollBarVisibility.Auto),
                            new Setter(ScrollViewer.TemplateProperty, new LedgerScrollTemplate(false /*false = virtualization loss?*/))
                        }
                    }
                },
                //{
                //    typeof(VirtualizingStackPanel),
                //    new Style(typeof(VirtualizingStackPanel)) {
                //        Setters = { new Setter(VirtualizingStackPanel.ScrollUnitProperty, ScrollUnit.Pixel) }
                //    }
                //}
            }
        };
        visuals.Add(items);
        items.SetBinding(ItemsControl.ItemsSourceProperty, new Binding(nameof(ItemsSource)) { Source = this });
        Loaded += onLoaded;
        Unloaded += onUnloaded;
    }

    void onLoaded(object sender, RoutedEventArgs e) {
        items.ItemTemplate = ItemTemplate;

        // smooth scrolling doesn't work unless LedgerScrollTemplate CanContentScroll is false
        //items.Resources.Add(typeof(VirtualizingStackPanel), new Style(typeof(VirtualizingStackPanel)) {
        //    Setters = { new Setter(VirtualizingStackPanel.ScrollUnitProperty, ScrollUnit.Pixel) }
        //});
    }
    void onUnloaded(object sender, RoutedEventArgs e) {
        Loaded -= onLoaded;
        Unloaded -= onUnloaded;
    }
    void addLines() {
        for (int i = 0; i < numSteps; i++) {
            var line = new Line() {
                StrokeThickness = 0.25,
                Stroke = Brushes.CornflowerBlue,
                StrokeDashCap = PenLineCap.Flat,
                StrokeDashArray = new DoubleCollection(new List<double> { 10, 5 }),
                IsHitTestVisible = false
            };
            visuals.Add(line);
        }
    }
    void addX1Ticks() {
        for (int i = 0; i < numSteps; i++) {
            var tick = new TextBlock() {
                Tag = "X1Tick",
                Margin = new Thickness(1, 0, 0, 0),
                RenderTransform = new RotateTransform(90),
                IsHitTestVisible = false
            };
            visuals.Add(tick);
        }
    }
    void addX2Ticks() {
        for (int i = 0; i < numSteps; i++) {
            var tick = new TextBlock() {
                Tag = "X2Tick",
                Margin = new Thickness(1, 0, 0, 0),
                RenderTransform = new RotateTransform(90),
                IsHitTestVisible = false
            };
            visuals.Add(tick);
        }
    }
    void addSideLabels() {
        var x1Label = new TextBlock() {
            Text = "Purchase & Payments",
            FontWeight = FontWeights.Bold,
            Foreground = Brushes.Gray,
            Tag = "X1Label",
            Margin = new Thickness(0, 0, 0, 5),
            IsHitTestVisible = false
        };
        var x2Label = new TextBlock() {
            Text = "Outstanding",
            FontWeight = FontWeights.Bold,
            Foreground = Brushes.Gray,
            Tag = "X2Label",
            Margin = new Thickness(0, 5, 0, 0),
            IsHitTestVisible = false
        };
        visuals.Add(x1Label);
        visuals.Add(x2Label);
    }
    
    protected override Size ArrangeOverride(Size finalSize) {
        double keyWidth = Constants.HorizontalBarKeyWidth;
        double X1TickHeight, X2TickHeight, x1LabelHeight, x2LabelHeight;
        X1TickHeight = X2TickHeight = x1LabelHeight = x2LabelHeight = 0;

        double lineX = keyWidth;
        double blockX1 = keyWidth;
        double blockX2 = keyWidth;
        double lineStep = (finalSize.Width - keyWidth - Constants.ScrollBarThickness - Constants.ScrollPresenterMargin) / (numSteps - 1);

        foreach (UIElement item in visuals) {
            if (item is TextBlock block) {
                if (block.Tag.Equals("X1Tick")) {
                    block.Measure(finalSize);
                    block.Arrange(new Rect(new Point(blockX1 + block.DesiredSize.Height, x1LabelHeight), item.DesiredSize));
                    blockX1 += lineStep;
                    if (X1TickHeight < block.DesiredSize.Width) {
                        X1TickHeight = block.DesiredSize.Width;
                    }
                }
                else if (block.Tag.Equals("X2Tick")) {
                    block.Measure(finalSize);
                    if (X2TickHeight < block.DesiredSize.Width) {
                        X2TickHeight = block.DesiredSize.Width;
                    }
                    
                    block.Arrange(new Rect(new Point(blockX2 + block.DesiredSize.Height, finalSize.Height - x2LabelHeight - X2TickHeight), item.DesiredSize));
                    blockX2 += lineStep;
                    
                }
                else if (block.Tag.Equals("X1Label")) {
                    block.Measure(finalSize);
                    x1LabelHeight = block.DesiredSize.Height;
                    var x = keyWidth + (finalSize.Width - keyWidth) / 2 - block.DesiredSize.Width / 2;
                    block.Arrange(new Rect(new Point(x, 0), block.DesiredSize));
                }
                else if (block.Tag.Equals("X2Label")) {
                    block.Measure(finalSize);
                    x2LabelHeight = block.DesiredSize.Height;
                    var x = keyWidth + (finalSize.Width - keyWidth) / 2 - block.DesiredSize.Width / 2;
                    block.Arrange(new Rect(new Point(x, finalSize.Height - x2LabelHeight), block.DesiredSize));
                }
            }
            else if (item is Line line) {
                line.Y1 = x1LabelHeight;
                line.Y2 = finalSize.Height - x2LabelHeight;
                line.X1 = line.X2 = lineX;
                line.Measure(finalSize);
                line.Arrange(new Rect(line.DesiredSize));
                lineX += lineStep;
            }
            else if (item is ItemsControl control) {
                double marginTop = x1LabelHeight + X1TickHeight + 10;
                double marginBottom = x2LabelHeight + X2TickHeight + 10;
                control.Width = finalSize.Width;
                control.Height = finalSize.Height - marginTop - marginBottom;
                control.Measure(finalSize);
                control.Arrange(new Rect(new Point(0, marginTop), control.DesiredSize));
            }
        }
        return finalSize;
    }
    protected override int VisualChildrenCount => visuals.Count;
    protected override Visual GetVisualChild(int index) => visuals[index];

    #region DependencyProperties
    public static readonly DependencyProperty X1MaxProperty;
    public static readonly DependencyProperty X2MaxProperty;
    public static readonly DependencyProperty ItemsSourceProperty;
    
    static HorizontalPinLineBarChart() {
        X1MaxProperty = DependencyProperty.Register("X1Max", typeof(int), typeof(HorizontalPinLineBarChart), new PropertyMetadata() {
            PropertyChangedCallback = (d, e) => {
                var o = (HorizontalPinLineBarChart)d;
                var step = o.X1Max / (o.numSteps - 1);
                int current = 0;
                foreach (var item in o.visuals) {
                    if (item is TextBlock block) {
                        if (!block.Tag.Equals("X1Tick")) continue;
                        block.Text = current.ToString("N0");
                        current += step;
                    }
                }
            }
        });
        X2MaxProperty = DependencyProperty.Register("X2Max", typeof(int), typeof(HorizontalPinLineBarChart), new PropertyMetadata() {
            PropertyChangedCallback = (d, e) => {
                var o = (HorizontalPinLineBarChart)d;
                var step = o.X2Max / (o.numSteps - 1);
                int current = 0;
                foreach (var item in o.visuals) {
                    if (item is TextBlock block) {
                        if (!block.Tag.Equals("X2Tick")) continue;
                        block.Text = current.ToString("N0");
                        current += step;
                    }
                }
            }
        });
        ItemsSourceProperty = DependencyProperty.Register("ItemsSource", typeof(IEnumerable), typeof(HorizontalPinLineBarChart));
    }
    public IEnumerable ItemsSource {
        get { return (IEnumerable)GetValue(ItemsSourceProperty); }
        set { SetValue(ItemsSourceProperty, value); }
    }
    public int X1Max {
        get { return (int)GetValue(X1MaxProperty); }
        set { SetValue(X1MaxProperty, value); }
    }
    public int X2Max {
        get { return (int)GetValue(X2MaxProperty); }
        set { SetValue(X2MaxProperty, value); }
    }
    #endregion
}
