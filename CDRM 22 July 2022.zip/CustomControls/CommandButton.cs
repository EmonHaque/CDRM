﻿class CommandButton : ActionButton
{
    Color disabledColor;
    public CommandButton() : base() {
        Focusable = true;
        normalColor = Colors.LightGray;
        brush.Color = normalColor;
        disabledColor = Colors.Gray;
        IsEnabledChanged += onIsEnabledChanged;
        Unloaded += onUnloaded;
    }

    void onUnloaded(object sender, RoutedEventArgs e) {
        IsEnabledChanged -= onIsEnabledChanged;
        Unloaded -= onUnloaded;
    }
    void onIsEnabledChanged(object sender, DependencyPropertyChangedEventArgs e) {
        if (IsEnabled) animateBrush(normalColor);
        else {
            Dispatcher.InvokeAsync(() => animateBrush(disabledColor), DispatcherPriority.Background);
        }
    }

    protected override void OnGotKeyboardFocus(KeyboardFocusChangedEventArgs e) => animateBrush(highlightColor);
    protected override void OnPreviewLostKeyboardFocus(KeyboardFocusChangedEventArgs e) => animateBrush(normalColor);
    protected override void OnMouseLeave(MouseEventArgs e) { if (IsEnabled) base.OnMouseLeave(e); }
    protected override void OnKeyUp(KeyEventArgs e) {
        if (e.Key != Key.Space) return;
        Command.Invoke();
    }
    protected override void OnKeyDown(KeyEventArgs e) {
        if (e.Key != Key.Space) return;
        animateBrush(downColor);
    }
}
