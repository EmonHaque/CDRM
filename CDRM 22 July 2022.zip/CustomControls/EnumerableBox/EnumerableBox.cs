﻿class EnumerableBox : ItemsControl
{
    List<EnumerableBoxItem> selectedBoxes;
    public bool IsMultiSelection { get; set; }

    public EnumerableBox() {
        selectedBoxes = new List<EnumerableBoxItem>();
        Template = new EnumerableBoxTemplate();
        ItemsPanel = new ItemsPanelTemplate(new FrameworkElementFactory(typeof(VirtualizingStackPanel)));
    }

    protected override bool IsItemItsOwnContainerOverride(object item) => false;
    protected override DependencyObject GetContainerForItemOverride() => new EnumerableBoxItem();
    protected override void PrepareContainerForItemOverride(DependencyObject element, object item) {
        var box = (EnumerableBoxItem)element;
        box.Content = item;
        box.Template = ItemTemplate is null ?
            ItemTemplateSelector.SelectTemplate(item, box) :
            ItemTemplate;
        box.AddHandler(EnumerableBoxItem.LoadedEvent, new RoutedEventHandler(onItemLoaded));
        box.AddHandler(EnumerableBoxItem.ClickedEvent, new RoutedEventHandler(onItemClicked));
    }
    protected override void ClearContainerForItemOverride(DependencyObject element, object item) {
        var box = (EnumerableBoxItem)element;
        box.RemoveHandler(EnumerableBoxItem.LoadedEvent, new RoutedEventHandler(onItemLoaded));
        box.RemoveHandler(EnumerableBoxItem.ClickedEvent, new RoutedEventHandler(onItemClicked));
        base.ClearContainerForItemOverride(element, item);
    }
    public override void OnApplyTemplate() {
        bool canContentScroll = GroupStyle.Count == 0;
        Resources.Add(typeof(ScrollViewer), new Style(typeof(ScrollViewer)) {
            Setters = {
                new Setter(ScrollViewer.HorizontalScrollBarVisibilityProperty, ScrollBarVisibility.Disabled),
                new Setter(ScrollViewer.VerticalScrollBarVisibilityProperty, ScrollBarVisibility.Auto),
                new Setter(ScrollViewer.TemplateProperty, new LedgerScrollTemplate(canContentScroll))
            }
        });
        Resources.Add(typeof(VirtualizingStackPanel), new Style(typeof(VirtualizingStackPanel)) {
            Setters = { new Setter(VirtualizingStackPanel.ScrollUnitProperty, ScrollUnit.Pixel) }
        });
        base.OnApplyTemplate();
    }

    void onItemLoaded(object sender, RoutedEventArgs e) {
        if (selectedBoxes.Count == 0) return;
        var loaded = (EnumerableBoxItem)sender;
        foreach (var item in selectedBoxes) {
            if (item.Content.Equals(loaded.Content)) {
                loaded.IsSelected = true;
                break;
            }
        }
    }
    void onItemClicked(object sender, RoutedEventArgs e) {
        var clicked = (EnumerableBoxItem)sender;
        if (!IsMultiSelection) {
            if (selectedBoxes.Count > 0) {
                if (selectedBoxes[0].Content.Equals(clicked.Content)) {
                    selectedBoxes[0].IsSelected = false;
                    selectedBoxes.Clear();
                    SelectedItem = null;
                    return;
                }
                else {
                    selectedBoxes[0].IsSelected = false;
                    selectedBoxes.Clear();
                }
            }
            clicked.IsSelected = true;
            SelectedItem = clicked.Content;
            selectedBoxes.Add(clicked);
        }
        else {
            if (selectedBoxes.Count > 0) {
                EnumerableBoxItem toBeRemoved = null;
                foreach (var item in selectedBoxes) {
                    if (item.Content.Equals(clicked.Content)) {
                        item.IsSelected = false;
                        toBeRemoved = item;
                        break;
                    }
                }
                if (toBeRemoved is not null) {
                    selectedBoxes.Remove(toBeRemoved);
                    SelectedItems = selectedBoxes.Select(x => x.Content);
                    return;
                }
            }
            clicked.IsSelected = true;
            SelectedItems = selectedBoxes.Select(x => x.Content);
            selectedBoxes.Add(clicked);
        }
        e.Handled = true;
    }

    #region DependencyProperties
    public static readonly DependencyProperty SelectedItemProperty;
    public static readonly DependencyProperty SelectedItemsProperty;

    static EnumerableBox() {
        SelectedItemProperty = DependencyProperty.Register("SelectedItem", typeof(object), typeof(EnumerableBox), new FrameworkPropertyMetadata() {
            BindsTwoWayByDefault = true,
            DefaultValue = null,
        });
        SelectedItemsProperty =
        DependencyProperty.Register("SelectedItems", typeof(IEnumerable<object>), typeof(EnumerableBox), new FrameworkPropertyMetadata() {
            BindsTwoWayByDefault = true,
            DefaultValue = null,
        });
    }

    public IEnumerable<object> SelectedItems {
        get { return (IEnumerable<object>)GetValue(SelectedItemsProperty); }
        set { SetValue(SelectedItemsProperty, value); }
    }
    public object SelectedItem {
        get { return (object)GetValue(SelectedItemProperty); }
        set { SetValue(SelectedItemProperty, value); }
    }
    #endregion
}