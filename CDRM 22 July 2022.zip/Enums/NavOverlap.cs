﻿enum NavOverlap
{
    None,
    Right,
    Left,
    Top, 
    Bottom
}
