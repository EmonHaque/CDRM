﻿class SiteReceipts : CardView
{
    public override string Header => "Site";
    public override string Icon => Icons.Cancel;
}
