﻿class PartyReceipts : CardView
{
    public override string Header => "Party";
    public override string Icon => Icons.Noncash;
}
