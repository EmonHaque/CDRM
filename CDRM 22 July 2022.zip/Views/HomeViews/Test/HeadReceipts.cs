﻿class HeadReceipts : CardView
{
    public override string Header => "Head";
    public override string Icon => Icons.Balance;
}
