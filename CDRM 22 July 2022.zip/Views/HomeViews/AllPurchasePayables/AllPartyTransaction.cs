﻿class AllPartyTransaction : AllPurchaseBase
{
    public override string Icon => Icons.Tenant;
    //public override string Header => "Party";

    protected override string searchHint => "Party";
    protected override AllPurchaseBaseVM vm => viewModel;
    AllPartyTransactionVM viewModel = new();
    ActionButton sortPayment, sortDue;
    public AllPartyTransaction() {
        secondRow.ColumnDefinitions.Add(new ColumnDefinition() { Width = GridLength.Auto });
        secondRow.ColumnDefinitions.Add(new ColumnDefinition() { Width = GridLength.Auto });
        sortPayment = new ActionButton() {
            ToolTip = "Payment",
            Margin = new Thickness(5, 0, 5, 0),
            Icon = Icons.SortSwap,
            Command = viewModel.SortPayment,
            VerticalAlignment = VerticalAlignment.Center
        };
        sortDue = new ActionButton() {
            ToolTip = "Due",
            Margin = new Thickness(5, 0, 5, 0),
            Icon = Icons.SortSwap,
            Command = viewModel.SortDue,
            VerticalAlignment = VerticalAlignment.Center
        };
        Grid.SetColumn(sortPayment, 2);
        Grid.SetColumn(sortDue, 3);
        secondRow.Children.Add(sortPayment);
        secondRow.Children.Add(sortDue);
    }
    
}
