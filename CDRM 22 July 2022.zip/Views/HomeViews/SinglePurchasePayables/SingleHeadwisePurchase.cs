﻿class SingleHeadwisePurchase : SinglePurchasePayables<Head>
{
    public override string Icon => Icons.ControlHead;

    SingleHeadwisePurchaseVM viewModel = new();
    PinChart pin = new();

    protected override SinglePurchasePayableBaseVM<Head> vm => viewModel;
    protected override string hint => "Head";
}
