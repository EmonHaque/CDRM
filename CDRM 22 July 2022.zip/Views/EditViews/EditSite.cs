﻿class EditSite : EditBase<Site>
{
    public override string Header => "Site";
    public override string Icon => Icons.Plot;

    EditSiteVM vm = new();
    EditSiteControl site = new();
    protected override IEdit<Site> viewModel => vm;
    protected override EditNameControl editElement => site;
}
