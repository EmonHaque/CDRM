﻿class EditHead : EditBase<Head>
{
    public override string Header => "Head";
    public override string Icon => Icons.ControlHead;

    EditHeadVM vm = new();
    EditNameControl name = new();
    protected override IEdit<Head> viewModel => vm;
    protected override EditNameControl editElement => name;
}
