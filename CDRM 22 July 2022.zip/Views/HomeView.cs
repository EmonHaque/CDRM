﻿class HomeView : View
{
    public override string Icon => Icons.Home;
    public override FrameworkElement container => grid;
    Grid grid;
    public HomeView() {

        var singlePurchase = new ViewContainer(NavPosition.TopRightVertical, NavOverlap.Right) {
            IconSize = 12,
            IconGap = 5,
            Children = {
                new SingleSitewisePurchase(),
                new SingleHeadwisePurchase(),
                new SinglePartyTransaction()
            }
        };
        var receiptVies = new ViewContainer(NavPosition.BottomRightVertical, NavOverlap.Right) {
            IconSize = 12,
            IconGap = 5,
            Children = {
                new SiteReceipts(),
                new PartyReceipts(),
                new HeadReceipts()
            }
        };
        var allPurchase = new ViewContainer(NavPosition.LeftCenter, NavOverlap.Left) {
            IsMarginLess = true,
            IconSize = 12,
            IconGap = 5,
            Children = {
                new AllSitewisePurchase(),
                new AllHeadwisePurchase(),
                new AllPartyTransaction()
            }
        };

        Grid.SetRow(receiptVies, 1);
        Grid.SetColumn(allPurchase, 1);
        Grid.SetRowSpan(allPurchase, 2);
        grid = new Grid() {
            RowDefinitions = {
                    new RowDefinition(),
                    new RowDefinition(),
                },
            ColumnDefinitions = {
                    new ColumnDefinition(),
                    new ColumnDefinition(),
                    new ColumnDefinition(),
                },
            Children = { singlePurchase, receiptVies, allPurchase }
        };
        AddVisualChild(grid);
    }
}
