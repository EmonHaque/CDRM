﻿class ViewContainer : Grid, IHaveIcon
{
    int selectedIndex, newIndex;
    bool isAnimating;
    NavPosition navPosition;
    NavOverlap overlap;
    List<View> containers;
    StackPanel navbar;
    DoubleAnimation getIn, getOut;

    public virtual string Icon { get; }
    public double IconSize { get; set; }
    public double IconGap { get; set; }
    public bool IsMarginLess { get; set; }
    public event Action Transitioned;

    public ViewContainer(NavPosition navPosition = NavPosition.BottomRightVertical, NavOverlap overlap = NavOverlap.None) {
        ClipToBounds = true;
        IconSize = 14;
        IconGap = 10;
        this.navPosition = navPosition;
        this.overlap = overlap;
        containers = new List<View>();
        var duration = TimeSpan.FromSeconds(1);
        var ease = new CubicEase() { EasingMode = EasingMode.EaseInOut };
        getIn = new DoubleAnimation() {
            To = 0,
            Duration = duration,
            EasingFunction = ease
        };
        getOut = new DoubleAnimation() {
            Duration = duration,
            EasingFunction = ease
        };
        addNavBar(navPosition);
        Loaded += onLoaded;
        Unloaded += onUnloaded;
    }

    void onLoaded(object sender, RoutedEventArgs e) {
        getOut.Completed += reset;
        addSpaceToNavButton();
    }
    void onUnloaded(object sender, RoutedEventArgs e) {
        Loaded -= onLoaded;
        Unloaded -= onUnloaded;
        getOut.Completed -= reset;
    }
    void addNavBar(NavPosition pos) {
        navbar = new StackPanel();
        var margin = Constants.CardMargin;
        switch (pos) {
            case NavPosition.TopLeftHorizontal:
            case NavPosition.TopRightHorizontal:
            case NavPosition.TopCenter:
                RowDefinitions.Add(new RowDefinition() { Height = GridLength.Auto });
                RowDefinitions.Add(new RowDefinition());
                navbar.Orientation = Orientation.Horizontal;
                navbar.Margin = new Thickness(margin, margin, margin, 0);
                break;
            case NavPosition.BottomLeftHorizontal:
            case NavPosition.BottomRightHorizontal:
            case NavPosition.BottomCenter:
                RowDefinitions.Add(new RowDefinition());
                RowDefinitions.Add(new RowDefinition() { Height = GridLength.Auto });
                navbar.Orientation = Orientation.Horizontal;
                navbar.Margin = new Thickness(margin, 0, margin, margin);
                SetRow(navbar, 1);
                break;
            case NavPosition.TopRightVertical:
            case NavPosition.BottomRightVertical:
            case NavPosition.RightCenter:
                ColumnDefinitions.Add(new ColumnDefinition());
                ColumnDefinitions.Add(new ColumnDefinition() { Width = GridLength.Auto });
                navbar.Margin = new Thickness(0, margin, margin, margin);
                SetColumn(navbar, 1);
                break;
            case NavPosition.TopLeftVertical:
            case NavPosition.BottomLeftVertical:
            case NavPosition.LeftCenter:
                ColumnDefinitions.Add(new ColumnDefinition() { Width = GridLength.Auto });
                ColumnDefinitions.Add(new ColumnDefinition());
                navbar.Margin = new Thickness(margin, margin, 0, margin);
                break;
        }
        switch (pos) {
            case NavPosition.TopRightHorizontal:
            case NavPosition.BottomRightHorizontal:
                navbar.HorizontalAlignment = HorizontalAlignment.Right;
                break;
            case NavPosition.TopCenter:
            case NavPosition.BottomCenter:
                navbar.HorizontalAlignment = HorizontalAlignment.Center;
                break;
            case NavPosition.BottomLeftVertical:
            case NavPosition.BottomRightVertical:
                navbar.VerticalAlignment = VerticalAlignment.Bottom;
                break;
            case NavPosition.RightCenter:
            case NavPosition.LeftCenter:
                navbar.VerticalAlignment = VerticalAlignment.Center;
                break;
        }
        Children.Add(navbar);
    }
    void addSpaceToNavButton() {
        int index = 0;
        int count = navbar.Children.Count;
        double halfGap = IconGap / 2d;
        switch (navPosition) {
            case NavPosition.TopLeftHorizontal:
            case NavPosition.TopRightHorizontal:
            case NavPosition.TopCenter:
            case NavPosition.BottomLeftHorizontal:
            case NavPosition.BottomRightHorizontal:
            case NavPosition.BottomCenter:
                foreach (TransitButton button in navbar.Children) {
                    index++;
                    if (index == 1) {
                        if (count > 1) {
                            button.Margin = new Thickness(0, 0, halfGap, 0);
                        }
                    }
                    else if (index == count) {
                        button.Margin = new Thickness(halfGap, 0, 0, 0);
                    }
                    else button.Margin = new Thickness(halfGap, 0, halfGap, 0);
                }
                break;
            case NavPosition.TopLeftVertical:
            case NavPosition.TopRightVertical:
            case NavPosition.BottomLeftVertical:
            case NavPosition.BottomRightVertical:
            case NavPosition.LeftCenter:
            case NavPosition.RightCenter:
                foreach (TransitButton button in navbar.Children) {
                    index++;
                    if (index == 1) {
                        if (count > 1) {
                            button.Margin = new Thickness(0, 0, 0, halfGap);
                        }
                    }
                    else if (index == count) {
                        button.Margin = new Thickness(0, halfGap, 0, 0);
                    }
                    else button.Margin = new Thickness(0, halfGap, 0, halfGap);
                }
                break;
        }

        if (overlap != NavOverlap.None) {
            var margin = Constants.CardMargin;
            switch (overlap) {
                case NavOverlap.Right:
                    Margin = new Thickness(0, 0, -navbar.ActualWidth / 2, 0);
                    navbar.Margin = new Thickness(0, margin, 0, margin);
                    break;
                case NavOverlap.Left:
                    Margin = new Thickness(-navbar.ActualWidth / 2, 0, 0, 0);
                    navbar.Margin = new Thickness(0, margin, 0, margin);
                    break;
                case NavOverlap.Top:
                    Margin = new Thickness(0, -navbar.ActualHeight / 2, 0, 0);
                    navbar.Margin = new Thickness(margin, 0, margin, 0);
                    break;
                case NavOverlap.Bottom:
                    Margin = new Thickness(0, 0, 0, -navbar.ActualHeight / 2);
                    navbar.Margin = new Thickness(margin, 0, margin, 0);
                    break;
            }
        }
        else {
            if (!IsMarginLess) return;
            var margin = Constants.CardMargin;
            switch (navPosition) {
                case NavPosition.TopLeftHorizontal:
                case NavPosition.TopRightHorizontal:
                case NavPosition.TopCenter:
                    navbar.Margin = new Thickness(margin, 0, margin, 0);
                    break;
                case NavPosition.BottomLeftHorizontal:
                case NavPosition.BottomRightHorizontal:
                case NavPosition.BottomCenter:
                    navbar.Margin = new Thickness(margin, 0, margin, 0);
                    break;
                case NavPosition.TopRightVertical:
                case NavPosition.BottomRightVertical:
                case NavPosition.RightCenter:
                    navbar.Margin = new Thickness(0, margin, 0, margin);
                    break;
                case NavPosition.TopLeftVertical:
                case NavPosition.BottomLeftVertical:
                case NavPosition.LeftCenter:
                    navbar.Margin = new Thickness(0, margin, 0, margin);
                    break;
            }
        }
    }
    void reset(object sender, EventArgs e) {
        containers[selectedIndex].Visibility = Visibility.Hidden;
        selectedIndex = newIndex;
        isAnimating = ((TransitButton)navbar.Children[selectedIndex]).isActing = false;
        Transitioned?.Invoke();
    }
    void go(int o) {
        var index = o;
        var oldIndex = selectedIndex;
        if (!isAnimating && index != oldIndex) {
            isAnimating = true;
            ((TransitButton)navbar.Children[index]).isActing = true;
            ((TransitButton)navbar.Children[index]).IsSelected = true;
            ((TransitButton)navbar.Children[selectedIndex]).IsSelected = false;

            newIndex = index;
            DependencyProperty property = null;
            switch (navPosition) {
                case NavPosition.TopRightVertical:
                case NavPosition.BottomRightVertical:
                case NavPosition.RightCenter:
                case NavPosition.TopLeftVertical:
                case NavPosition.BottomLeftVertical:
                case NavPosition.LeftCenter:
                    property = TranslateTransform.YProperty;
                    if (newIndex > oldIndex) {
                        getIn.From = ActualHeight;
                        getOut.To = -ActualHeight;
                    }
                    else {
                        getIn.From = -ActualHeight;
                        getOut.To = ActualHeight;
                    }
                    break;
                case NavPosition.TopLeftHorizontal:
                case NavPosition.TopRightHorizontal:
                case NavPosition.TopCenter:
                case NavPosition.BottomLeftHorizontal:
                case NavPosition.BottomRightHorizontal:
                case NavPosition.BottomCenter:
                    property = TranslateTransform.XProperty;
                    if (newIndex > oldIndex) {
                        getIn.From = ActualWidth;
                        getOut.To = -ActualWidth;
                    }
                    else {
                        getIn.From = -ActualWidth;
                        getOut.To = ActualWidth;
                    }
                    break;
            }
            containers[oldIndex].RenderTransform.BeginAnimation(property, getOut);
            containers[newIndex].RenderTransform.BeginAnimation(property, getIn);
            containers[newIndex].Visibility = Visibility.Visible;

            //if (navPosition == NavPosition.BottomRightVertical
            //    || navPosition == NavPosition.TopRightVertical
            //    || navPosition == NavPosition.TopLeftVertical
            //    || navPosition == NavPosition.BottomLeftVertical
            //    || navPosition == NavPosition.RightCenter
            //    || navPosition == NavPosition.LeftCenter) {
            //    if (newIndex > oldIndex) {
            //        getIn.From = ActualHeight;
            //        getOut.To = -ActualHeight;
            //    }
            //    else {
            //        getIn.From = -ActualHeight;
            //        getOut.To = ActualHeight;
            //    }
            //    containers[oldIndex].RenderTransform.BeginAnimation(TranslateTransform.YProperty, getOut);
            //    containers[newIndex].RenderTransform.BeginAnimation(TranslateTransform.YProperty, getIn);
            //}
            //else if (navPosition == NavPosition.BottomRightHorizontal 
            //    || navPosition == NavPosition.TopRightHorizontal
            //    || navPosition == NavPosition.TopLeftHorizontal
            //    || navPosition == NavPosition.BottomLeftHorizontal
            //    || navPosition == NavPosition.BottomCenter
            //    || navPosition == NavPosition.TopCenter) {
            //    if (newIndex > oldIndex) {
            //        getIn.From = ActualWidth;
            //        getOut.To = -ActualWidth;
            //    }
            //    else {
            //        getIn.From = -ActualWidth;
            //        getOut.To = ActualWidth;
            //    }
            //    containers[oldIndex].RenderTransform.BeginAnimation(TranslateTransform.XProperty, getOut);
            //    containers[newIndex].RenderTransform.BeginAnimation(TranslateTransform.XProperty, getIn);
            //}
            //containers[newIndex].Visibility = Visibility.Visible;
        }
    }
    protected override void OnVisualChildrenChanged(DependencyObject visualAdded, DependencyObject visualRemoved) {
        if (visualAdded is not View) {
            base.OnVisualChildrenChanged(visualAdded, visualRemoved);
            return;
        }
        var view = (View)visualAdded;
        view.RenderTransform = new TranslateTransform(0, 0);
        containers.Add(view);
        if (!containers.ElementAt(selectedIndex).Equals(view))
            view.Visibility = Visibility.Hidden;

        navbar.Children.Add(new TransitButton(IconSize) {
            Icon = view.Icon,
            Command = go,
            index = navbar.Children.Count,
            IsSelected = navbar.Children.Count == 0
        });

        switch (navPosition) {
            case NavPosition.TopLeftHorizontal:
            case NavPosition.TopRightHorizontal:
            case NavPosition.TopCenter:
                SetRow(view, 1);
                break;
            case NavPosition.TopLeftVertical:
            case NavPosition.BottomLeftVertical:
            case NavPosition.LeftCenter:
                SetColumn(view, 1);
                break;
        }
    }
}
