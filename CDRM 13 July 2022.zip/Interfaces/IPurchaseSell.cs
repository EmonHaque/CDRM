﻿interface IPurchaseSell
{
    double Purchase { get; set; }
    double Sell { get; set; }
}
