﻿class PathIcon : FrameworkElement
{
    Path path;
    public PathIcon() {
        path = new Path() {
            VerticalAlignment = VerticalAlignment.Center,
            Stretch = Stretch.Uniform,
            Width = 12,
            Height = 12,
            Fill = Brushes.LightGray
        };
        AddVisualChild(path);
    }
    protected override Size MeasureOverride(Size availableSize) {
        path.Measure(availableSize);
        return path.DesiredSize;
    }
    protected override Size ArrangeOverride(Size finalSize) {
        path.Arrange(new Rect(path.DesiredSize));
        return path.DesiredSize;
    }
    protected override Visual GetVisualChild(int index) => path;
    protected override int VisualChildrenCount => 1;

    public string Icon {
        get { return (string)GetValue(IconProperty); }
        set { SetValue(IconProperty, value); }
    }

    public static readonly DependencyProperty IconProperty =
        DependencyProperty.Register("Icon", typeof(string), typeof(PathIcon), new PropertyMetadata() {
            DefaultValue = null,
            PropertyChangedCallback = (d, e) => {
                var o = (PathIcon)d;
                o.path.Data = Geometry.Parse(e.NewValue.ToString());
            }
        });


}
