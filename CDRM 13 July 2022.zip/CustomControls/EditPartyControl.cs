﻿class EditPartyControl : EditSiteControl
{
    TextBlock phone;
    TextBox editedPhone;

    #region DependencyProperties
    public static readonly DependencyProperty PhoneProperty;
    public static readonly DependencyProperty EditedPhoneProperty;
    static EditPartyControl() {
        PhoneProperty = DependencyProperty.Register("Phone", typeof(string), typeof(EditPartyControl));
        EditedPhoneProperty = DependencyProperty.Register("EditedPhone", typeof(string), typeof(EditPartyControl), new FrameworkPropertyMetadata() {
            DefaultValue = null,
            BindsTwoWayByDefault = true
        });
    }
    public new string Phone {
        get { return (string)GetValue(PhoneProperty); }
        set { SetValue(PhoneProperty, value); }
    }
    public new string EditedPhone {
        get { return (string)GetValue(EditedPhoneProperty); }
        set { SetValue(EditedPhoneProperty, value); }
    }
    #endregion

    public EditPartyControl() : base() {
        phone = new TextBlock() {
            HorizontalAlignment = HorizontalAlignment.Center,
            TextAlignment = TextAlignment.Center,
            TextWrapping = TextWrapping.Wrap
        };
        editedPhone = new TextBox() {
            BorderThickness = new Thickness(0, 0, 0, 0.5),
            Visibility = Visibility.Collapsed
        };
        Children.Add(phone);
        Children.Add(editedPhone);

        phone.SetBinding(TextBlock.TextProperty, new Binding(nameof(Phone)) { Source = this });
        editedPhone.SetBinding(TextBox.TextProperty, new Binding(nameof(EditedPhone)) { Source = this, UpdateSourceTrigger = UpdateSourceTrigger.PropertyChanged });
    }

    protected override void setEdit() {
        base.setEdit();
        if (string.IsNullOrWhiteSpace(Phone)) return;
        editedPhone.Text = Phone;
        phone.Visibility = Visibility.Collapsed;
        editedPhone.Visibility = Visibility.Visible;
    }
    protected override void cancelEdit() {
        if (!EditedPhone.Equals(Phone)) EditedPhone = Phone;
        base.cancelEdit();
    }
    protected override void resetVisibility() {
        phone.Visibility = Visibility.Visible;
        editedPhone.Visibility = Visibility.Collapsed;
        base.resetVisibility();
    }
}
