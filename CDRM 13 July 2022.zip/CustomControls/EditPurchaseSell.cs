﻿class EditPurchaseSell : Grid
{
    double top, left, width, height;
    List<ValidationError> errors;
    DayPicker date;
    SuggestBox site, party, head, subHead, unit;
    TextBlock partyAddressBlock, partyPhoneBlock, siteAddressBlock;
    Run partyAddress, partyPhone, siteAddress;
    EditText amount, quantity, narration;
    MultiState isConstruction, isPurchase;
    ActionButton update;
    EntryPurchaseSellText originalEntry, entry;
    public EntryPurchaseSellText Entry {
        get { return entry; }
        set {
            entry = value;
            originalEntry = entry.Clone();
            DataContext = value;
        }
    }
    public event Action<IHaveTitle> Updated;

    public EditPurchaseSell() {
        date = new DayPicker() {
            Hint = "Date",
            DateFormat = "dd/MM/yyyy"
        };
        isPurchase = new MultiState() {
            Icons = new string[] { Icons.Purchase, Icons.Sell },
            Texts = new string[] { "Purchase", "Sell" },
            IsIconInfront = true,
            Margin = new Thickness(5, 5, 0, 0),
            VerticalAlignment = VerticalAlignment.Center
        };
        isConstruction = new MultiState() {
            Icons = new string[] { Icons.Construction, Icons.Development, Icons.Repair, Icons.Maintenance },
            Texts = new string[] { "Construction", "Development", "Repair", "Maintenance" },
            IsIconInfront = true,
            Margin = new Thickness(5, 5, 5, 0),
            VerticalAlignment = VerticalAlignment.Center
        };
        amount = new EditText() {
            Icon = Icons.Amount,
            Hint = "Amount"
        };
        Grid.SetColumn(isPurchase, 1);
        Grid.SetColumn(isConstruction, 2);
        Grid.SetColumn(amount, 3);
        var dateDueGrid = new Grid() {
            ColumnDefinitions = {
                new ColumnDefinition(){ Width = new GridLength(2, GridUnitType.Star)},
                new ColumnDefinition(),
                new ColumnDefinition(),
                new ColumnDefinition(){ Width = new GridLength(1.55, GridUnitType.Star)}
            },
            Children = { date, isPurchase, isConstruction, amount }
        };
        site = new SuggestBox() {
            IsRequired = true,
            Icon = Icons.Plot,
            Hint = "Site",
            SuggestionSource = AppData.sites
        };
        party = new SuggestBox() {
            IsRequired = true,
            Icon = Icons.Tenant,
            Hint = "Party",
            SuggestionSource = AppData.parties
        };
        partyAddress = new Run();
        partyPhone = new Run();
        partyAddressBlock = new TextBlock() {
            Margin = new Thickness(5, 5, 0, 5),
            Inlines = { "Address: ", partyAddress }
        };
        partyPhoneBlock = new TextBlock() {
            Margin = new Thickness(5, 5, 0, 10),
            Inlines = { "Phone: ", partyPhone }
        };
        siteAddress = new Run();
        siteAddressBlock = new TextBlock() {
            Margin = new Thickness(5, 5, 0, 10),
            Inlines = { "Address: ", siteAddress }
        };
        Grid.SetRow(partyAddressBlock, 1);
        Grid.SetRow(partyPhoneBlock, 2);
        Grid.SetRow(site, 3);
        Grid.SetRow(siteAddressBlock, 4);
        var partySiteGrid = new Grid() {
            RowDefinitions = {
                new RowDefinition(){Height = GridLength.Auto },
                new RowDefinition(){Height = GridLength.Auto },
                new RowDefinition(){Height = GridLength.Auto },
                new RowDefinition(){Height = GridLength.Auto },
                new RowDefinition(){Height = GridLength.Auto }
            },
            Children = { party, partyAddressBlock, partyPhoneBlock, site, siteAddressBlock }
        };
        head = new SuggestBox() {
            IsRequired = true,
            Icon = Icons.ControlHead,
            Hint = "Head",
            SuggestionSource = AppData.heads
        };
        subHead = new SuggestBox() {
            Icon = Icons.Head,
            Hint = "Subhead",
            SuggestionSource = AppData.subHeads
        };
        quantity = new EditText() {
            Icon = Icons.Amount,
            Hint = "Quantity"
        };
        unit = new SuggestBox() {
            Icon = Icons.Accounts,
            Hint = "Unit",
            SuggestionSource = AppData.units
        };
        Grid.SetColumn(subHead, 1);
        Grid.SetRow(quantity, 1);
        Grid.SetRow(unit, 1);
        Grid.SetColumn(unit, 1);
        var headQuantityGrid = new Grid() {
            ColumnDefinitions = {
                new ColumnDefinition(),
                new ColumnDefinition()
            },
            RowDefinitions = {

                new RowDefinition(){Height = GridLength.Auto},
                new RowDefinition(){Height = GridLength.Auto}
            },
            Children = { head, subHead, quantity, unit }
        };
        narration = new EditText() {
            Margin = new Thickness(0, 15, 0, 0),
            IsMultiline = true,
            Icon = Icons.Description,
            Hint = "Narration"
        };
        update = new ActionButton() {
            Icon = Icons.Checked,
            ToolTip = "Update",
            Command = onUpdateEntry,
            Width = 14,
            Height = 14,
            Margin = new Thickness(2, 5, 0, 0),
            HorizontalAlignment = HorizontalAlignment.Left
        };
        RowDefinitions.Add(new RowDefinition() { Height = GridLength.Auto });
        RowDefinitions.Add(new RowDefinition() { Height = GridLength.Auto });
        RowDefinitions.Add(new RowDefinition() { Height = GridLength.Auto });
        RowDefinitions.Add(new RowDefinition());
        RowDefinitions.Add(new RowDefinition() { Height = GridLength.Auto });

        SetRow(partySiteGrid, 1);
        SetRow(headQuantityGrid, 2);
        SetRow(narration, 3);
        SetRow(update, 4);
        Children.Add(dateDueGrid);
        Children.Add(partySiteGrid);
        Children.Add(headQuantityGrid);
        Children.Add(narration);
        Children.Add(update);
        bind();
    }

    void bind() {
        DataContext = Entry;
        date.SetBinding(DayPicker.SelectedDateProperty, new Binding(nameof(Entry.Date)) { Mode = BindingMode.TwoWay });
        site.SetBinding(SuggestBox.TextProperty, new Binding(nameof(Entry.Site)) { Mode = BindingMode.TwoWay });
        party.SetBinding(SuggestBox.TextProperty, new Binding(nameof(Entry.Party)) { Mode = BindingMode.TwoWay });
        head.SetBinding(SuggestBox.TextProperty, new Binding(nameof(Entry.Head)) { Mode = BindingMode.TwoWay });
        subHead.SetBinding(SuggestBox.TextProperty, new Binding(nameof(Entry.SubHead)) { Mode = BindingMode.TwoWay });
        unit.SetBinding(SuggestBox.TextProperty, new Binding(nameof(Entry.Unit)) { Mode = BindingMode.TwoWay });
        quantity.SetBinding(EditText.TextProperty, new Binding(nameof(Entry.Quantity)) { Mode = BindingMode.TwoWay });
        amount.SetBinding(EditText.TextProperty, new Binding(nameof(Entry.Amount)) { Mode = BindingMode.TwoWay });
        narration.SetBinding(EditText.TextProperty, new Binding(nameof(Entry.Narration)) { Mode = BindingMode.TwoWay });
        isPurchase.SetBinding(MultiState.StateProperty, new Binding(nameof(Entry.IsSell)) { Mode = BindingMode.TwoWay });
        isConstruction.SetBinding(MultiState.StateProperty, new Binding(nameof(Entry.IsConstruction)) { Mode = BindingMode.TwoWay });
    }
    void onUpdateEntry() {
        if (!isValid()) {
            updatePosition();
            var errorDialog = new ErrorDialog(left, top, width, height, errors);
            errorDialog.ShowDialog();
            return;
        }
        if (isEqual()) return;
        if (!doesExist()) {
            updatePosition();
            var confirmDialog = new ConfirmCreationDialog(left, top, width, height, errors);
            var result = confirmDialog.ShowDialog();
            if (!result.HasValue) return;
            if (!result.Value) return;

            foreach (var e in errors) {
                switch (e.Head) {
                    case nameof(entry.Site): {
                            var dialog = new CreateSiteDialog(left, top, width, height, entry.Site);
                            dialog.ShowDialog();
                            var site = new Site() {
                                Name = entry.Site.Trim(),
                                Address = dialog.GetAddress().Trim()
                            };
                            AppData.InsertSite(site);
                        }
                        break;
                    case nameof(entry.Party): {
                            var dialog = new CreatePartyDialog(left, top, width, height, entry.Party);
                            dialog.ShowDialog();
                            var (address, phone) = dialog.GetAddressAndPhone();
                            var party = new Party() {
                                Name = entry.Party.Trim(),
                                Address = address.Trim(),
                                Phone = phone?.Trim()
                            };
                            AppData.InsertParty(party);
                        }
                        break;
                    case nameof(entry.Head): AppData.InsertHead(entry.Head.Trim()); break;
                    case nameof(entry.SubHead): AppData.InsertSubHead(entry.SubHead.Trim()); break;
                    case nameof(entry.Unit): AppData.InsertUnit(entry.Unit.Trim()); break;
                }
            }
        }
        Updated?.Invoke(entry);
        originalEntry = entry.Clone();
    }
    bool isValid() {
        bool isValid = true;
        errors = new List<ValidationError>();

        if (entry.Date is null) {
            errors.Add(new ValidationError() {
                Head = nameof(entry.Date),
                Error = Constants.CannotBeEmpty
            });
            isValid = false;
        }
        if (string.IsNullOrWhiteSpace(entry.Site)) {
            errors.Add(new ValidationError() {
                Head = nameof(entry.Site),
                Error = Constants.CannotBeEmpty
            });
            isValid = false;
        }
        if (string.IsNullOrWhiteSpace(entry.Party)) {
            errors.Add(new ValidationError() {
                Head = nameof(entry.Party),
                Error = Constants.CannotBeEmpty
            });
            isValid = false;
        }
        if (string.IsNullOrWhiteSpace(entry.Head)) {
            errors.Add(new ValidationError() {
                Head = nameof(entry.Head),
                Error = Constants.CannotBeEmpty
            });
            isValid = false;
        }
        if (string.IsNullOrWhiteSpace(entry.Amount)) {
            errors.Add(new ValidationError() {
                Head = nameof(entry.Amount),
                Error = Constants.CannotBeEmpty
            });
            isValid = false;
        }
        else {
            double x;
            if (!double.TryParse(entry.Amount, out x)) {
                errors.Add(new ValidationError() {
                    Head = nameof(entry.Amount),
                    Error = Constants.IsntValid
                });
                isValid = false;
            }
            else if (x <= 0) {
                errors.Add(new ValidationError() {
                    Head = nameof(entry.Amount),
                    Error = Constants.MustBePositive
                });
                isValid = false;
            }
        }
        if (!string.IsNullOrWhiteSpace(entry.Quantity)) {
            double x;
            if (!double.TryParse(entry.Quantity, out x)) {
                errors.Add(new ValidationError() {
                    Head = nameof(entry.Quantity),
                    Error = Constants.IsntValid
                });
                isValid = false;
            }
            else if (x <= 0) {
                errors.Add(new ValidationError() {
                    Head = nameof(entry.Quantity),
                    Error = Constants.MustBePositive
                });
                isValid = false;
            }

            if (string.IsNullOrWhiteSpace(entry.Unit)) {
                errors.Add(new ValidationError() {
                    Head = nameof(entry.Unit),
                    Error = Constants.CannotBeEmpty
                });
                isValid = false;
            }
        }
        return isValid;
    }
    bool isEqual() {
        if (originalEntry.IsSell != entry.IsSell) {
            if (originalEntry.IsSell == 0) entry.Title = "Sell";
            else entry.Title = "Purchase";
            return false;
        }
        if (originalEntry.Date != entry.Date) return false;
        if (originalEntry.IsConstruction != entry.IsConstruction) return false;
        if (!originalEntry.Site.Equals(entry.Site, StringComparison.InvariantCultureIgnoreCase)) return false;
        if (!originalEntry.Party.Equals(entry.Party, StringComparison.InvariantCultureIgnoreCase)) return false;
        if (!originalEntry.Head.Equals(entry.Head, StringComparison.InvariantCultureIgnoreCase)) return false;
        if (!originalEntry.SubHead.Equals(entry.SubHead, StringComparison.InvariantCultureIgnoreCase)) return false;
        if (!originalEntry.Unit.Equals(entry.Unit, StringComparison.InvariantCultureIgnoreCase)) return false;
        if (!originalEntry.Narration.Equals(entry.Narration, StringComparison.InvariantCultureIgnoreCase)) return false;

        double originalAmount, editedAmount;
        double.TryParse(originalEntry.Amount, out originalAmount);
        double.TryParse(entry.Amount, out editedAmount);
        if (originalAmount != editedAmount) return false;

        double originalQuantity, editedQuantity;
        double.TryParse(originalEntry.Quantity, out originalQuantity);
        double.TryParse(entry.Quantity, out editedQuantity);
        if (originalQuantity != editedQuantity) return false;

        return true;
    }
    bool doesExist() {
        bool doesExist = true;
        errors = new List<ValidationError>();
        if (!AppData.HasSite(entry.Site)) {
            errors.Add(new ValidationError() {
                Head = nameof(entry.Site),
                Error = Constants.DoesntExist
            });
            doesExist = false;
        }
        if (!AppData.HasParty(entry.Party)) {
            errors.Add(new ValidationError() {
                Head = nameof(entry.Party),
                Error = Constants.DoesntExist
            });
            doesExist = false;
        }
        if (!AppData.HasHead(entry.Head)) {
            errors.Add(new ValidationError() {
                Head = nameof(entry.Head),
                Error = Constants.DoesntExist
            });
            doesExist = false;
        }
        if (!string.IsNullOrWhiteSpace(entry.SubHead)) {
            if (!AppData.HasSubHead(entry.SubHead)) {
                errors.Add(new ValidationError() {
                    Head = nameof(entry.SubHead),
                    Error = Constants.DoesntExist
                });
                doesExist = false;
            }
        }
        if (!string.IsNullOrWhiteSpace(entry.Quantity)) {
            if (!AppData.HasUnit(entry.Unit)) {
                errors.Add(new ValidationError() {
                    Head = nameof(entry.Unit),
                    Error = Constants.DoesntExist
                });
                doesExist = false;
            }
        }
        return doesExist;
    }
    void updatePosition() {
        var position = PointToScreen(new Point(0, 0));
        var dpi = VisualTreeHelper.GetDpi(this);
        position.X /= dpi.DpiScaleX;
        position.Y /= dpi.DpiScaleY;

        left = position.X - 7;
        top = position.Y - 5;
        width = ActualWidth + 14;
        height = ActualHeight + 10;
    }
}
