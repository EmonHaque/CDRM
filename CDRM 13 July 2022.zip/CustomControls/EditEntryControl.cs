﻿class EditEntryControl : Grid
{
    EditReceiptPayment receiptPayment;
    EditPurchaseSell purchaseSell;

    #region DependencyProperties
    public static readonly DependencyProperty EntryProperty;
    public static readonly DependencyProperty EntryEditedProperty;
    static EditEntryControl() {
        EntryProperty = DependencyProperty.Register("Entry", typeof(IHaveTitle), typeof(EditEntryControl),
            new PropertyMetadata() {
                DefaultValue = null,
                PropertyChangedCallback = (d, e) => {
                    var o = (EditEntryControl)d;
                    if (e.NewValue is null) {
                        o.purchaseSell.Visibility = Visibility.Hidden;
                        o.receiptPayment.Visibility = Visibility.Hidden;
                        return;
                    }
                    if (e.NewValue is EntryPurchaseSellText) {
                        o.receiptPayment.Visibility = Visibility.Hidden;
                        o.purchaseSell.Visibility = Visibility.Visible;
                        o.purchaseSell.Entry = (EntryPurchaseSellText)e.NewValue;
                    }
                    else {
                        o.purchaseSell.Visibility = Visibility.Hidden;
                        o.receiptPayment.Visibility = Visibility.Visible;
                        o.receiptPayment.Entry = (EntryReceiptPaymentText)e.NewValue;
                    }
                }
            });

        EntryEditedProperty = DependencyProperty.Register("EntryEdited", typeof(IHaveTitle), typeof(EditEntryControl));
    }
    public IHaveTitle Entry {
        get { return (IHaveTitle)GetValue(EntryProperty); }
        set { SetValue(EntryProperty, value); }
    }
    public IHaveTitle EntryEdited {
        get { return (IHaveTitle)GetValue(EntryEditedProperty); }
        set { SetValue(EntryEditedProperty, value); }
    }
    #endregion

    public EditEntryControl() {
        receiptPayment = new EditReceiptPayment();
        purchaseSell = new EditPurchaseSell();
        Children.Add(receiptPayment);
        Children.Add(purchaseSell);
        purchaseSell.Visibility = Visibility.Hidden;
        receiptPayment.Visibility = Visibility.Hidden;
        Loaded += onLoaded;
        Unloaded += onUnloaded;

    }

    void onLoaded(object sender, RoutedEventArgs e) {
        receiptPayment.Updated += onUpdate;
        purchaseSell.Updated += onUpdate;
    }
    void onUnloaded(object sender, RoutedEventArgs e) {
        receiptPayment.Updated -= onUpdate;
        purchaseSell.Updated -= onUpdate;
    }
    void onUpdate(IHaveTitle o) => EntryEdited = o;
}
