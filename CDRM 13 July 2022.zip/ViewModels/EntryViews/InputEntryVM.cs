﻿class InputEntryVM : Notifiable
{
    EntryInsert entry;
    List<ValidationError> errors;
    public double Top { get; set; }
    public double Left { get; set; }
    public double Width { get; set; }
    public double Height { get; set; }

    public TransactionType TransactionType { get; set; }
    public EntryPurchaseSellText PurchaseSell { get; set; }
    public EntryReceiptPaymentText ReceiptPayment { get; set; }
    public ObservableCollection<EntryReceiptPayment> ReceiptPayments { get; set; }
    public Action<EntryReceiptPayment> RemoveReceiptPayment { get; set; }
    public static event Action<EntryInsert> EntryRequested;

    public InputEntryVM() {
        ReceiptPayments = new ObservableCollection<EntryReceiptPayment>();
        PurchaseSell = new EntryPurchaseSellText() { Date = DateTime.Today };
        ReceiptPayment = new EntryReceiptPaymentText();
        RemoveReceiptPayment = removeReceiptPayment;
    }

    public void AddReceiptPayment() {
        if (!isReceiptPaymentValid()) {
            var errorDialog = new ErrorDialog(Left, Top, Width, Height, errors);
            errorDialog.ShowDialog();
            return;
        }
        if (TransactionType == TransactionType.Payment || TransactionType == TransactionType.Receipt) {
            if (!doesExist(PurchaseSell.Party, ReceiptPayment.Head)) {
                var confirmDialog = new ConfirmCreationDialog(Left, Top, Width, Height, errors);
                var result = confirmDialog.ShowDialog();
                if (!result.HasValue) return;
                if (!result.Value) return;
            }
        }
        else {
            if (!doesExist(PurchaseSell.Party)) {
                var confirmDialog = new ConfirmCreationDialog(Left, Top, Width, Height, errors);
                var result = confirmDialog.ShowDialog();
                if (!result.HasValue) return;
                if (!result.Value) return;
            }
        }

        foreach (var e in errors) {
            switch (e.Head) {
                case "Head": AppData.InsertHead(ReceiptPayment.Head.Trim()); break;
                case "Party": {
                        var dialog = new CreatePartyDialog(Left, Top, Width, Height, PurchaseSell.Party);
                        dialog.ShowDialog();
                        var (address, phone) = dialog.GetAddressAndPhone();
                        var party = new Party() {
                            Name = PurchaseSell.Party.Trim(),
                            Address = address.Trim(),
                            Phone = phone?.Trim()
                        };
                        AppData.InsertParty(party);
                    }
                    break;
            }
        }

        var entry = new EntryReceiptPayment() {
            Date = PurchaseSell.Date.Value.ToString("yyyy-MM-dd"),
            IsCash = ReceiptPayment.IsCash,
            PartyId = AppData.GetParty().Id,
            Amount = double.Parse(ReceiptPayment.Amount),
            Narration = PurchaseSell.Narration?.Trim()
        };

        if (TransactionType == TransactionType.Payment) {
            entry.HeadId = AppData.GetHead().Id;
            entry.IsReceipt = 0;
        }
        else if (TransactionType == TransactionType.Receipt) {
            entry.HeadId = AppData.GetHead().Id;
            entry.IsReceipt = 1;
        }
        else if (TransactionType == TransactionType.Sell) {
            entry.HeadId = AppData.heads.First(x => x.Name.Equals("Receivable")).Id;
            entry.IsReceipt = 1;
        }
        else if (TransactionType == TransactionType.Purchase) {
            entry.HeadId = AppData.heads.First(x => x.Name.Equals("Payable")).Id;
            entry.IsReceipt = 0;
        }

        ReceiptPayments.Add(entry);

        PurchaseSell.Narration = "";
        ReceiptPayment = new EntryReceiptPaymentText() { IsCash = entry.IsCash };
        OnPropertyChanged(nameof(ReceiptPayment));
        PurchaseSell.OnPropertyChanged(nameof(PurchaseSell.Narration));
    }
    public void removeReceiptPayment(object o) {
        var e = (EntryReceiptPayment)o;
        ReceiptPayments.Remove(e);
    }
    public void AddEntry() {
        if (TransactionType == TransactionType.Purchase 
            || TransactionType == TransactionType.Sell) {
            addPurchaseSell();
        }
        else {
            entry = new EntryInsert() {
                Date = PurchaseSell.Date.Value.ToString("yyyy-MM-dd"),
                SiteId = TransactionType == TransactionType.Payment ? int.MaxValue : int.MaxValue - 1,
                IsTopLevel = false
            };
            foreach (var item in ReceiptPayments) {
                entry.ReceiptPayments.Add(item);
            }
            EntryRequested?.Invoke(entry);
            ReceiptPayments.Clear();
        }
    }

    void addPurchaseSell() {
        if (!isValid()) {
            var errorDialog = new ErrorDialog(Left, Top, Width, Height, errors);
            errorDialog.ShowDialog();
            return;
        }
        if (!doesExist()) {
            var confirmDialog = new ConfirmCreationDialog(Left, Top, Width, Height, errors);
            var result = confirmDialog.ShowDialog();
            if (!result.HasValue) return;
            if (!result.Value) return;

            foreach (var e in errors) {
                switch (e.Head) {
                    case nameof(PurchaseSell.Site): {
                            var dialog = new CreateSiteDialog(Left, Top, Width, Height, PurchaseSell.Site);
                            dialog.ShowDialog();
                            var site = new Site() {
                                Name = PurchaseSell.Site.Trim(),
                                Address = dialog.GetAddress().Trim()
                            };
                            AppData.InsertSite(site);
                        }
                        break;
                    case nameof(PurchaseSell.Party): {
                            var dialog = new CreatePartyDialog(Left, Top, Width, Height, PurchaseSell.Party);
                            dialog.ShowDialog();
                            var (address, phone) = dialog.GetAddressAndPhone();
                            var party = new Party() {
                                Name = PurchaseSell.Party.Trim(),
                                Address = address.Trim(),
                                Phone = phone?.Trim()
                            };
                            AppData.InsertParty(party);
                        }
                        break;
                    case nameof(PurchaseSell.Head): AppData.InsertHead(PurchaseSell.Head.Trim()); break;
                    case nameof(PurchaseSell.SubHead): AppData.InsertSubHead(PurchaseSell.SubHead.Trim()); break;
                    case nameof(PurchaseSell.Unit): AppData.InsertUnit(PurchaseSell.Unit.Trim()); break;
                }
            }
        }
        entry = new EntryInsert() {
            Date = PurchaseSell.Date.Value.ToString("yyyy-MM-dd"),
            IsSell = (byte)TransactionType,
            IsConstruction = PurchaseSell.IsConstruction,
            SiteId = AppData.GetSite().Id,
            PartyId = AppData.GetParty().Id,
            HeadId = AppData.GetHead().Id,
            Amount = double.Parse(PurchaseSell.Amount),
            IsTopLevel = true,
            Narration = PurchaseSell.Narration?.Trim()
        };
        if (!string.IsNullOrWhiteSpace(PurchaseSell.SubHead)) entry.SubHeadId = AppData.GetSubHead().Id;
        if (!string.IsNullOrWhiteSpace(PurchaseSell.Quantity)) {
            entry.Quantity = double.Parse(PurchaseSell.Quantity);
            entry.UnitId = AppData.GetUnit().Id;
        }
        foreach (var item in ReceiptPayments) {
            entry.ReceiptPayments.Add(item);
        }
        EntryRequested?.Invoke(entry);
        PurchaseSell = new EntryPurchaseSellText() { Date = DateTime.Today };
        OnPropertyChanged(nameof(PurchaseSell));
        ReceiptPayments.Clear();
    }
    bool isReceiptPaymentValid() {
        bool isValid = true;
        errors = new List<ValidationError>();
        if (PurchaseSell.Date is null) {
            errors.Add(new ValidationError() {
                Head = nameof(PurchaseSell.Date),
                Error = Constants.CannotBeEmpty
            });
            isValid = false;
        }
        if (string.IsNullOrWhiteSpace(PurchaseSell.Party)) {
            errors.Add(new ValidationError() {
                Head = nameof(PurchaseSell.Party),
                Error = Constants.CannotBeEmpty
            });
            isValid = false;
        }
        if (TransactionType == TransactionType.Payment || TransactionType == TransactionType.Receipt) {
            if (string.IsNullOrWhiteSpace(ReceiptPayment.Head)) {
                errors.Add(new ValidationError() {
                    Head = nameof(ReceiptPayment.Head),
                    Error = Constants.CannotBeEmpty
                });
                isValid = false;
            }
        }
        if (string.IsNullOrWhiteSpace(ReceiptPayment.Amount)) {
            errors.Add(new ValidationError() {
                Head = nameof(ReceiptPayment.Amount),
                Error = Constants.CannotBeEmpty
            });
            isValid = false;
        }
        return isValid;
    }
    bool isValid() {
        bool isValid = true;
        errors = new List<ValidationError>();

        if (PurchaseSell.Date is null) {
            errors.Add(new ValidationError() {
                Head = nameof(PurchaseSell.Date),
                Error = Constants.CannotBeEmpty
            });
            isValid = false;
        }
        if (string.IsNullOrWhiteSpace(PurchaseSell.Site)) {
            errors.Add(new ValidationError() {
                Head = nameof(PurchaseSell.Site),
                Error = Constants.CannotBeEmpty
            });
            isValid = false;
        }
        if (string.IsNullOrWhiteSpace(PurchaseSell.Party)) {
            errors.Add(new ValidationError() {
                Head = nameof(PurchaseSell.Party),
                Error = Constants.CannotBeEmpty
            });
            isValid = false;
        }
        if (string.IsNullOrWhiteSpace(PurchaseSell.Head)) {
            errors.Add(new ValidationError() {
                Head = nameof(PurchaseSell.Head),
                Error = Constants.CannotBeEmpty
            });
            isValid = false;
        }
        if (string.IsNullOrWhiteSpace(PurchaseSell.Amount)) {
            errors.Add(new ValidationError() {
                Head = nameof(PurchaseSell.Amount),
                Error = Constants.CannotBeEmpty
            });
            isValid = false;
        }
        else {
            double x;
            if (!double.TryParse(PurchaseSell.Amount, out x)) {
                errors.Add(new ValidationError() {
                    Head = nameof(PurchaseSell.Amount),
                    Error = Constants.IsntValid
                });
                isValid = false;
            }
            else if (x <= 0) {
                errors.Add(new ValidationError() {
                    Head = nameof(PurchaseSell.Amount),
                    Error = Constants.MustBePositive
                });
                isValid = false;
            }
        }
        if (!string.IsNullOrWhiteSpace(PurchaseSell.Quantity)) {
            double x;
            if (!double.TryParse(PurchaseSell.Quantity, out x)) {
                errors.Add(new ValidationError() {
                    Head = nameof(PurchaseSell.Quantity),
                    Error = Constants.IsntValid
                });
                isValid = false;
            }
            else if (x <= 0) {
                errors.Add(new ValidationError() {
                    Head = nameof(PurchaseSell.Quantity),
                    Error = Constants.MustBePositive
                });
                isValid = false;
            }

            if (string.IsNullOrWhiteSpace(PurchaseSell.Unit)) {
                errors.Add(new ValidationError() {
                    Head = nameof(PurchaseSell.Unit),
                    Error = Constants.CannotBeEmpty
                });
                isValid = false;
            }
        }
        return isValid;
    }
    bool doesExist(string party) {
        bool doesExist = true;
        if (!AppData.HasParty(party)) {
            errors.Add(new ValidationError() {
                Head = "Party",
                Error = Constants.DoesntExist
            });
            doesExist = false;
        }
        return doesExist;
    }
    bool doesExist(string party, string head) {
        bool doesExist = true;
        if (!AppData.HasParty(party)) {
            errors.Add(new ValidationError() {
                Head = "Party",
                Error = Constants.DoesntExist
            });
            doesExist = false;
        }
        if (!AppData.HasHead(head)) {
            errors.Add(new ValidationError() {
                Head = "Head",
                Error = Constants.DoesntExist
            });
            doesExist = false;
        }
        return doesExist;
    }
    bool doesExist() {
        bool doesExist = true;
        errors = new List<ValidationError>();
        if (!AppData.HasSite(PurchaseSell.Site)) {
            errors.Add(new ValidationError() {
                Head = nameof(PurchaseSell.Site),
                Error = Constants.DoesntExist
            });
            doesExist = false;
        }
        if (!AppData.HasParty(PurchaseSell.Party)) {
            errors.Add(new ValidationError() {
                Head = nameof(PurchaseSell.Party),
                Error = Constants.DoesntExist
            });
            doesExist = false;
        }
        if (!AppData.HasHead(PurchaseSell.Head)) {
            errors.Add(new ValidationError() {
                Head = nameof(PurchaseSell.Head),
                Error = Constants.DoesntExist
            });
            doesExist = false;
        }
        if (!string.IsNullOrWhiteSpace(PurchaseSell.SubHead)) {
            if (!AppData.HasSubHead(PurchaseSell.SubHead)) {
                errors.Add(new ValidationError() {
                    Head = nameof(PurchaseSell.SubHead),
                    Error = Constants.DoesntExist
                });
                doesExist = false;
            }
        }
        if (!string.IsNullOrWhiteSpace(PurchaseSell.Quantity)) {
            if (!AppData.HasUnit(PurchaseSell.Unit)) {
                errors.Add(new ValidationError() {
                    Head = nameof(PurchaseSell.Unit),
                    Error = Constants.DoesntExist
                });
                doesExist = false;
            }
        }
        return doesExist;
    }
}
