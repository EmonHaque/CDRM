﻿class ListEntriesVM : Notifiable
{
    List<EntryInsert> original;
    ObservableCollection<EntryInsert> entries;

    string status;
    public string Status {
        get { return status; }
        set { status = value; OnPropertyChanged(nameof(Status)); }
    }
    public bool CanUpdate { get; set; }
    public ICollectionView Entries { get; set; }
    public Action<EntryInsert> RemoveEntry { get; set; }

    public ListEntriesVM() {
        original = new List<EntryInsert>();
        entries = new ObservableCollection<EntryInsert>();
        Entries = new CollectionViewSource() {
            Source = entries,
            IsLiveGroupingRequested = true,
            LiveGroupingProperties = { nameof(EntryPurchaseSell.SiteId) }
        }.View;
        Entries.GroupDescriptions.Add(new PropertyGroupDescription(nameof(EntryPurchaseSell.SiteId)));
        RemoveEntry = onRemoveEntry;
        InputEntryVM.EntryRequested += onEntryRequest;
    }
    public void Insert() {
        if (!CanUpdate) return;
        CanUpdate = false;
        OnPropertyChanged(nameof(CanUpdate));
        new Thread(insert) { IsBackground = true }.Start();
    }
    void insert() {
        Status = "Getting commands ready ...";
        Thread.Sleep(500);
        var commands = getCommands();
        Status = "Inserting into database ...";
        Thread.Sleep(500);
        if (!SQL.Transaction(commands)) {
            Status = "Error inserting records in database ...";
            Thread.Sleep(500);
        }
        else {
            Status = $"Finished inserting {commands.Count} records in database";
            Thread.Sleep(500);
        }
        App.Current.Dispatcher.InvokeAsync(() => entries.Clear(), DispatcherPriority.Background);
    }
    List<KeyValuePair<string, List<SqliteParameter>>> getCommands() {
        int count = 1;
        List<KeyValuePair<string, List<SqliteParameter>>> commands = new();
        foreach (var e in original) {
            Status = $"Preparing {count++}/{original.Count} commands";

            if (e.IsTopLevel) {
                object subHead = e.SubHeadId > 0 ? e.SubHeadId : DBNull.Value;
                object unit = e.UnitId > 0 ? e.UnitId : DBNull.Value;
                object quantity = e.Quantity > 0 ? e.Quantity : DBNull.Value;
                object narration = string.IsNullOrWhiteSpace(e.Narration) ? DBNull.Value : e.Narration;

                var command = $@"INSERT INTO Dues(Date, Amount, IsSell, IsConstruction, SiteId, PartyId, HeadId, SubHeadId, 
                                                UnitId, Quantity, Narration)
                            VALUES(@Date, {e.Amount}, {e.IsSell}, {e.IsConstruction}, {e.SiteId}, {e.PartyId}, {e.HeadId}, @SubHead, 
                                                @Unit, @Quantity,  @Narration)";
                var para = new List<SqliteParameter>() {
                    new SqliteParameter(@"Date", e.Date),
                    new SqliteParameter(@"SubHead", subHead),
                    new SqliteParameter(@"Unit", unit),
                    new SqliteParameter(@"Quantity", quantity),
                    new SqliteParameter(@"Narration", narration)
                };
                commands.Add(new KeyValuePair<string, List<SqliteParameter>>(command, para));
                Thread.Sleep(100);
            }
            else {
                object narration = string.IsNullOrWhiteSpace(e.Narration) ? DBNull.Value : e.Narration;
                var command = $@"INSERT INTO ReceiptPayments(Date, Amount, PartyId, HeadId, IsReceipt, IsCash, Narration)
                                VALUES(@Date, {e.Amount}, {e.PartyId}, {e.HeadId}, {e.IsReceipt}, {e.IsCash}, @Narration)";
                var para = new List<SqliteParameter>() {
                        new SqliteParameter(@"Date", e.Date),
                        new SqliteParameter(@"Narration", narration)
                    };
                commands.Add(new KeyValuePair<string, List<SqliteParameter>>(command, para));
                count++;
                Status = $"Preparing {count++}/{original.Count} commands";
                Thread.Sleep(100);
            }
        }
        return commands;
    }
    void onEntryRequest(EntryInsert e) {

        if (e.IsTopLevel) {
            entries.Add(e);
            original.Add(e);
            foreach (var item in e.ReceiptPayments) {
                var en = new EntryInsert() {
                    Date = e.Date,
                    SiteId = e.SiteId,
                    PartyId = e.PartyId,
                    HeadId = item.HeadId,
                    IsTopLevel = false,
                    Amount = item.Amount,
                    IsCash = item.IsCash,
                    IsReceipt = item.IsReceipt
                };
                if (e.IsSell == 0 || e.IsSell == 2) en.SiteId = int.MaxValue;
                else en.SiteId = int.MaxValue - 1;
                entries.Add(en);
                original.Add(en);
            }
        }
        else {
            foreach (var item in e.ReceiptPayments) {
                var en = new EntryInsert() {
                    Date = e.Date,
                    SiteId = e.SiteId,
                    PartyId = item.PartyId,
                    HeadId = item.HeadId,
                    IsTopLevel = false,
                    Amount = item.Amount,
                    IsCash = item.IsCash,
                    IsReceipt = item.IsReceipt
                };
                entries.Add(en);
                original.Add(en);
            }
        }
        if (!CanUpdate) {
            CanUpdate = true;
            OnPropertyChanged(nameof(CanUpdate));
        }
    }
    void onRemoveEntry(object o) {
        var e = (EntryInsert)o;
        original.Remove(e);
        entries.Remove(e);
        if (entries.Count == 0) {
            CanUpdate = false;
            OnPropertyChanged(nameof(CanUpdate));
        }
    }
}

