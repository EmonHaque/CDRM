﻿abstract class EditBaseVM<T> : Notifiable, IEdit<T> where T : Notifiable, IHaveName, new()
{
    string query;
    public string Query {
        get { return query; }
        set {
            if (query != value) {
                query = value?.Trim().ToLower();
                Editables.Refresh();
            }
        }
    }
    T selected;
    public T Selected {
        get { return selected; }
        set {
            selected = value;
            OnPropertyChanged(nameof(Selected));
        }
    }
    public T Edited { get; set; }
    bool isOnEdit;
    public bool IsOnEdit {
        get { return isOnEdit; }
        set { isOnEdit = value; if (!value) validateAndSave(); }
    }
    public ICollectionView Editables { get; set; }
    protected abstract CollectionViewSource cvs { get; }
    protected abstract void insert();

    public EditBaseVM() {
        Editables = cvs.View;
        Editables.SortDescriptions.Add(new SortDescription(nameof(IHaveName.Name), ListSortDirection.Ascending));
        Editables.Filter = filter;
    }
    bool filter(object o) {
        if (string.IsNullOrWhiteSpace(Query)) return true;
        return ((IHaveName)o).Name.ToLower().Contains(Query);
    }
    void validateAndSave() {
        var o = ((IEnumerable<T>)cvs.Source)
            .FirstOrDefault(x => x.Name.Equals(Edited.Name.Trim(), StringComparison.InvariantCultureIgnoreCase));

        bool isValid = false; ;
        if (o is Site) {
            if (o is null) isValid = true;
            else {
                var site = o as Site;
                var editedSite = Edited as Site;
                isValid = !editedSite.Address.Trim().Equals(site.Address);
            }
            if (isValid) insert();
        }
        else if (o is Party) {
            if (o is null) isValid = true;
            else {
                var party = o as Party;
                var editedParty = Edited as Party;
                isValid = !(editedParty.Address.Trim().Equals(party.Address, StringComparison.InvariantCultureIgnoreCase)
                    && editedParty.Phone.Trim().Equals(party.Phone, StringComparison.InvariantCultureIgnoreCase));
            }
            if (isValid) insert();
        }
        else {
            isValid = o is null;
            if (isValid) insert();
            else if (!isValid && Edited.Name.Trim().Equals(Selected.Name, StringComparison.InvariantCultureIgnoreCase)) return;
            else new ErrorDialog(EditBase<T>.Left, EditBase<T>.Top, EditBase<T>.Width, EditBase<T>.Height,
                    new List<ValidationError>() {
                    new ValidationError() {
                        Head = "Name",
                        Error = "already exists"
                    }
                    }).ShowDialog();
        }
    }
}
