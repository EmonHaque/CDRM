﻿class EditHead : EditBase<Head>
{
    public override string Header => "Head";
    public override string Icon => Icons.ControlHead;

    EditHeadVM vm = new();
    EditNameControl<Head> name = new();
    protected override IEdit<Head> viewModel => vm;
    protected override FrameworkElement editElement => name;

    protected override void bind() {
        base.bind();
        name.SetBinding(EditNameControl<Head>.NameProperty, new Binding($"{nameof(vm.Selected)}.{nameof(Unit.Name)}"));
        name.SetBinding(EditNameControl<Head>.EditedNameProperty, new Binding($"{nameof(vm.Edited)}.{nameof(Unit.Name)}"));
        name.SetBinding(EditNameControl<Head>.IsOnEditProperty, new Binding(nameof(vm.IsOnEdit)));
    }
}
