﻿class EditEntry : CardView
{
    public override string Header => "Entries";
    public override string Icon => Icons.Transact;

    DayPicker date;
    CommandButton delete, refresh;
    EditText search;
    CountBlock counter;
    ListBox list;
    Grid left;
    EditEntryControl editControl;
    EditEntryVM vm;

    public EditEntry() {
        vm = new EditEntryVM();
        DataContext = vm;
        initializeUI();
        bind();
    }
    void initializeLeftGrid() {
        date = new DayPicker() {
            Hint = "Date",
            DateFormat = "dd/MM/yyyy",
            IsRequired = true
        };
        refresh = new CommandButton() {
            Icon = Icons.Refresh,
            Command = vm.Refresh,
            Margin = new Thickness(0, 5, 0, 0),
            VerticalAlignment = VerticalAlignment.Center,
            ToolTip = "Refresh"
        };

        search = new EditText() {
            Icon = Icons.Search,
            Hint = "Tenant",
            IsTrimBottomRequested = true,
            Margin = new Thickness(0, 10, 0, 0)
        };
        counter = new CountBlock() { VerticalAlignment = VerticalAlignment.Center };


        list = new ListBox() {
            ItemTemplateSelector = new EditEntrySelector(),
            GroupStyle = {
                new GroupStyle() {
                    HeaderTemplateSelector = new EditEntryGroupHeaderSelector()
                }
            },
            Resources = {
                {
                    typeof(ScrollViewer),
                    new Style() {
                        Setters = {
                            new Setter(ScrollViewer.HorizontalScrollBarVisibilityProperty, ScrollBarVisibility.Disabled),
                            new Setter(ScrollViewer.TemplateProperty, new LedgerScrollTemplate(false)),
                        }
                    }

                }
            }
        };

        Grid.SetColumn(refresh, 1);
        Grid.SetColumn(counter, 1);
        Grid.SetRow(search, 1);
        Grid.SetRow(counter, 1);
        Grid.SetRow(list, 2);
        Grid.SetColumnSpan(list, 2);

        left = new Grid() {
            RowDefinitions = {
                new RowDefinition(){Height = GridLength.Auto},
                new RowDefinition(){Height = GridLength.Auto},
                new RowDefinition()
            },
            ColumnDefinitions = {
                new ColumnDefinition(),
                new ColumnDefinition(){Width = GridLength.Auto}
            },
            Children = { date, refresh, search, counter, list }
        };
    }
    void initializeUI() {
        delete = new CommandButton() {
            Icon = Icons.Delete,
            Command = vm.Delete,
            VerticalAlignment = VerticalAlignment.Center,
            ToolTip = "Delete"
        };
        addActions(delete);
        initializeLeftGrid();
        editControl = new EditEntryControl();
        var border = new Border() {
            BorderThickness = new Thickness(0.5, 0, 0, 0),
            BorderBrush = Brushes.LightGray,
            Margin = new Thickness(10, 0, 0, 0),
            Padding = new Thickness(10, 0, 0, 0),
            Child = editControl
        };

        Grid.SetColumn(border, 1);
        var grid = new Grid() {
            ColumnDefinitions = {
                new ColumnDefinition(),
                new ColumnDefinition()
            },
            Children = { left, border }
        };
        setContent(grid);

    }

    void bind() {
        list.SetBinding(ListBox.ItemsSourceProperty, new Binding(nameof(vm.Entries)));
        list.SetBinding(ListBox.SelectedItemProperty, new Binding(nameof(vm.Selected)));
        date.SetBinding(DayPicker.SelectedDateProperty, new Binding(nameof(vm.Date)));
        counter.SetBinding(CountBlock.CountProperty, new Binding("Items.Count") { Source = list });
        refresh.SetBinding(CommandButton.IsEnabledProperty, new Binding(nameof(vm.IsRefreshValid)));
        search.SetBinding(EditText.TextProperty, new Binding(nameof(vm.Query)));
        editControl.SetBinding(EditEntryControl.EntryProperty, new Binding(nameof(ListBox.SelectedItem)) { Source = list });
        editControl.SetBinding(EditEntryControl.EntryEditedProperty, new Binding(nameof(vm.Edited)) { Mode = BindingMode.OneWayToSource });
        delete.SetBinding(CommandButton.IsEnabledProperty, new Binding(nameof(vm.IsDeleteValid)));
    }
}
