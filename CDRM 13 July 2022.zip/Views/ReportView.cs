﻿class ReportView : ViewContainer
{
    override public string Icon => Icons.Ledger;
    public ReportView() {
        Children.Add(new SummaryDue());
        Children.Add(new ReportParty());
        //Children.Add(new ReportHead());
    }
}
