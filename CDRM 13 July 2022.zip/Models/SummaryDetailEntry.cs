﻿class SummaryDetailEntry : IPurchaseSell
{
    public DateTime Date { get; set; }
    public string GroupName { get; set; }
    public string Particulars { get; set; }
    public string Narration { get; set; }
    public double Purchase { get; set; }
    public double Sell { get; set; }
    public double GroupTotalPurchase { get; set; }
    public double GroupTotalSell { get; set; }
}
