﻿class EntryReceiptPayment : Notifiable
{
    public int Id { get; set; }
    public string Date { get; set; }
    public double Amount { get; set; }
    public int PartyId { get; set; }
    public int HeadId { get; set; }
    public byte IsReceipt { get; set; }
    public byte IsCash { get; set; }
    public string Narration { get; set; }
}
