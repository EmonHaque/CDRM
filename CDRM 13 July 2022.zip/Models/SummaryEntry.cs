﻿class SummaryEntry : IPurchaseSell
{
    public string GroupName { get; set; }
    public string Particulars { get; set; }
    public double Purchase { get; set; }
    public double Sell { get; set; }
    public double GroupTotalPurchase { get; set; }
    public double GroupTotalSell { get; set; }
}
