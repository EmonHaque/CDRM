﻿interface IEdit<T>
{
    T Selected { get; set; }
    T Edited { get; set; }
    bool IsOnEdit { get; set; }
    string Query { get; set; }
    ICollectionView Editables { get; set; }
    void ValidateAndSave();
}
