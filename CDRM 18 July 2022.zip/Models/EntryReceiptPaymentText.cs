﻿class EntryReceiptPaymentText : Notifiable, IHaveTitle
{
    public int Id { get; set; }
    public DateTime? Date { get; set; }
    public string Amount { get; set; }
    public string Party { get; set; }
    public string Head { get; set; }
    public byte IsCash { get; set; }
    public byte IsReceipt { get; set; }
    public string Narration { get; set; }
    public string Title { get; set; }
    public byte IsConstruction { get; set; }
}