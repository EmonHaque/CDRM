﻿class EditSite : EditBase<Site>
{
    public override string Header => "Site";
    public override string Icon => Icons.Plot;

    EditSiteVM vm = new();
    EditSiteControl site = new();
    protected override IEdit<Site> viewModel => vm;
    protected override EditNameControl editElement => site;

    //protected override void bind() {
    //    base.bind();
    //    site.SetBinding(EditSiteControl.NameProperty, new Binding($"{nameof(vm.Selected)}.{nameof(Site.Name)}"));
    //    site.SetBinding(EditSiteControl.EditedNameProperty, new Binding($"{nameof(vm.Edited)}.{nameof(Site.Name)}"));
    //    site.SetBinding(EditSiteControl.AddressProperty, new Binding($"{nameof(vm.Selected)}.{nameof(Site.Address)}"));
    //    site.SetBinding(EditSiteControl.EditedAddressProperty, new Binding($"{nameof(vm.Edited)}.{nameof(Site.Address)}"));
    //    site.SetBinding(EditSiteControl.IsOnEditProperty, new Binding(nameof(vm.IsOnEdit)));
    //}
}
