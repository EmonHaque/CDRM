﻿class EditUnit : EditBase<Unit>
{
    public override string Header => "Unit";
    public override string Icon => Icons.Accounts;

    EditUnitVM vm = new();
    EditNameControl name = new();
    protected override IEdit<Unit> viewModel => vm;
    protected override EditNameControl editElement => name;

    //protected override void bind() {
    //    base.bind();
    //    name.SetBinding(EditNameControl<Unit>.NameProperty, new Binding($"{nameof(vm.Selected)}.{nameof(Unit.Name)}"));
    //    name.SetBinding(EditNameControl<Unit>.EditedNameProperty, new Binding($"{nameof(vm.Edited)}.{nameof(Unit.Name)}"));
    //    name.SetBinding(EditNameControl<Unit>.IsOnEditProperty, new Binding(nameof(vm.IsOnEdit)));
    //}
}
