﻿abstract class EditBase<T> : CardView
{
    public static double Top { get; set; }
    public static double Left { get; set; }
    public static double Width { get; set; }
    public static double Height { get; set; }

    EditText search;
    CountBlock counter;
    ListBox list;
    Grid rightGrid;
    protected abstract EditNameControl editElement { get; }
    protected abstract IEdit<T> viewModel { get; }

    public EditBase() {
        DataContext = viewModel;
        initializeUI();
        bind();
        Loaded += onLoaded;
        Unloaded += onUnloaded;
    }
    void onLoaded(object sender, RoutedEventArgs e) {
        App.Current.MainWindow.LocationChanged += onRelocate;
    }
    void onUnloaded(object sender, RoutedEventArgs e) {
        Loaded -= onLoaded;
        Unloaded -= onUnloaded;
        App.Current.MainWindow.LocationChanged -= onRelocate;
    }
    void initializeUI() {
        search = new EditText() {
            Icon = Icons.Search,
            Hint = "Search"
        };
        counter = new CountBlock() { MinWidth = 20 };
        list = new ListBox() {
            ItemTemplate = new HiTemplate(nameof(IHaveName.Name), nameof(viewModel.Query), viewModel)
        };

        Grid.SetColumn(counter, 1);
        Grid.SetRow(list, 1);
        Grid.SetColumnSpan(list, 2);
        var leftGrid = new Grid() {
            Margin = new Thickness(0,5,0,0),
            ColumnDefinitions = {
                new ColumnDefinition(),
                new ColumnDefinition() { Width = GridLength.Auto }
            },
            RowDefinitions = {
                new RowDefinition(){ Height = GridLength.Auto},
                new RowDefinition()
            },
            Children = { search, counter, list }
        };

        editElement.SaveAction = viewModel.ValidateAndSave;
        rightGrid = new Grid() { Children = { editElement } };

        Grid.SetColumn(rightGrid, 2);
        var grid = new Grid() {
            ColumnDefinitions = {
                new ColumnDefinition(),
                new ColumnDefinition(){ Width = new GridLength(10)},
                new ColumnDefinition()
            },
            Children = { leftGrid, rightGrid }
        };
        setContent(grid);
    }
    protected virtual void bind() {
        counter.SetBinding(CountBlock.CountProperty, new Binding("Items.Count") { Source = list });
        list.SetBinding(ListBox.ItemsSourceProperty, new Binding(nameof(viewModel.Editables)));
        list.SetBinding(ListBox.SelectedItemProperty, new Binding(nameof(viewModel.Selected)) { Mode = BindingMode.OneWayToSource });

        editElement.SetBinding(EditNameControl.IsOnEditProperty, new Binding(nameof(viewModel.IsOnEdit)) { Mode = BindingMode.OneWayToSource });
        editElement.SetBinding(EditNameControl.SelectedProperty, new Binding(nameof(ListBox.SelectedItem)) { Source = list });
        editElement.SetBinding(EditNameControl.EditedProperty, new Binding(nameof(viewModel.Edited)));

        search.SetBinding(EditText.TextProperty, new Binding(nameof(viewModel.Query)));
    }

    void onRelocate(object? sender, EventArgs e) => updatePosition();
    protected override void OnRenderSizeChanged(SizeChangedInfo sizeInfo) {
        base.OnRenderSizeChanged(sizeInfo);
        updatePosition();
    }
    void updatePosition() {
        var dpi = VisualTreeHelper.GetDpi(this);
        var topLeft = rightGrid.TransformToAncestor(this).Transform(new Point(0, 0));
        var position = PointToScreen(topLeft);

        position.X /= dpi.DpiScaleX;
        position.Y /= dpi.DpiScaleY;

        Top = position.Y;
        Left = position.X;
        Width = rightGrid.ActualWidth;
        Height = rightGrid.ActualHeight;
    }
}
