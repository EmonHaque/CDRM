﻿class EntryNote : CardView
{
    public override string Header => "Note";
    public override string Icon => Icons.NoteBookPlus;

    SuggestBox noteType, site;
    TextBlock siteAddressBlock;
    Run siteAddress;
    EditText entry;
    CommandButton add;
    EntryNoteVM vm;

    public EntryNote() {
        vm = new EntryNoteVM();
        DataContext = vm;
        initializeUI();
        bind();
        Loaded += onLoaded;
        Unloaded += onUnloaded;
    }

    void onLoaded(object sender, RoutedEventArgs e) {
        App.Current.MainWindow.LocationChanged += onRelocate;
    }
    void onUnloaded(object sender, RoutedEventArgs e) {
        Loaded -= onLoaded;
        Unloaded -= onUnloaded;
        App.Current.MainWindow.LocationChanged -= onRelocate;
    }
    void initializeUI() {
        noteType = new SuggestBox() {
            IsRequired = true,
            Icon = Icons.NoteType,
            Hint = "Note type",
            Source = AppData.noteTypes
        };
        site = new SuggestBox() {
            IsRequired = true,
            Icon = Icons.Plot,
            Hint = "Site",
            Source = AppData.sites,
            LostFocusAction = vm.SetSiteAddress
        };
        siteAddress = new Run();
        siteAddressBlock = new TextBlock() {
            Margin = new Thickness(5, 5, 0, 10),
            Inlines = { "Address: ", siteAddress },
            Foreground = Brushes.DarkGray,
            TextWrapping = TextWrapping.Wrap
        };
        entry = new EditText() {
            Margin = new Thickness(5, 15, 5, 0),
            IsMultiline = true,
            Icon = Icons.Description,
            Hint = "Entry"
        };
        add = new CommandButton() {
            Icon = Icons.Plus,
            Margin = new Thickness(0, 5, 5, 0),
            Width = 16,
            Height = 16,
            HorizontalAlignment = HorizontalAlignment.Right,
            Command = vm.AddEntry
        };
        Grid.SetRow(site, 1);
        Grid.SetRow(siteAddressBlock, 2);
        Grid.SetRow(entry, 3);
        Grid.SetRow(add, 4);
        var grid = new Grid() {
            Margin = new Thickness(0,5,0,0),
            RowDefinitions = {
                new RowDefinition(){ Height = GridLength.Auto },
                new RowDefinition(){ Height = GridLength.Auto },
                new RowDefinition(){ Height = GridLength.Auto },
                new RowDefinition(),
                new RowDefinition(){ Height = GridLength.Auto }
            },
            Children = { noteType, site, siteAddressBlock, entry, add }
        };
        setContent(grid);
    }
    void bind() {
        noteType.SetBinding(SuggestBox.TextProperty, new Binding($"{nameof(vm.Entry)}.{nameof(EntryNoteText.NoteType)}"));
        site.SetBinding(SuggestBox.TextProperty, new Binding($"{nameof(vm.Entry)}.{nameof(EntryNoteText.Site)}"));
        siteAddress.SetBinding(Run.TextProperty, new Binding(nameof(vm.SiteAddress)));
        entry.SetBinding(EditText.TextProperty, new Binding($"{nameof(vm.Entry)}.{nameof(EntryNoteText.Entry)}"));
    }

    void onRelocate(object? sender, EventArgs e) => updatePosition(PointToScreen(new Point(0, 0)));
    protected override void OnRenderSizeChanged(SizeChangedInfo sizeInfo) {
        base.OnRenderSizeChanged(sizeInfo);
        updatePosition(PointToScreen(new Point(0, 0)));
    }
    void updatePosition(Point position) {
        var dpi = VisualTreeHelper.GetDpi(this);
        position.X /= dpi.DpiScaleX;
        position.Y /= dpi.DpiScaleY;
        position.X += Constants.CardMargin.Left;
        position.Y += Constants.CardMargin.Top;
        var width = ActualWidth - Constants.CardMargin.Left - Constants.CardMargin.Right;
        var height = ActualHeight - Constants.CardMargin.Top - Constants.CardMargin.Bottom;
        vm.Top = position.Y;
        vm.Left = position.X;
        vm.Width = width;
        vm.Height = height;
    }
}
