﻿class BalanceToolTip : ToolTip
{
    public BalanceToolTip() {
        var particulars = new TextBlock() { 
            Text = "Particulars", 
            VerticalAlignment = VerticalAlignment.Center 
        };
        var purchase = new TextBlock() { 
            Text = "Purchase/\nReceipt", 
            HorizontalAlignment = HorizontalAlignment.Right,
            TextAlignment = TextAlignment.Right
        };
        var sell = new TextBlock() { 
            Text = "Sell/\nPayment",
            HorizontalAlignment = HorizontalAlignment.Right,
            TextAlignment = TextAlignment.Right
        };
        var separator = new Separator() { Height = Constants.BottomLineThickness };

        Grid.SetColumn(purchase, 1);
        Grid.SetColumn(sell, 2);
        Grid.SetRow(separator, 1);
        Grid.SetColumnSpan(separator, 3);
        var header = new Grid() {
            ColumnDefinitions = {
                new ColumnDefinition(),
                new ColumnDefinition(){Width = new GridLength(Constants.AmountColumnWidth)},
                new ColumnDefinition(){Width = new GridLength(Constants.AmountColumnWidth)},
            },
            RowDefinitions = {
                new RowDefinition(){Height = GridLength.Auto},
                new RowDefinition(){Height = GridLength.Auto}
            },
            Children = { particulars, purchase, sell, separator },
            Resources = {
                {
                    typeof(TextBlock),
                    new Style(typeof(TextBlock)) {
                        Setters = {
                            new Setter(TextBlock.ForegroundProperty, Brushes.LightGray)
                        }
                    }
                }
            }
        };

        var box = new ItemsControl() {
            ItemTemplate = new BalanceToolTipTemplate(),
            AlternationCount = 2
        };
        box.SetBinding(ItemsControl.ItemsSourceProperty, new Binding(nameof(SumPartyTransaction.Transactions)));
        Grid.SetRow(box, 1);
        Content = new Grid() {
            RowDefinitions = {
                new RowDefinition(){Height = GridLength.Auto},
                new RowDefinition(),
            },
            Children = { header, box }
        };
    }
}
