﻿class EnumerableBoxItem : FrameworkElement
{
    ContentPresenter presenter;
    Border border;
    double thickness = 0.5;
    bool isSelected;
    public bool IsSelected {
        get { return isSelected; }
        set { isSelected = value; onSelectionChange(value); }
    }
    DataTemplate template;
    public DataTemplate Template {
        get { return template; }
        set { template = value; presenter.ContentTemplate = value; }
    }
    object content;
    public object Content {
        get { return content; }
        set { content = value; presenter.Content = value; }
    }

    public EnumerableBoxItem() {
        Focusable = true;
        FocusVisualStyle = null;
        presenter = new ContentPresenter();
        border = new Border() {
            BorderThickness = new Thickness(0, thickness, 0, thickness),
            Padding = new Thickness(3, 1, 0, 1),
            BorderBrush = Brushes.Transparent,
            Background = Brushes.Transparent,
            Child = presenter
        };
        AddVisualChild(border);
    }

    void onSelectionChange(bool value) {
        if (value) {
            border.Background = Constants.BackgroundDark;
            border.BorderBrush = Brushes.LightGray;
        }
        else {
            border.Background = null;
            border.BorderBrush = Brushes.Transparent;
        }
    }
    protected override void OnMouseEnter(MouseEventArgs e) {
        if (IsSelected) return;
        border.Background = Constants.BackgroundDark;
        border.BorderBrush = Brushes.LightGray;
    }
    protected override void OnMouseLeave(MouseEventArgs e) {
        if (IsSelected) return;
        border.Background = null;
        border.BorderBrush = Brushes.Transparent;
    }
    // Work on these Focus
    protected override void OnPreviewMouseLeftButtonUp(MouseButtonEventArgs e) {
        IsSelected = !IsSelected;
        RaiseEvent(new RoutedEventArgs(ClickedEvent));
        //if (IsSelected) Focus();
    }
    //protected override void OnPreviewGotKeyboardFocus(KeyboardFocusChangedEventArgs e) {
        
    //}
    //protected override void OnPreviewLostKeyboardFocus(KeyboardFocusChangedEventArgs e) {
    //    if (!IsSelected) {
    //        IsSelected = true;
    //        RaiseEvent(new RoutedEventArgs(ClickedEvent));
    //    }
    //}
    protected override Size MeasureOverride(Size availableSize) {
        border.Measure(availableSize);
        return border.DesiredSize;
    }
    protected override Size ArrangeOverride(Size finalSize) {
        border.Arrange(new Rect(finalSize));
        return finalSize;
    }
    protected override Visual GetVisualChild(int index) => border;
    protected override int VisualChildrenCount => 1;

    #region DependendyProperties
    public event RoutedEventHandler Clicked {
        add { AddHandler(ClickedEvent, value); }
        remove { RemoveHandler(ClickedEvent, value); }
    }

    public static readonly RoutedEvent ClickedEvent =
        EventManager.RegisterRoutedEvent("Clicked", RoutingStrategy.Direct, typeof(RoutedEventHandler), typeof(EnumerableBoxItem));
    #endregion
}
