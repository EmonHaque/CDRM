﻿class EntryNoteVM : Notifiable
{
    public double Top { get; set; }
    public double Left { get; set; }
    public double Width { get; set; }
    public double Height { get; set; }
    public EntryNoteText Entry { get; set; }
    string siteAddress;
    public string SiteAddress {
        get { return siteAddress; }
        set { siteAddress = value; OnPropertyChanged(nameof(SiteAddress)); }
    }

    public EntryNoteVM() {
        Entry = new EntryNoteText() { Date = DateTime.Today };
    }

    public void AddEntry() {
        var validator = new NoteValidator(Entry);
        if (!validator.IsValid()) {
            var errorDialog = new ErrorDialog(Left, Top, Width, Height, validator.Errors);
            errorDialog.ShowDialog();
            return;
        }
        if (!validator.DoesExist()) {
            var confirmDialog = new ConfirmCreationDialog(Left, Top, Width, Height, validator.Errors);
            var result = confirmDialog.ShowDialog();
            if (!result.HasValue) return;
            if (!result.Value) return;

            foreach (var e in validator.Errors) {
                switch (e.Head) {
                    case nameof(Entry.Site): {
                            var dialog = new CreateSiteDialog(Left, Top, Width, Height, Entry.Site);
                            dialog.ShowDialog();
                            var site = new Site() {
                                Name = Entry.Site.Trim(),
                                Address = dialog.GetAddress().Trim()
                            };
                            AppData.InsertSite(site);
                        }
                        break;
     
                    case nameof(Entry.NoteType): AppData.InsertNoteType(Entry.NoteType.Trim()); break;
                }
            }
        }

        AppData.InsertNote(new Note() {
            SiteId = AppData.GetSite().Id,
            NoteTypeId = AppData.GetNoteType().Id,
            Entry = Entry.Entry
        });
        Entry = new EntryNoteText() { Date = DateTime.Today };
        OnPropertyChanged(nameof(Entry));
    }
    public void SetSiteAddress() {
        if (string.IsNullOrWhiteSpace(Entry.Site)) {
            SiteAddress = null;
            return;
        }
        var site = AppData.sites.FirstOrDefault(x => x.Name.Equals(Entry.Site, StringComparison.InvariantCultureIgnoreCase));
        if (site is null) {
            SiteAddress = null;
            return;
        }
        SiteAddress = site.Address;
    }
    
}
