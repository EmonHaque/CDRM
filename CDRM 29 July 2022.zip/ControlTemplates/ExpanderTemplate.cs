﻿class ExpanderTemplate : ControlTemplate
{
    public ExpanderTemplate() {
        TargetType = typeof(Expander);
        var grid = new FrameworkElementFactory(typeof(Grid));
        var col1 = new FrameworkElementFactory(typeof(ColumnDefinition));
        var col2 = new FrameworkElementFactory(typeof(ColumnDefinition));
        var row1 = new FrameworkElementFactory(typeof(RowDefinition));
        var row2 = new FrameworkElementFactory(typeof(RowDefinition)) { Name = "contentRow" };
        var toggle = new FrameworkElementFactory(typeof(ExpanderState));
        var header = new FrameworkElementFactory(typeof(ContentPresenter));
        var content = new FrameworkElementFactory(typeof(ContentPresenter)) { Name = "content" };

        col1.SetValue(ColumnDefinition.WidthProperty, GridLength.Auto);
        row1.SetValue(RowDefinition.HeightProperty, GridLength.Auto);
        header.SetValue(Grid.ColumnProperty, 1);
        content.SetValue(Grid.RowProperty, 1);
        content.SetValue(Grid.ColumnProperty, 1);
        header.SetValue(ContentPresenter.ContentSourceProperty, "Header");
        toggle.SetValue(ExpanderState.MarginProperty, new Thickness(0, 3, 5, 0));
        toggle.SetValue(ExpanderState.VerticalAlignmentProperty, VerticalAlignment.Top);
        toggle.SetBinding(ExpanderState.IsTrueProperty, new Binding(nameof(Expander.IsExpanded)) {
            Mode = BindingMode.TwoWay,
            RelativeSource = new RelativeSource(RelativeSourceMode.TemplatedParent)
        });

        grid.AppendChild(col1);
        grid.AppendChild(col2);
        grid.AppendChild(row1);
        grid.AppendChild(row2);
        grid.AppendChild(toggle);
        grid.AppendChild(header);
        grid.AppendChild(content);

        VisualTree = grid;

        Triggers.Add(new Trigger() {
            Property = Expander.IsExpandedProperty,
            Value = false,
            Setters = {
                new Setter(){
                    TargetName = "content",
                    Property = ContentPresenter.HeightProperty,
                    Value = 0d
                }
            }
        });
    }
}
