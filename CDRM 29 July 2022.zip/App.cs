﻿class App : Application
{
    [STAThread]
    static void Main(string[] args) => new App().Run();

    protected override void OnStartup(StartupEventArgs e) {
        base.OnStartup(e);
        new AppData();
        new Converters();
        SetStyle();

        App.Current.MainWindow = new RootWindow() {
            Content = new RootPanel() {
                Children = {
                    new HomeView(),
                    new EntryView(),
                    new EditView(),
                    new ReportView()
                }
            }
        };
        App.Current.MainWindow.Show();
    }

    void SetStyle() {
        Current.Resources.Add(SystemParameters.VerticalScrollBarWidthKey, Constants.ScrollBarThickness);
        Current.Resources.Add(SystemParameters.HorizontalScrollBarHeightKey, Constants.ScrollBarThickness);

        Control.StyleProperty.OverrideMetadata(typeof(ScrollBar), new FrameworkPropertyMetadata() {
            DefaultValue = new Style() {
                Setters = { new Setter(ScrollBar.TemplateProperty, new VScrollTemplate()) },
                Triggers = {
                    new Trigger() {
                        Property = ScrollBar.OrientationProperty,
                        Value = Orientation.Horizontal,
                        Setters = { new Setter(ScrollBar.TemplateProperty, new HScrollTemplate()) }
                    }
                }
            }
        });
        ListBoxItem.StyleProperty.OverrideMetadata(typeof(ListBox), new FrameworkPropertyMetadata() {
            DefaultValue = new Style() {
                Setters = {
                    new Setter(ListBox.TemplateProperty, new ListBoxTemplate()),
                    new Setter(ListBox.BorderThicknessProperty, new Thickness(0)),
                    new Setter(ListBox.HorizontalContentAlignmentProperty, HorizontalAlignment.Stretch),
                    new Setter(ListBox.IsSynchronizedWithCurrentItemProperty, true),
                    new Setter(TextElement.ForegroundProperty, Brushes.LightGray)
                }
            }
        });
        ListBoxItem.StyleProperty.OverrideMetadata(typeof(ListBoxItem), new FrameworkPropertyMetadata() {
            DefaultValue = new Style() {
                Setters = {
                    new Setter(ListBoxItem.TemplateProperty, new ListBoxItemTemplate()),
                    new Setter(ListBoxItem.FocusVisualStyleProperty, null)
                }
            }
        });
        Separator.StyleProperty.OverrideMetadata(typeof(Separator), new FrameworkPropertyMetadata() {
            DefaultValue = new Style() {
                Setters = {
                    new Setter(Separator.BorderThicknessProperty, new Thickness(0.1))
                }
            }
        });
        ToolTip.StyleProperty.OverrideMetadata(typeof(ToolTip), new FrameworkPropertyMetadata() {
            DefaultValue = new Style() {
                Setters = {
                    new Setter(ToolTip.TemplateProperty, new ToolTipTemplate()),
                    new Setter(ToolTip.HorizontalOffsetProperty, 10d),
                    new Setter(ToolTip.VerticalOffsetProperty, 10d),
                }
            }
        });
        Control.StyleProperty.OverrideMetadata(typeof(Control), new FrameworkPropertyMetadata() {
            DefaultValue = new Style() {
                Setters = {
                    new Setter(MenuItem.BorderThicknessProperty, new Thickness(0)),
                    new Setter(MenuItem.PaddingProperty, new Thickness(0)),
                    new Setter(Control.BackgroundProperty, Constants.Background),
                    new Setter(Control.ForegroundProperty, Brushes.LightGray)
                }
            }
        });
    }
    void unhandledHandler(object sender, DispatcherUnhandledExceptionEventArgs e) {
        if (BusyWindow.IsOpened) BusyWindow.Terminate();
        ExceptionDialog.Activate("Exception", e.Exception.Message + "\n" + e.Exception.StackTrace);
        e.Handled = true;
    }
}
