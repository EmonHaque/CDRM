﻿class Notes : CardView
{
    public override string Header => "Notes";
    public override string Icon => Icons.NoteBook;

    DependencyPropertyDescriptor expandDescriptor;
    Grid leftGrid;
    Border rightBorder;
    EditText search;
    ExpanderState expandState;
    ListBox entries;
    CountBlock count;
    TextBox note;
    ActionButton refresh, edit, cancel, save, delete;
    Separator separator;
    StackPanel cancelSave;
    EditNoteControl editNote;
    NotesVM vm;

    public override void OnFirstSight() {
        base.OnFirstSight();
        vm = new NotesVM();
        DataContext = vm;
        initializeUI();
        bind();

        expandDescriptor = DependencyPropertyDescriptor.FromProperty(ExpanderState.IsTrueProperty, typeof(ExpanderState));
        expandDescriptor.AddValueChanged(expandState, onExpandChanged);
        vm.CoordinateRequested += onCoordinateRequest;
        note.PreviewMouseWheel += onWheel;
        Unloaded += onUnloaded;
    }
    void onUnloaded(object sender, RoutedEventArgs e) {
        vm.CoordinateRequested -= onCoordinateRequest;
        expandDescriptor.RemoveValueChanged(expandState, onExpandChanged);
        Unloaded -= onUnloaded;
        note.PreviewMouseWheel -= onWheel;
    }
    void onCoordinateRequest() => updatePosition();
    void onExpandChanged(object? sender, EventArgs e) {
        var items = Helper.FindVisualChildren<GroupItem>(entries);
        if (expandState.IsTrue) {
            foreach (GroupItem item in items) item.Tag = true;
            expandState.ToolTip = "Collapse";
        }
        else {
            foreach (GroupItem item in items) item.Tag = false;
            expandState.ToolTip = "Expand";
        }
    }
    void onWheel(object sender, MouseWheelEventArgs e) {
        if (!(Keyboard.IsKeyDown(Key.LeftCtrl) || Keyboard.IsKeyDown(Key.RightCtrl))) return;
        e.Handled = true;
        if(e.Delta > 0) {
            if (note.FontSize < 25) note.FontSize++;
        }
        else {
            if (note.FontSize > 12) note.FontSize--;
        }
    }
    void initializeLeftGrid() {
        search = new EditText() {
            Hint = "Search",
            Icon = Icons.Search,
            IsTrimBottomRequested = true
        };
       
        expandState = new ExpanderState() {
            Margin = new Thickness(5, 0, 5, 0),
            ToolTip = "Expand"
        };
        refresh = new ActionButton() {
            Icon = Icons.Refresh,
            ToolTip = "Refresh",
            Command = vm.Refresh
        };
        count = new CountBlock() { Margin = new Thickness(5,0,0,0)};
        Grid.SetColumn(expandState, 1);
        Grid.SetColumn(refresh, 2);
        Grid.SetColumn(count, 3);
       
        var topRow = new Grid() {
            ColumnDefinitions = {
                new ColumnDefinition(),
                new ColumnDefinition(){Width = GridLength.Auto},
                new ColumnDefinition(){Width = GridLength.Auto},
                new ColumnDefinition(){Width = GridLength.Auto}
            },
            Children = { search, expandState, refresh, count }
        };
        entries = new ListBox() {
            ItemTemplate = new NoteTemplate(),
            GroupStyle = {
                new GroupStyle() {
                    ContainerStyle = new Style(typeof(GroupItem)) {
                        Setters = {
                            new Setter(GroupItem.TemplateProperty, new NoteGroupTemplate())
                        }
                    }
                }
            },
            Resources = {
                {
                    typeof(ScrollViewer),
                    new Style(typeof(ScrollViewer)) {
                        Setters = {
                            new Setter(ScrollViewer.HorizontalScrollBarVisibilityProperty, ScrollBarVisibility.Disabled)
                        }
                    }
                }
            }
        };
        Grid.SetRow(entries, 1);
        leftGrid = new Grid() {
            Margin = new Thickness(0,5,5,0),
            RowDefinitions = {
                new RowDefinition(){Height = GridLength.Auto},
                new RowDefinition()
            },
            Children = { topRow, entries }
        };
    }
    void initializeRightBorder() {
        #region buttons;
        delete = new ActionButton() {
            Margin = new Thickness(0,0,5,0),
            ToolTip = "Delete",
            Icon = Icons.Delete,
            HorizontalAlignment = HorizontalAlignment.Right,
            Command = vm.Delete
        };
        edit = new ActionButton() {
            ToolTip = "Edit",
            Icon = Icons.Pencil,
            Command = vm.Edit
        };
        cancel = new ActionButton() {
            Margin = new Thickness(0, 0, 5, 0),
            ToolTip = "Cancel",
            Icon = Icons.Close,
            Visibility = Visibility.Collapsed,
            Command = vm.Cancel
        };
        save = new ActionButton() {
            ToolTip = "Save",
            Icon = Icons.Checked,
            Visibility = Visibility.Collapsed,
            Command = vm.Save
        };
        cancelSave = new StackPanel() {
            Margin = new Thickness(5,0,0,0),
            Orientation = Orientation.Horizontal,
            Children = { edit, cancel, save }
        };
        separator = new Separator() {
            Height = Constants.BottomLineThickness,
            Margin = new Thickness(0, 5, 0, 3)
        };
        #endregion

        note = new TextBox() {
            IsReadOnly = true,
            Margin = new Thickness(0,5,5,0),
            BorderThickness = new Thickness(0),
            TextWrapping = TextWrapping.Wrap,
            SelectionBrush = Brushes.Black,
            HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled,
            VerticalScrollBarVisibility = ScrollBarVisibility.Auto
        };
        editNote = new EditNoteControl();
        Grid.SetRow(separator, 1);
        Grid.SetRow(note, 2);
        Grid.SetRow(editNote, 2);
        var grid = new Grid() {
            RowDefinitions = {
                new RowDefinition(){Height = GridLength.Auto},
                 new RowDefinition(){Height = GridLength.Auto},
                new RowDefinition()
            },
            Children = { cancelSave, delete, separator, note, editNote }
        };
        rightBorder = new Border() {
            BorderThickness = new Thickness(Constants.BottomLineThickness, 0, 0, 0),
            Margin = new Thickness(5,0,0,0),
            Padding = new Thickness(5,5,0,5),
            BorderBrush = Brushes.LightGray,
            Child = grid
        };
    }
    void initializeUI() {
        initializeLeftGrid();
        initializeRightBorder();
        Grid.SetColumn(rightBorder, 1);
        var grid = new Grid() {
            ColumnDefinitions = {
                new ColumnDefinition(),
                new ColumnDefinition()
            },
            Children = { leftGrid, rightBorder }
        };
        setContent(grid);
    }
    void bind() {
        entries.SetBinding(ListBox.ItemsSourceProperty, new Binding(nameof(vm.Reportables)));
        entries.SetBinding(ListBox.SelectedItemProperty, new Binding(nameof(vm.Selected)) { Mode = BindingMode.OneWayToSource });
        count.SetBinding(CountBlock.CountProperty, new Binding("Items.Count") { Source = entries, Mode = BindingMode.OneWay });
        search.SetBinding(EditText.TextProperty, new Binding(nameof(vm.Query)) { Mode = BindingMode.OneWayToSource });
        note.SetBinding(TextBox.TextProperty, new Binding($"{nameof(ListBox.SelectedItem)}.{nameof(EntryNoteText.Entry)}") { Source = entries});
        editNote.SetBinding(EditNoteControl.DataContextProperty, new Binding(nameof(vm.Edited)));
        
        var binding = new Binding(nameof(vm.IsOnEdit)) { Converter = new BooleanToVisibilityConverter() };
        cancel.SetBinding(ActionButton.VisibilityProperty, binding);
        save.SetBinding(ActionButton.VisibilityProperty, binding);
        separator.SetBinding(Separator.VisibilityProperty, binding);
        editNote.SetBinding(EditNoteControl.VisibilityProperty, new Binding(nameof(vm.IsOnEdit)) {
            Converter = new BooleanToVisibilityConverter(),
            Source = vm
        });

        edit.SetBinding(ActionButton.VisibilityProperty, new Binding(nameof(vm.IsOnEdit)) { Converter = Converters.bool2Invisible });
        note.SetBinding(TextBox.VisibilityProperty, new Binding(nameof(vm.IsOnEdit)) { Converter = Converters.bool2Invisible });
    }
    void updatePosition() {
        var dpi = VisualTreeHelper.GetDpi(this);

        var topLeftOfMiddleBorder = rightBorder.TransformToAncestor(this).Transform(new Point(0, 0));
        var positionOfMiddleBorder = PointToScreen(topLeftOfMiddleBorder);

        positionOfMiddleBorder.X /= dpi.DpiScaleX;
        positionOfMiddleBorder.Y /= dpi.DpiScaleY;

        vm.Top = positionOfMiddleBorder.Y - 5;
        vm.Left = positionOfMiddleBorder.X;
        vm.Width = rightBorder.ActualWidth + 5;
        vm.Height = rightBorder.ActualHeight + 10;
    }
}
