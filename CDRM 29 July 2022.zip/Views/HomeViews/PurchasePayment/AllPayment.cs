﻿class AllPayment : CardView
{
    public override string Icon => Icons.HandShake;

    TextBlock totalBlock;
    Run total;
    DayPicker from, to;
    ActionButton refresh;
    PieChart chart;
    AllPaymentVM vm;

    public override void OnFirstSight() {
        base.OnFirstSight();
        vm = new AllPaymentVM();
        DataContext = vm;
        initializeUI();
        bind();
    }
    void initializeUI() {
        var label = new TextBlock() {
            FontSize = 14,
            Text = "Payments",
            VerticalAlignment = VerticalAlignment.Bottom,
            LayoutTransform = new RotateTransform(-90),
            IsHitTestVisible = false
        };
        #region first Row
        from = new DayPicker() {
            DateFormat = "dd/MM/yyyy",
            Hint = "from"
        };
        to = new DayPicker() {
            DateFormat = "dd/MM/yyyy",
            Hint = "to"
        };
        refresh = new ActionButton() {
            Margin = new Thickness(5, 0, 0, 0),
            Icon = Icons.Refresh,
            Command = vm.Refresh,
            VerticalAlignment = VerticalAlignment.Center
        };
        Grid.SetColumn(to, 1);
        Grid.SetColumn(refresh, 2);
        var firstRow = new Grid() {
            Margin = new Thickness(0, 5, 0, 0),
            ColumnDefinitions = {
                new ColumnDefinition(),
                new ColumnDefinition(),
                new ColumnDefinition(){Width = GridLength.Auto }
            },
            Children = { from, to, refresh }
        };
        #endregion

        chart = new PieChart() /*{ IsSelectable = true }*/;

        #region bottom Row
        total = new Run();
        totalBlock = new TextBlock() {
            Inlines = { "Total ", total },
            HorizontalAlignment = HorizontalAlignment.Right
        };
        #endregion
        Grid.SetRowSpan(label, 3);
        Grid.SetRow(chart, 1);
        Grid.SetRow(totalBlock, 2);
        var grid = new Grid() {
            RowDefinitions = {
                new RowDefinition(){Height = GridLength.Auto},
                new RowDefinition(),
                new RowDefinition(){Height = GridLength.Auto}
            },
            Children = { label, firstRow, chart, totalBlock }
        };
        setContent(grid);
    }
    void bind() {
        total.SetBinding(Run.TextProperty, new Binding(nameof(vm.Total)) { StringFormat = Constants.NumberFormat });
        from.SetBinding(DayPicker.SelectedDateProperty, new Binding(nameof(vm.From)));
        to.SetBinding(DayPicker.SelectedDateProperty, new Binding(nameof(vm.To)));
        chart.SetBinding(PieChart.ItemsSourceProperty, new Binding(nameof(vm.Data)));
    }
}
