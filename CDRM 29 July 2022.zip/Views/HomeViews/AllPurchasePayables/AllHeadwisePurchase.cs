﻿class AllHeadwisePurchase : AllPurchaseBase
{
    public override string Icon => Icons.ControlHead;
    protected override string searchHint => "Head";
    AllHeadwisePurchaseVM viewModel;
    protected override AllPurchaseBaseVM vm { get {
            if(viewModel is null) {
                viewModel = new AllHeadwisePurchaseVM();
            }
            return viewModel;
        }
    }
}
