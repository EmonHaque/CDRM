﻿class AllSitewisePurchase : AllPurchaseBase
{
    public override string Icon => Icons.Plot;
    protected override string searchHint => "Site";
    AllSitewisePurchaseVM viewModel;
    protected override AllPurchaseBaseVM vm { get { 
            if(viewModel is null) {
                viewModel = new AllSitewisePurchaseVM();
            }
            return viewModel;
        } 
    }

}
