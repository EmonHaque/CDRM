﻿abstract class SinglePurchasePayables<T> : CardView where T : IHaveName
{
    SelectItem sites;
    MultiState state;
    ActionButton refresh;
    TextBlock total;
    FrameworkElement chart;
    protected abstract SinglePurchasePayableBaseVM<T> vm { get; }
    protected abstract string hint { get; }
    protected abstract void initialize();
    public override void OnFirstSight() {
        initialize();
        DataContext = vm;
        base.OnFirstSight();
        initializeUI();
        bind();
    }
    void initializeUI() {
        sites = new SelectItem() {
            Margin = new Thickness(5, 10, 5, 0),
            Hint = hint,
            IsRequired = true,
            Icon = Icons.Tenant,
            SelectedValuePath = nameof(IHaveName.Id),
            DisplayPath = nameof(IHaveName.Name)
        };
        state = new MultiState() {
            Texts = new string[] { "Date", "Month" },
            Icons = new string[] { Icons.Calendar, Icons.CalendarSearch },
            Margin = new Thickness(5, 10, 5, 0),
            VerticalAlignment = VerticalAlignment.Center,
            HorizontalAlignment = HorizontalAlignment.Right
        };
        refresh = new ActionButton() {
            ToolTip = "refresh",
            Icon = Icons.Refresh,
            Command = vm.Refresh,
            Margin = new Thickness(0, 10, 0, 0),
            VerticalAlignment = VerticalAlignment.Center
        };
        Grid.SetColumn(state, 1);
        Grid.SetColumn(refresh, 2);
        var topRow = new Grid() {
            ColumnDefinitions = {
                new ColumnDefinition(),
                new ColumnDefinition(){ Width = GridLength.Auto },
                new ColumnDefinition(){ Width = GridLength.Auto }
            },
            Children = { sites, state, refresh }
        };
        total = new TextBlock() {
            HorizontalAlignment = HorizontalAlignment.Right,
            Margin = new Thickness(0, 5, 0, 0)
        };
        if (vm is (SingleSitewisePurchaseVM or SingleHeadwisePurchaseVM)) {
            chart = new PinChart();
        }
        else chart = new PinLineBarChart();
        chart.Margin = new Thickness(5, 0, 5, 5);
        Grid.SetRow(total, 1);
        Grid.SetRow(chart, 2);
        var grid = new Grid() {
            Margin = new Thickness(0, 5, 5, 0),
            RowDefinitions = {
                new RowDefinition(){Height = GridLength.Auto},
                new RowDefinition(){Height = GridLength.Auto},
                new RowDefinition()
            },
            Children = { topRow, total, chart }
        };
        setContent(grid);
    }
    void bind() {
        sites.SetBinding(SelectItem.ItemsSourceProperty, new Binding(nameof(vm.SelectionView)));
        sites.SetBinding(SelectItem.SelectedvalueProperty, new Binding(nameof(vm.Id)));
        sites.SetBinding(SelectItem.QueryProperty, new Binding(nameof(vm.Query)) { Mode = BindingMode.OneWayToSource });
        state.SetBinding(MultiState.StateProperty, new Binding(nameof(vm.State)) { Mode = BindingMode.OneWayToSource });
        total.SetBinding(TextBlock.TextProperty, new Binding(nameof(vm.Total)));

        DependencyProperty property = null;
        if (vm is (SingleSitewisePurchaseVM or SingleHeadwisePurchaseVM)) property = PinChart.ItemsSourceProperty;
        else property = PinLineBarChart.ItemsSourceProperty;
        chart.SetBinding(property, new Binding(nameof(vm.Data)));
    }
}
