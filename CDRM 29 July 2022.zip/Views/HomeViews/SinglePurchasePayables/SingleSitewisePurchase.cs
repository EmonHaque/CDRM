﻿class SingleSitewisePurchase : SinglePurchasePayables<Site>
{
    public override string Icon => Icons.Plot;
    SingleSitewisePurchaseVM viewModel;
    PinChart pin;
    protected override SinglePurchasePayableBaseVM<Site> vm => viewModel;
    protected override string hint => "Site";
    protected override void initialize() {
        viewModel = new SingleSitewisePurchaseVM();
        pin = new PinChart();
    }
}
