﻿class SingleHeadwisePurchase : SinglePurchasePayables<Head>
{
    public override string Icon => Icons.ControlHead;

    SingleHeadwisePurchaseVM viewModel;
    PinChart pin;
    protected override void initialize() {
        viewModel = new SingleHeadwisePurchaseVM();
        pin = new PinChart();
    }
    protected override SinglePurchasePayableBaseVM<Head> vm => viewModel;
    protected override string hint => "Head";
}
