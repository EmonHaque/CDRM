﻿class EditHead : EditBase<Head>
{
    public override string Header => "Head";
    public override string Icon => Icons.ControlHead;

    EditHeadVM vm;
    EditNameControl name;
    protected override IEdit<Head> viewModel => vm;
    protected override EditNameControl editElement => name;
    protected override void initialize() {
        vm = new EditHeadVM();
        name = new EditNameControl();
    }
}
