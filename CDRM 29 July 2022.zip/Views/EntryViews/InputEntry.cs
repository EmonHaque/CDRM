﻿class InputEntry : CardView
{
    public override string Header => "Entry";
    public override string Icon => Icons.HandShake;

    DependencyPropertyDescriptor isPurchaseDescriptor, quantityDescriptor;
    DayPicker date;
    SuggestBox site, party, head, rpHead, subHead, unit;
    TextBlock partyAddressBlock, partyPhoneBlock, siteAddressBlock;
    Run partyAddress, partyPhone, siteAddress;
    EditText amountDue, amountRP, quantity, narration;
    MultiState isConstruction, isCash, isPurchase;
    ListBox receiptPaymentList;
    CommandButton add, addReceiptPayment;
    Grid siteHeadQuantityGrid;
    InputEntryVM vm;

    public override void OnFirstSight() {
        base.OnFirstSight();
        vm = new InputEntryVM();
        DataContext = vm;
        initializeUI();
        bind();

        isPurchaseDescriptor = DependencyPropertyDescriptor.FromProperty(MultiState.StateProperty, typeof(MultiState));
        quantityDescriptor = DependencyPropertyDescriptor.FromProperty(EditText.TextProperty, typeof(EditText));
        isPurchaseDescriptor.AddValueChanged(isPurchase, onIsPurchaseChanged);
        quantityDescriptor.AddValueChanged(quantity, onQuantityChanged);
        vm.CoordinateRequested += onCoordinateRequest;
        Unloaded += onUnloaded;
    }
    void onUnloaded(object sender, RoutedEventArgs e) {
        vm.CoordinateRequested -= onCoordinateRequest;
        Unloaded -= onUnloaded;
        isPurchaseDescriptor.RemoveValueChanged(isPurchase, onIsPurchaseChanged);
        quantityDescriptor.RemoveValueChanged(quantity, onQuantityChanged);
    }
    void onIsPurchaseChanged(object? sender, EventArgs e) {
        switch (isPurchase.State) {
            case 0:
            case 1:
                amountDue.Visibility = Visibility.Visible;
                isConstruction.Visibility = Visibility.Visible;
                siteHeadQuantityGrid.Visibility = Visibility.Visible;
                rpHead.Visibility = Visibility.Hidden;
                break;
            case 2:
            case 3:
                amountDue.Visibility = Visibility.Hidden;
                isConstruction.Visibility = Visibility.Hidden;
                siteHeadQuantityGrid.Visibility = Visibility.Collapsed;
                rpHead.Visibility = Visibility.Visible;
                break;
        }
    }
    void onQuantityChanged(object? sender, EventArgs e) {
        unit.IsRequired = !string.IsNullOrWhiteSpace(quantity.Text);
    }
    void onCoordinateRequest() => updatePosition();

    void initializeUI() {
        #region DateDueGrid
        date = new DayPicker() {
            Hint = "Date",
            DateFormat = "dd/MM/yyyy"
        };
        isPurchase = new MultiState() {
            Icons = new string[] { Icons.Purchase, Icons.Sell, Icons.Payment, Icons.Receipt },
            Texts = new string[] { "Purchase", "Sell", "Payment", "Receipt" },
            IsIconInfront = true,
            Margin = new Thickness(5, 0, 0, 10),
            VerticalAlignment = VerticalAlignment.Bottom
        };
        isConstruction = new MultiState() {
            Icons = new string[] { Icons.Construction, Icons.Development, Icons.Repair, Icons.Maintenance },
            Texts = new string[] { "Construction", "Development", "Repair", "Maintenance" },
            IsIconInfront = true,
            Margin = new Thickness(5, 0, 5, 10),
            VerticalAlignment = VerticalAlignment.Bottom
        };
        amountDue = new EditText() {
            Icon = Icons.Amount,
            Hint = "Due"
        };
        rpHead = new SuggestBox() {
            IsRequired = true,
            Icon = Icons.ControlHead,
            Hint = "Head",
            Source = AppData.heads,
            Visibility = Visibility.Hidden
        };
        Grid.SetColumn(isPurchase, 1);
        Grid.SetColumn(isConstruction, 2);
        Grid.SetColumn(amountDue, 3);
        Grid.SetColumn(rpHead, 2);
        Grid.SetColumnSpan(rpHead, 2);
        var dateDueGrid = new Grid() {
            Margin = new Thickness(0, 5, 0, 0),
            ColumnDefinitions = {
                new ColumnDefinition(){ Width = new GridLength(2, GridUnitType.Star)},
                new ColumnDefinition(),
                new ColumnDefinition(),
                new ColumnDefinition(){ Width = new GridLength(1.55, GridUnitType.Star)}
            },
            Children = { date, isPurchase, isConstruction, amountDue, rpHead }
        };
        #endregion

        #region PartyReceiptPaymentGrid
        party = new SuggestBox() {
            IsRequired = true,
            Icon = Icons.Tenant,
            Hint = "Party",
            Source = AppData.parties,
            LostFocusAction = vm.SetPartyAddress
        };
        partyAddress = new Run();
        partyPhone = new Run();
        partyAddressBlock = new TextBlock() {
            Margin = new Thickness(5, 5, 0, 5),
            Inlines = { "Address: ", partyAddress },
            TextWrapping = TextWrapping.Wrap,
            Foreground = Brushes.DarkGray
        };
        partyPhoneBlock = new TextBlock() {
            Margin = new Thickness(5, 5, 0, 10),
            Inlines = { "Phone: ", partyPhone },
            TextWrapping = TextWrapping.Wrap,
            Foreground = Brushes.DarkGray
        };

        isCash = new MultiState() {
            Icons = new string[] { Icons.Cash, Icons.Phone, Icons.Noncash },
            Texts = new string[] { "Cash", "Mobile", "Discount" },
            IsIconInfront = true,
            Width = 65,
            Margin = new Thickness(10, 5, 5, 0),
            VerticalAlignment = VerticalAlignment.Center
        };
        amountRP = new EditText() {
            Icon = Icons.Amount,
            Hint = "Amount"
        };
        addReceiptPayment = new CommandButton() {
            Icon = Icons.Plus,
            Width = 14,
            Height = 14,
            Margin = new Thickness(2, 5, 5, 0),
            HorizontalAlignment = HorizontalAlignment.Right,
            Command = vm.AddReceiptPayment
        };
        receiptPaymentList = new ListBox() {
            Margin = new Thickness(10, 0, 5, 0),
            ItemTemplate = new ReceiptPaymentTemplate(new Binding(nameof(vm.RemoveReceiptPayment)) { Source = vm })
        };
        Grid.SetColumn(amountRP, 1);
        Grid.SetColumn(addReceiptPayment, 2);
        Grid.SetRow(receiptPaymentList, 1);
        Grid.SetColumnSpan(receiptPaymentList, 3);
        var rpGrid = new Grid() {
            MinWidth = 250,
            MaxWidth = 400,
            ColumnDefinitions = {
                new ColumnDefinition(){Width = GridLength.Auto},
                new ColumnDefinition(),
                new ColumnDefinition(){Width = GridLength.Auto}
            },
            RowDefinitions = {
                new RowDefinition(){Height = GridLength.Auto},
                new RowDefinition()
            },
            Children = { isCash, amountRP, addReceiptPayment, receiptPaymentList }
        };
        Grid.SetRow(partyAddressBlock, 1);
        Grid.SetRow(partyPhoneBlock, 2);
        Grid.SetColumn(rpGrid, 1);
        Grid.SetRowSpan(rpGrid, 3);
        var partyRPGrid = new Grid() {
            ColumnDefinitions = {
                new ColumnDefinition(),
                new ColumnDefinition(){ Width = GridLength.Auto }
            },
            RowDefinitions = {
                new RowDefinition(),
                new RowDefinition(),
                new RowDefinition()
            },
            Children = { party, partyAddressBlock, partyPhoneBlock, rpGrid }
        };
        #endregion

        #region SiteHeadQuantityGrid
        site = new SuggestBox() {
            IsRequired = true,
            Icon = Icons.Plot,
            Hint = "Site",
            Source = AppData.sites,
            LostFocusAction = vm.SetSiteAddress
        };
        siteAddress = new Run();
        siteAddressBlock = new TextBlock() {
            Margin = new Thickness(5, 5, 0, 10),
            Inlines = { "Address: ", siteAddress },
            Foreground = Brushes.DarkGray,
            TextWrapping = TextWrapping.Wrap
        };
        head = new SuggestBox() {
            IsRequired = true,
            Icon = Icons.ControlHead,
            Hint = "Head",
            Source = AppData.heads
        };
        subHead = new SuggestBox() {
            Icon = Icons.Head,
            Hint = "Subhead",
            Source = AppData.subHeads
        };
        quantity = new EditText() {
            Icon = Icons.Amount,
            Hint = "Quantity"
        };
        unit = new SuggestBox() {
            Icon = Icons.Accounts,
            Hint = "Unit",
            Source = AppData.units
        };
        Grid.SetColumnSpan(site, 2);
        Grid.SetColumnSpan(siteAddressBlock, 2);
        Grid.SetRow(siteAddressBlock, 1);
        Grid.SetRow(head, 2);
        Grid.SetRow(subHead, 2);
        Grid.SetColumn(subHead, 1);
        Grid.SetRow(quantity, 3);
        Grid.SetRow(unit, 3);
        Grid.SetColumn(unit, 1);

        siteHeadQuantityGrid = new Grid() {
            ColumnDefinitions = {
                new ColumnDefinition(),
                new ColumnDefinition()
            },
            RowDefinitions = {
                new RowDefinition(){Height = GridLength.Auto},
                new RowDefinition(){Height = GridLength.Auto},
                new RowDefinition(){Height = GridLength.Auto},
                new RowDefinition(){Height = GridLength.Auto}
            },
            Children = { site, siteAddressBlock, head, subHead, quantity, unit }
        };
        #endregion

        narration = new EditText() {
            Margin = new Thickness(5, 15, 5, 0),
            IsMultiline = true,
            Icon = Icons.Description,
            Hint = "Narration"
        };
        add = new CommandButton() {
            Icon = Icons.Plus,
            Margin = new Thickness(0, 5, 5, 0),
            Width = 16,
            Height = 16,
            HorizontalAlignment = HorizontalAlignment.Right,
            Command = vm.AddEntry
        };

        Grid.SetRow(partyRPGrid, 1);
        Grid.SetRow(siteHeadQuantityGrid, 2);
        Grid.SetRow(narration, 3);
        Grid.SetRow(add, 4);
        var grid = new Grid() {
            RowDefinitions = {
                new RowDefinition(){Height = GridLength.Auto},
                new RowDefinition(){Height = GridLength.Auto},
                new RowDefinition(){Height = GridLength.Auto},
                new RowDefinition(),
                new RowDefinition(){Height = GridLength.Auto}
            },
            Children = { dateDueGrid, partyRPGrid, siteHeadQuantityGrid, narration, add }
        };
        setContent(grid);
    }
    void bind() {
        date.SetBinding(DayPicker.SelectedDateProperty, new Binding($"{nameof(vm.PurchaseSell)}.{nameof(EntryPurchaseSellText.Date)}"));
        isPurchase.SetBinding(MultiState.StateProperty, new Binding(nameof(vm.TransactionType)));
        isConstruction.SetBinding(MultiState.StateProperty, new Binding($"{nameof(vm.PurchaseSell)}.{nameof(EntryPurchaseSellText.IsConstruction)}"));
        amountDue.SetBinding(EditText.TextProperty, new Binding($"{nameof(vm.PurchaseSell)}.{nameof(EntryPurchaseSellText.Amount)}"));
        party.SetBinding(SuggestBox.TextProperty, new Binding($"{nameof(vm.PurchaseSell)}.{nameof(EntryPurchaseSellText.Party)}"));
        rpHead.SetBinding(SuggestBox.TextProperty, new Binding($"{nameof(vm.ReceiptPayment)}.{nameof(EntryReceiptPaymentText.Head)}"));
        isCash.SetBinding(MultiState.StateProperty, new Binding($"{nameof(vm.ReceiptPayment)}.{nameof(EntryReceiptPaymentText.IsCash)}"));
        amountRP.SetBinding(EditText.TextProperty, new Binding($"{nameof(vm.ReceiptPayment)}.{nameof(EntryReceiptPaymentText.Amount)}"));
        receiptPaymentList.SetBinding(ListBox.ItemsSourceProperty, new Binding(nameof(vm.ReceiptPayments)));
        site.SetBinding(SuggestBox.TextProperty, new Binding($"{nameof(vm.PurchaseSell)}.{nameof(EntryPurchaseSellText.Site)}"));
        head.SetBinding(SuggestBox.TextProperty, new Binding($"{nameof(vm.PurchaseSell)}.{nameof(EntryPurchaseSellText.Head)}"));
        subHead.SetBinding(SuggestBox.TextProperty, new Binding($"{nameof(vm.PurchaseSell)}.{nameof(EntryPurchaseSellText.SubHead)}"));
        quantity.SetBinding(EditText.TextProperty, new Binding($"{nameof(vm.PurchaseSell)}.{nameof(EntryPurchaseSellText.Quantity)}"));
        unit.SetBinding(SuggestBox.TextProperty, new Binding($"{nameof(vm.PurchaseSell)}.{nameof(EntryPurchaseSellText.Unit)}"));
        narration.SetBinding(EditText.TextProperty, new Binding($"{nameof(vm.PurchaseSell)}.{nameof(EntryPurchaseSellText.Narration)}"));

        siteAddress.SetBinding(Run.TextProperty, new Binding(nameof(vm.SiteAddress)));
        partyAddress.SetBinding(Run.TextProperty, new Binding(nameof(vm.PartyAddress)));
        partyPhone.SetBinding(Run.TextProperty, new Binding(nameof(vm.PartyPhone)));
    }

    void updatePosition() {
        var dpi = VisualTreeHelper.GetDpi(this);
        var position = PointToScreen(new Point(0, 0));
        position.X /= dpi.DpiScaleX;
        position.Y /= dpi.DpiScaleY;
        position.X += Constants.CardMargin;
        position.Y += Constants.CardMargin;
        var width = ActualWidth - Constants.CardMargin - Constants.CardMargin;
        var height = ActualHeight - Constants.CardMargin - Constants.CardMargin;
        vm.Top = position.Y;
        vm.Left = position.X;
        vm.Width = width;
        vm.Height = height;
    }
}
