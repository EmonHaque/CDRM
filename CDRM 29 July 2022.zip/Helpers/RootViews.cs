﻿class RootView
{
    public FrameworkElement Element { get; set; }
    public bool IsSeen { get; set; }
}
