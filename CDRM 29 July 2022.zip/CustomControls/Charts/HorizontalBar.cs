﻿class HorizontalBar : Grid
{
    HiBlock text;
    Border bar;
    Brush barNormal, barHighlight, textNormal, textHighlight;
    DoubleAnimation onLoadAnim;
    KeyValueSeries series;
    bool isSelected;
    public bool IsSelected {
        get { return isSelected; }
        set { isSelected = value; updateSelection(value); }
    }
    public KeyValueSeries Content => series;

    public HorizontalBar() {
        Margin = new Thickness(0, 2.5, 0, 2.5);
        Background = Brushes.Transparent;

        barNormal = Brushes.LightGray;
        barHighlight = Brushes.CornflowerBlue;
        textNormal = Brushes.LightGray;
        textHighlight = Brushes.Coral;

        text = new HiBlock() {
            TextWrapping = TextWrapping.Wrap,
            IsHitTestVisible = false
        };
        bar = new Border() {
            HorizontalAlignment = HorizontalAlignment.Left,
            CornerRadius = new CornerRadius(0, 5, 5, 0),
            Background = barNormal,
            Height = 15,
            IsHitTestVisible = false,
            RenderTransform = new ScaleTransform(0, 1)
        };
        ColumnDefinitions.Add(new ColumnDefinition() { Width = new GridLength(Constants.HorizontalBarKeyWidth) });
        ColumnDefinitions.Add(new ColumnDefinition());

        SetColumn(bar, 1);
        Children.Add(text);
        Children.Add(bar);
        
        Loaded += onLoaded;
        Unloaded += onUnloaded;

        onLoadAnim = new DoubleAnimation() {
            To = 1,
            Duration = TimeSpan.FromMilliseconds(750),
            EasingFunction = new CubicEase() { EasingMode = EasingMode.EaseIn }
        };
    }

    void onLoaded(object sender, RoutedEventArgs e) {
        series = (KeyValueSeries)DataContext;
        text.Text = series.Key;
        bar.Width = (double)series.Value / Max * (ActualWidth - Constants.HorizontalBarKeyWidth);
        ToolTip = series.Value.ToString("N0");
        text.SetBinding(HiBlock.QueryProperty, new Binding("DataContext." + nameof(AllHeadwisePurchaseVM.Query)) {
            RelativeSource = new RelativeSource(RelativeSourceMode.FindAncestor, typeof(HorizontalBarChart), 1)
        });
        bar.RenderTransform.BeginAnimation(ScaleTransform.ScaleXProperty, onLoadAnim);
    }
    void onUnloaded(object sender, RoutedEventArgs e) {
        BindingOperations.ClearAllBindings(text);
        Loaded -= onLoaded;
        Unloaded -= onUnloaded;
    }
    void updateSelection(bool value) {
        if (value) {
            bar.Background = barHighlight;
            text.Foreground = textHighlight;
        }
        else {
            bar.Background = barNormal;
            text.Foreground = textNormal;
        }
    }
    protected override void OnMouseEnter(MouseEventArgs e) {
        if (IsSelected) return;
        bar.Background = barHighlight;
        text.Foreground = textHighlight;
    }
    protected override void OnMouseLeave(MouseEventArgs e) {
        if (IsSelected) return;
        bar.Background = barNormal;
        text.Foreground = textNormal;
    }
    protected override void OnMouseLeftButtonUp(MouseButtonEventArgs e) {
        IsSelected = !IsSelected;
    }
    protected override void OnRenderSizeChanged(SizeChangedInfo sizeInfo) {
        base.OnRenderSizeChanged(sizeInfo);
        if (series is null) return;
        bar.Width = (double)series.Value / Max * (ActualWidth - Constants.HorizontalBarKeyWidth);
    }

    public int Max {
        get { return (int)GetValue(MaxProperty); }
        set { SetValue(MaxProperty, value); }
    }
    public static readonly DependencyProperty MaxProperty =
        DependencyProperty.Register("Max", typeof(int), typeof(HorizontalBar));

}