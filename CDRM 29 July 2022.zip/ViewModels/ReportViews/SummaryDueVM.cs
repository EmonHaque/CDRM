﻿class SummaryDueVM : Notifiable
{
    List<SumTransaction> entries;
    ObservableCollection<SumPartyTransaction> reportables;
    string query;
    public string Query {
        get { return query; }
        set { query = value; Reportables.Refresh(); }
    }
    bool isSettled;
    public bool IsSettled {
        get { return isSettled; }
        set { isSettled = value; Reportables.Refresh(); }
    }

    public int TotalPaid { get; set; }
    public int TotalBalance { get; set; }
    public ICollectionView Reportables { get; set; }
    public event Action CoordinateRequested;

    public SummaryDueVM() {
        entries = new List<SumTransaction>();
        reportables = new ObservableCollection<SumPartyTransaction>();
        Reportables = CollectionViewSource.GetDefaultView(reportables);
        Reportables.Filter = filter;
        Reportables.CollectionChanged += onCollectionChanged;
        getEntries();
    }

    public void Refresh() {
        CoordinateRequested?.Invoke();
        BusyWindow.Activate(SummaryDue.Left, SummaryDue.Top, SummaryDue.Width, SummaryDue.Height, "Refreshing");
        getEntries();
        BusyWindow.Terminate();
    }
    public void SortName() => sort(nameof(SumPartyTransaction.Party));
    public void SortPaid() => sort(nameof(SumPartyTransaction.Paid));
    public void SortBalance() => sort(nameof(SumPartyTransaction.Balance));

    ListSortDirection getDirection(string property) {
        var direction = property.Equals(nameof(SumPartyTransaction.Party)) ?
            ListSortDirection.Ascending :
            ListSortDirection.Descending;
        var description = Reportables.SortDescriptions.FirstOrDefault(x => x.PropertyName.Equals(property));
        if (description.PropertyName is not null) {
            direction = description.Direction == ListSortDirection.Descending ?
                ListSortDirection.Ascending :
                ListSortDirection.Descending;
        }
        return direction;
    }
    bool filter(object o) {
        if (string.IsNullOrWhiteSpace(Query)) return ((SumPartyTransaction)o).IsSettled == IsSettled;
        var s = (SumPartyTransaction)o;
        return
            s.IsSettled == IsSettled &&
            s.Party.Contains(Query, StringComparison.InvariantCultureIgnoreCase);
    }
    void sort(string property) {
        if (Reportables.IsEmpty) return;
        var direction = getDirection(property);
        using (Reportables.DeferRefresh()) {
            Reportables.SortDescriptions.Clear();
            Reportables.SortDescriptions.Add(new SortDescription(property, direction));
        }
    }
    void onCollectionChanged(object? sender, NotifyCollectionChangedEventArgs e) {
        TotalPaid = 0;
        foreach (SumPartyTransaction item in Reportables) {
            TotalPaid += item.Paid;
            TotalBalance += item.Balance;
        }
        OnPropertyChanged(nameof(TotalPaid));
        OnPropertyChanged(nameof(TotalBalance));
    }
    void getEntries() {
        entries.Clear();
        lock (SQL.key) {
            SQL.command.CommandText = @"WITH t1(PartyId, Head, Purchase, Sell) AS(
											SELECT PartyId, CASE IsSell WHEN 0 THEN 'Purchase' ELSE 'Sell' END Head,
												SUM(CASE WHEN IsSell = 0 THEN Amount ELSE 0 END),
												SUM(CASE WHEN IsSell = 1 THEN Amount ELSE 0 END)
											FROM Dues
											GROUP BY PartyId, Head
										),
										t2(PartyId, Head, Receipt, Payment) AS(
											SELECT PartyId, he.Name Head,
												SUM(CASE WHEN IsReceipt = 1 THEN Amount ELSE 0 END),
												SUM(CASE WHEN IsReceipt = 0 THEN Amount ELSE 0 END)
											FROM ReceiptPayments rp
											LEFT JOIN Heads he ON he.Id = rp.HeadId
											GROUP BY PartyId, Head
										),
										t3 (PartyId, Head, PurRec, SelPay) AS(
											SELECT * FROM t1 UNION ALL 
											SELECT PartyId, CASE Head 
												WHEN 'Payable' THEN 'Paid'
												WHEN 'Receivable' THEN 'Received'
												ELSE Head END Head,
											Receipt, Payment
											FROM t2
										)
										SELECT * FROM t3";
            var reader = SQL.command.ExecuteReader();
            while (reader.Read()) {
                entries.Add(new SumTransaction() {
                    PartyId = reader.GetInt32(0),
                    Head = reader.GetString(1),
                    PurchaseReceipt = reader.GetInt32(2),
                    SellPayment = reader.GetInt32(3)
                });
            };
            reader.Close();
            reader.DisposeAsync();
        }

        using (Reportables.DeferRefresh()) {
            Reportables.Filter = null;
            Reportables.CollectionChanged -= onCollectionChanged;
            reportables.Clear();
        }
        SumPartyTransaction group = null;
        foreach (var e in entries) {
            group = reportables.FirstOrDefault(x => x.PartyId == e.PartyId);
            if (group is null) {
                group = new SumPartyTransaction() {
                    PartyId = e.PartyId,
                    Party = AppData.parties.First(x => x.Id == e.PartyId).Name,
                    Transactions = new List<SumTransaction>()
                };
                group.Transactions.Add(e);
                reportables.Add(group);
            }
            else group.Transactions.Add(e);

            group.Balance += e.PurchaseReceipt;
            group.Balance -= e.SellPayment;
        }
        foreach (var party in reportables) {
            party.IsSettled = party.Balance == 0;
            int sell = 0;
            var sellEntry = party.Transactions.FirstOrDefault(x => x.Head.Equals("Sell"));
            if (sellEntry != null) sell = sellEntry.SellPayment;
            party.Paid = party.Transactions.Sum(x => x.SellPayment) - sell;
        }
        Reportables.Filter = filter;
        Reportables.CollectionChanged += onCollectionChanged;
    }
}
