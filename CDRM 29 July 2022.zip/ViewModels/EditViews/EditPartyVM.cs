﻿class EditPartyVM : EditBaseVM<Party>
{
    protected override CollectionViewSource cvs => new CollectionViewSource() {
        Source = AppData.parties,
        IsLiveSortingRequested = true,
        LiveSortingProperties = { nameof(IHaveName.Name) }
    };

    protected override Party clone() {
        return new Party() {
            Id = Selected.Id,
            Name = Selected.Name,
            Address = Selected.Address,
            Phone = Selected.Phone
        };
    }
    protected override void update() {
        lock (SQL.key) {
            SQL.command.CommandText = $"UPDATE Parties SET Name = @Name, Address = @Address, Phone = @Phone WHERE Id = {Selected.Id}";
            SQL.command.Parameters.AddWithValue("@Name", Edited.Name);
            SQL.command.Parameters.AddWithValue("@Address", Edited.Address);
            SQL.command.Parameters.AddWithValue("@Phone", string.IsNullOrWhiteSpace(Edited.Phone) ? DBNull.Value : Edited.Phone);
            SQL.command.ExecuteNonQuery();
            SQL.command.Parameters.Clear();
        }
        Selected.Name = Edited.Name;
        Selected.Address = Edited.Address;
        Selected.Phone = Edited.Phone;
        Selected.OnPropertyChanged(nameof(Party.Name));
        Selected.OnPropertyChanged(nameof(Party.Address));
        Selected.OnPropertyChanged(nameof(Party.Phone));
    }
}

