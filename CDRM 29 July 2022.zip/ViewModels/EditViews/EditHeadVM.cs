﻿class EditHeadVM : EditBaseVM<Head>
{
    protected override CollectionViewSource cvs => new CollectionViewSource() {
        Source = AppData.heads,
        IsLiveSortingRequested = true,
        LiveSortingProperties = { nameof(IHaveName.Name) }
    };

    protected override Head clone() {
        return new Head() {
            Id = Selected.Id,
            Name = Selected.Name
        };
    }
    protected override void update() {
        lock (SQL.key) {
            SQL.command.CommandText = $"UPDATE Heads SET Name = @Name WHERE Id = {Selected.Id}";
            SQL.command.Parameters.AddWithValue("@Name", Edited.Name);
            SQL.command.ExecuteNonQuery();
            SQL.command.Parameters.Clear();
        }
        Selected.Name = Edited.Name;
        Selected.OnPropertyChanged(nameof(Head.Name));
    }
}
