﻿class EditEntryVM : Notifiable
{
    DateTime? date;
    public DateTime? Date {
        get { return date; }
        set {
            date = value;
            GetEntries();
            IsRefreshValid = value is not null;
            OnPropertyChanged(nameof(IsRefreshValid));
        }
    }
    string query;
    public string Query {
        get { return query; }
        set { query = value?.Trim(); Entries.Refresh(); }
    }
    bool isOnEdit;
    public bool IsOnEdit {
        get { return isOnEdit; }
        set { isOnEdit = value; if (value) clone(); }
    }

    public IHaveTitle Selected { get; set; }
    public IHaveTitle Edited { get; set; }
    ObservableCollection<IHaveTitle> entries;
    CollectionViewSource entrieSource;
    public ICollectionView Entries { get; set; }
    public bool IsRefreshValid { get; set; }
    public event Action CoordinateRequested;

    public EditEntryVM() {
        entries = new ObservableCollection<IHaveTitle>();
        entrieSource = new CollectionViewSource() {
            Source = entries,
            GroupDescriptions = {
                new PropertyGroupDescription(nameof(IHaveTitle.Title))
            },
            IsLiveFilteringRequested = true,
            IsLiveGroupingRequested = true,
            LiveFilteringProperties = { nameof(IHaveTitle.Date) },
            LiveGroupingProperties = { nameof(IHaveTitle.Title) }
        };
        Entries = entrieSource.View;
        Entries.Filter = filter;
    }

    bool filter(object o) {
        if (string.IsNullOrWhiteSpace(Query)) return ((IHaveTitle)o).Date == Date;
        var e = (IHaveTitle)o;
        return e.Date == Date &&
            e.Party.Contains(Query, StringComparison.CurrentCultureIgnoreCase);
    }
    void clone() {
        if (Selected is EntryPurchaseSellText) {
            var e = (EntryPurchaseSellText)Selected;
            Edited = new EntryPurchaseSellText() {
                Title = e.Title,
                Id = e.Id,
                Date = e.Date,
                IsSell = e.IsSell,
                IsConstruction = e.IsConstruction,
                Party = e.Party,
                Site = e.Site,
                Amount = e.Amount,
                Head = e.Head,
                SubHead = e.SubHead,
                Quantity = e.Quantity,
                Unit = e.Unit,
                Narration = e.Narration
            };
        }
        else {
            var e = (EntryReceiptPaymentText)Selected;
            Edited = new EntryReceiptPaymentText() {
                Title = e.Title,
                Id = e.Id,
                Date = e.Date,
                IsCash = e.IsCash,
                IsReceipt = e.IsReceipt,
                Party = e.Party,
                Head = e.Head,
                Amount = e.Amount,
                Narration = e.Narration
            };
        }
        OnPropertyChanged(nameof(Edited));
    }
    void updateSelectedPurchaseSell(EntryPurchaseSellText e) {
        var s = (EntryPurchaseSellText)Selected;
        s.Id = e.Id;
        s.Date = e.Date;
        s.Amount = e.Amount;
        s.IsSell = e.IsSell;
        s.IsConstruction = e.IsConstruction;
        s.Site = e.Site;
        s.Party = e.Party;
        s.Head = e.Head;
        s.SubHead = e.SubHead;
        s.Unit = e.Unit;
        s.Quantity = e.Quantity;
        s.Narration = e.Narration;
        s.Title = e.Title;
        s.OnPropertyChanged(null);
    }
    void updateSelectedReceiptPayment(EntryReceiptPaymentText e) {
        var s = (EntryReceiptPaymentText)Selected;
        s.Id = e.Id;
        s.Head = e.Head;
        s.Party = e.Party;
        s.Amount = e.Amount;
        s.IsReceipt = e.IsReceipt;
        s.IsCash = e.IsCash;
        s.Date = e.Date;
        s.Narration = e.Narration;
        s.Title = e.Title;
        s.OnPropertyChanged(null);
    }
    public void Update() {
        if (Edited is null) return;
        CoordinateRequested?.Invoke();
        BusyWindow.Activate(EditEntryControl.Left, EditEntryControl.Top, EditEntryControl.Width, EditEntryControl.Height, "Updating");
        if (Edited is EntryPurchaseSellText) {
            var e = (EntryPurchaseSellText)Edited;
            var entry = new EntryPurchaseSell() {
                Id = e.Id,
                Date = e.Date.Value.ToString("yyyy-MM-dd"),
                IsSell = e.IsSell,
                IsConstruction = e.IsConstruction,
                SiteId = AppData.GetSite().Id,
                PartyId = AppData.GetParty().Id,
                HeadId = AppData.GetHead().Id,
                Amount = int.Parse(e.Amount, NumberStyles.Number, CultureInfo.CurrentCulture.NumberFormat),
                Narration = e.Narration?.Trim()
            };
            if (!string.IsNullOrWhiteSpace(e.SubHead)) entry.SubHeadId = AppData.GetSubHead().Id;
            if (!string.IsNullOrWhiteSpace(e.Quantity)) {
                entry.Quantity = double.Parse(e.Quantity);
                entry.UnitId = AppData.GetUnit().Id;
            }
            AppData.UpdatePurchaseSell(entry);
            e.Amount = entry.Amount.ToString("N0");
            updateSelectedPurchaseSell(e);
        }
        else {
            var e = (EntryReceiptPaymentText)Edited;
            var entry = new EntryReceiptPayment() {
                Id = e.Id,
                Date = e.Date.Value.ToString("yyyy-MM-dd"),
                IsCash = e.IsCash,
                IsReceipt = e.IsReceipt,
                PartyId = AppData.GetParty().Id,
                HeadId = AppData.GetHead().Id,
                Amount = int.Parse(e.Amount, NumberStyles.Number, CultureInfo.CurrentCulture.NumberFormat),
                Narration = e.Narration?.Trim()
            };
            AppData.UpdateReceiptPayment(entry);
            e.Amount = entry.Amount.ToString("N0");
            updateSelectedReceiptPayment(e);
        }
        BusyWindow.Terminate();
    }
    public void Delete() {
        if (Selected is null) return;
        CoordinateRequested?.Invoke();
        BusyWindow.Activate(EditEntryControl.Left, EditEntryControl.Top, EditEntryControl.Width, EditEntryControl.Height, "Deleting");
        if (Selected is EntryPurchaseSellText) AppData.DeletePurchaseSell(Selected.Id);
        else AppData.DeleteReceiptPayment(Selected.Id);
        entries.Remove(Selected);
        BusyWindow.Terminate();
    }
    public void GetEntries() {
        if (Date is null) return;
        CoordinateRequested?.Invoke();
        BusyWindow.Activate(EditEntry.Left, EditEntry.Top, EditEntry.Width, EditEntry.Height, "Refreshing");
        entries.Clear();
        lock (SQL.key) {
            SQL.command.CommandText = $@"SELECT Date, Amount, IsSell, IsConstruction, si.Name, pa.Name, he.Name, 
                                        sh.Name, Quantity, un.Name, Narration, d.Id FROM Dues d
                                        LEFT JOIN Sites si ON si.Id = d.SiteId
                                        LEFT JOIN Parties pa ON pa.Id = d.PartyId
                                        LEFT JOIN Heads he ON he.Id = d.HeadId
                                        LEFT JOIN SubHeads sh ON sh.Id = d.SubHeadId
                                        LEFT JOIN Units un ON un.Id = d.UnitId
                                        WHERE Date = '{Date.Value.ToString("yyyy-MM-dd")}';
                                        
                                        SELECT Date, Amount, pa.Name, he.Name, IsReceipt, IsCash, Narration, d.Id FROM ReceiptPayments d
                                        LEFT JOIN Parties pa ON pa.Id = d.PartyId
                                        LEFT JOIN Heads he ON he.Id = d.HeadId
                                        WHERE Date = '{Date.Value.ToString("yyyy-MM-dd")}'";
            var reader = SQL.command.ExecuteReader();
            while (reader.Read()) {
                var e = new EntryPurchaseSellText() {
                    Date = reader.GetDateTime(0),
                    Amount = reader.GetInt32(1).ToString("N0"),
                    IsSell = reader.GetByte(2),
                    IsConstruction = reader.GetByte(3),
                    Site = reader.GetString(4),
                    Party = reader.GetString(5),
                    Head = reader.GetString(6),
                    SubHead = reader.IsDBNull(7) ? "" : reader.GetString(7),
                    Quantity = reader.IsDBNull(8) ? "" : reader.GetString(8),
                    Unit = reader.IsDBNull(9) ? "" : reader.GetString(9),
                    Narration = reader.IsDBNull(10) ? "" : reader.GetString(10),
                    Id = reader.GetInt32(11)
                };
                e.Title = e.IsSell == 0 ? "Purchase" : "Sell";
                entries.Add(e);
            }
            reader.NextResult();
            while (reader.Read()) {
                var e = new EntryReceiptPaymentText() {
                    Date = reader.GetDateTime(0),
                    Amount = reader.GetInt32(1).ToString("N0"),
                    Party = reader.GetString(2),
                    Head = reader.GetString(3),
                    IsReceipt = reader.GetByte(4),
                    IsCash = reader.GetByte(5),
                    Narration = reader.IsDBNull(6) ? "" : reader.GetString(6),
                    Id = reader.GetInt32(7)
                };
                e.Title = e.IsReceipt == 0 ? "Payment" : "Receipt";
                entries.Add(e);
            }
            reader.Close();
            reader.DisposeAsync();

            IsRefreshValid = true;
            OnPropertyChanged(nameof(IsRefreshValid));
        }
        BusyWindow.Terminate();
    }
}
