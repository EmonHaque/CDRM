﻿class InputEntryVM : Notifiable
{
    EntryInsert entry;
    public double Top { get; set; }
    public double Left { get; set; }
    public double Width { get; set; }
    public double Height { get; set; }

    string siteAddress;
    public string SiteAddress {
        get { return siteAddress; }
        set { siteAddress = value; OnPropertyChanged(nameof(SiteAddress)); }
    }
    string partyAddress;
    public string PartyAddress {
        get { return partyAddress; }
        set { partyAddress = value; OnPropertyChanged(nameof(PartyAddress)); }
    }
    string partyPhone;
    public string PartyPhone {
        get { return partyPhone; }
        set { partyPhone = value; OnPropertyChanged(nameof(partyPhone)); }
    }

    public byte TransactionType { get; set; }
    public EntryPurchaseSellText PurchaseSell { get; set; }
    public EntryReceiptPaymentText ReceiptPayment { get; set; }
    public ObservableCollection<EntryReceiptPayment> ReceiptPayments { get; set; }
    public Action<EntryReceiptPayment> RemoveReceiptPayment { get; set; }
    public static event Action<EntryInsert> EntryRequested;
    public event Action CoordinateRequested;

    public InputEntryVM() {
        ReceiptPayments = new ObservableCollection<EntryReceiptPayment>();
        PurchaseSell = new EntryPurchaseSellText() { Date = DateTime.Today };
        ReceiptPayment = new EntryReceiptPaymentText();
        RemoveReceiptPayment = removeReceiptPayment;
    }

    bool isMultipleRPValid() {
        var first = ReceiptPayments.First();
        var date = DateTime.Parse(first.Date);
        var errors = new List<ValidationError>();

        if (PurchaseSell.Date is null) {
            errors.Add(new ValidationError() {
                Head = nameof(PurchaseSell.Date),
                Error = date.ToString("dd MMMM yyyy") + " expected"
            });
        }
        else if (!PurchaseSell.Date.Value.ToString("yyyy-MM-dd").Equals(first.Date)) {
            errors.Add(new ValidationError() {
                Head = nameof(PurchaseSell.Date),
                Error = date.ToString("dd MMM yyyy") + " expected"
            });
        }
        var party = AppData.parties.First(x => x.Id == first.PartyId).Name;
        if (!PurchaseSell.Party.Equals(party, StringComparison.InvariantCultureIgnoreCase)) {
            errors.Add(new ValidationError() {
                Head = nameof(PurchaseSell.Party),
                Error = party + " expected"
            });
        }

        if (TransactionType == 0 || TransactionType == 1) {
            if (!first.IsPurchaseOrSell) {
                var type = "";
                switch (first.IsReceipt) {
                    case 0: type = "payment"; break;
                    default: type = "receipt"; break;
                }
                errors.Add(new ValidationError() {
                    Head = "Transaction",
                    Error = type + " entry expected"
                });
            }
            else if (TransactionType != first.IsReceipt) {
                var type = "";
                switch (first.IsReceipt) {
                    case 0: type = "purchase"; break;
                    default: type = "sell"; break;
                }
                errors.Add(new ValidationError() {
                    Head = "Transaction",
                    Error = type + " entry expected"
                });
            }
            if(first.IsConstruction != PurchaseSell.IsConstruction) {
                var type = "";
                switch (first.IsConstruction) {
                    case 0: type = "Construction"; break;
                    case 1: type = "Development"; break;
                    case 2: type = "Repair"; break;
                    default: type = "Maintenance"; break;
                }
                errors.Add(new ValidationError() {
                    Head = type,
                    Error = type.ToLower() + " entry expected"
                });
            }
            foreach (var e in ReceiptPayments) {
                if (e.IsCash == ReceiptPayment.IsCash) {
                    var medium = "";
                    switch (ReceiptPayment.IsCash) {
                        case 0: medium = "Cash"; break;
                        case 1: medium = "Mobile"; break;
                        default: medium = "Discount"; break;
                    }
                    errors.Add(new ValidationError() {
                        Head = medium,
                        Error = "only 1 " + medium.ToLower() + " entry expected"
                    });
                    break;
                }
            }
        }
        else {
            var tt = TransactionType - 2;
            if (first.IsPurchaseOrSell) {
                var type = "";
                switch (first.IsReceipt) {
                    case 0: type = "purchase"; break;
                    default: type = "sell"; break;
                }
                errors.Add(new ValidationError() {
                    Head = "Transaction",
                    Error = type + " entry expected"
                });
            }
            else if (tt != first.IsReceipt) {
                var type = "";
                switch (first.IsReceipt) {
                    case 0: type = "payment"; break;
                    default: type = "receipt"; break;
                }
                errors.Add(new ValidationError() {
                    Head = "Transaction",
                    Error = type + " entry expected"
                });
            }

            var head = AppData.heads.First(x => x.Id == first.HeadId).Name;
            if (head.Equals("Discount")) head = first.HeadForDiscount;
            if (string.IsNullOrWhiteSpace(ReceiptPayment.Head)) {
                errors.Add(new ValidationError() {
                    Head = nameof(ReceiptPayment.Head),
                    Error = head + " expected"
                });
            }
            else if (!ReceiptPayment.Head.Equals(head)) {
                errors.Add(new ValidationError() {
                    Head = nameof(ReceiptPayment.Head),
                    Error = head + " expected"
                });
            }
            else {
                foreach (var e in ReceiptPayments) {
                    if (e.IsCash == ReceiptPayment.IsCash) {
                        var medium = "";
                        switch (ReceiptPayment.IsCash) {
                            case 0: medium = "Cash"; break;
                            case 1: medium = "Mobile"; break;
                            default: medium = "Discount"; break;
                        }
                        errors.Add(new ValidationError() {
                            Head = medium,
                            Error = "only 1 " + medium.ToLower() + " entry expected"
                        });
                        break;
                    }
                }
            }
        }
        bool isValid = errors.Count == 0;
        if (!isValid) {
            CoordinateRequested?.Invoke();
            var errorDialog = new ErrorDialog(Left, Top, Width, Height, errors);
            errorDialog.ShowDialog();
        }
        return isValid;
    }

    public void AddReceiptPayment() {
        if (ReceiptPayments.Count > 0) {
            if (!isMultipleRPValid()) return;
        }

        var rp = new EntryReceiptPaymentText() {
            Date = PurchaseSell.Date,
            Party = PurchaseSell.Party,
            Amount = ReceiptPayment.Amount,
            IsCash = ReceiptPayment.IsCash,
            Narration = PurchaseSell.Narration
        };
        switch (TransactionType) {
            case 0: // Purchase
                rp.Head = rp.IsCash == 2 ? "Discount" : "Payable";
                rp.IsReceipt = 0;
                rp.IsConstruction = PurchaseSell.IsConstruction;
                break;
            case 1: // Sell
                rp.Head = rp.IsCash == 2 ? "Discount" : "Receivable";
                rp.IsReceipt = 1;
                rp.IsConstruction = PurchaseSell.IsConstruction;
                break;
            case 2: // Payment
                rp.Head = rp.IsCash == 2 ? "Discount" : ReceiptPayment.Head;
                rp.IsReceipt = 0;
                break;
            default: // Receipt
                rp.Head = rp.IsCash == 2 ? "Discount" : ReceiptPayment.Head;
                rp.IsReceipt = 1;
                break;
        }
        var validator = new ReceiptPaymentValidator(rp);
        if (!validator.IsValid()) {
            CoordinateRequested?.Invoke();
            var errorDialog = new ErrorDialog(Left, Top, Width, Height, validator.Errors);
            errorDialog.ShowDialog();
            return;
        }
        if (!validator.DoesExist()) {
            CoordinateRequested?.Invoke();
            var confirmDialog = new ConfirmCreationDialog(Left, Top, Width, Height, validator.Errors);
            var result = confirmDialog.ShowDialog();
            if (!result.HasValue) return;
            if (!result.Value) return;

            foreach (var e in validator.Errors) {
                switch (e.Head) {
                    case "Head": AppData.InsertHead(ReceiptPayment.Head.Trim()); break;
                    case "Party": {
                            var dialog = new CreatePartyDialog(Left, Top, Width, Height, PurchaseSell.Party);
                            dialog.ShowDialog();
                            var (address, phone) = dialog.GetAddressAndPhone();
                            var party = new Party() {
                                Name = PurchaseSell.Party.Trim(),
                                Address = address.Trim(),
                                Phone = phone?.Trim()
                            };
                            AppData.InsertParty(party);
                        }
                        break;
                }
            }
        }
        var entry = new EntryReceiptPayment() {
            Date = rp.Date.Value.ToString("yyyy-MM-dd"),
            IsCash = rp.IsCash,
            IsReceipt = rp.IsReceipt,
            IsPurchaseOrSell = TransactionType < 2,
            IsConstruction = rp.IsConstruction,
            PartyId = AppData.GetParty().Id,
            HeadId = AppData.GetHead().Id,
            Amount = int.Parse(rp.Amount, NumberStyles.Number, CultureInfo.CurrentCulture.NumberFormat),
            Narration = rp.Narration
        };
        if (rp.Head.Equals("Discount")) {
            entry.HeadForDiscount = ReceiptPayment.Head;
        }
        ReceiptPayments.Add(entry);

        PurchaseSell.Narration = "";
        var head = ReceiptPayment.Head;
        ReceiptPayment = new EntryReceiptPaymentText() { IsCash = entry.IsCash };
        if (TransactionType == 2 || TransactionType == 3) {
            ReceiptPayment.Head = head;
        }
        OnPropertyChanged(nameof(ReceiptPayment));
        PurchaseSell.OnPropertyChanged(nameof(PurchaseSell.Narration));
    }
    public void SetSiteAddress() {
        if (string.IsNullOrWhiteSpace(PurchaseSell.Site)) {
            SiteAddress = null;
            return;
        }
        var site = AppData.sites.FirstOrDefault(x => x.Name.Equals(PurchaseSell.Site, StringComparison.InvariantCultureIgnoreCase));
        if (site is null) {
            SiteAddress = null;
            return;
        }
        SiteAddress = site.Address;
    }
    public void SetPartyAddress() {
        if (string.IsNullOrWhiteSpace(PurchaseSell.Party)) {
            PartyAddress = PartyPhone = null;
            return;
        }
        var party = AppData.parties.FirstOrDefault(x => x.Name.Equals(PurchaseSell.Party, StringComparison.InvariantCultureIgnoreCase));
        if (party is null) {
            PartyAddress = PartyPhone = null;
            return;
        }
        PartyAddress = party.Address;
        PartyPhone = party.Phone;
    }
    public void AddEntry() {
        if (TransactionType == 0 /*Purchase*/ || TransactionType == 1 /*Sell*/) {
            addPurchaseSell();
        }
        else {
            entry = new EntryInsert() {
                Date = PurchaseSell.Date.Value.ToString("yyyy-MM-dd"),
                SiteId = TransactionType == 2 /*Payment*/ ? int.MaxValue : int.MaxValue - 1,
                IsTopLevel = false
            };
            foreach (var item in ReceiptPayments) {
                entry.ReceiptPayments.Add(item);
            }
            EntryRequested?.Invoke(entry);
            ReceiptPayments.Clear();
        }
    }
    void addPurchaseSell() {
        var validator = new PurchaseSellValidator(PurchaseSell);
        if (!validator.IsValid()) {
            CoordinateRequested?.Invoke();
            var errorDialog = new ErrorDialog(Left, Top, Width, Height, validator.Errors);
            errorDialog.ShowDialog();
            return;
        }
        if (!validator.DoesExist()) {
            CoordinateRequested?.Invoke();
            var confirmDialog = new ConfirmCreationDialog(Left, Top, Width, Height, validator.Errors);
            var result = confirmDialog.ShowDialog();
            if (!result.HasValue) return;
            if (!result.Value) return;

            foreach (var e in validator.Errors) {
                switch (e.Head) {
                    case nameof(PurchaseSell.Site): {
                            var dialog = new CreateSiteDialog(Left, Top, Width, Height, PurchaseSell.Site);
                            dialog.ShowDialog();
                            var site = new Site() {
                                Name = PurchaseSell.Site.Trim(),
                                Address = dialog.GetAddress().Trim()
                            };
                            AppData.InsertSite(site);
                        }
                        break;
                    case nameof(PurchaseSell.Party): {
                            var dialog = new CreatePartyDialog(Left, Top, Width, Height, PurchaseSell.Party);
                            dialog.ShowDialog();
                            var (address, phone) = dialog.GetAddressAndPhone();
                            var party = new Party() {
                                Name = PurchaseSell.Party.Trim(),
                                Address = address.Trim(),
                                Phone = phone?.Trim()
                            };
                            AppData.InsertParty(party);
                        }
                        break;
                    case nameof(PurchaseSell.Head): AppData.InsertHead(PurchaseSell.Head.Trim()); break;
                    case nameof(PurchaseSell.SubHead): AppData.InsertSubHead(PurchaseSell.SubHead.Trim()); break;
                    case nameof(PurchaseSell.Unit): AppData.InsertUnit(PurchaseSell.Unit.Trim()); break;
                }
            }
        }
        entry = new EntryInsert() {
            Date = PurchaseSell.Date.Value.ToString("yyyy-MM-dd"),
            IsSell = (byte)TransactionType,
            IsConstruction = PurchaseSell.IsConstruction,
            SiteId = AppData.GetSite().Id,
            PartyId = AppData.GetParty().Id,
            HeadId = AppData.GetHead().Id,
            Amount = int.Parse(PurchaseSell.Amount),
            IsTopLevel = true,
            Narration = PurchaseSell.Narration?.Trim()
        };
        if (!string.IsNullOrWhiteSpace(PurchaseSell.SubHead)) entry.SubHeadId = AppData.GetSubHead().Id;
        if (!string.IsNullOrWhiteSpace(PurchaseSell.Quantity)) {
            entry.Quantity = double.Parse(PurchaseSell.Quantity);
            entry.UnitId = AppData.GetUnit().Id;
        }
        foreach (var item in ReceiptPayments) {
            entry.ReceiptPayments.Add(item);
        }
        EntryRequested?.Invoke(entry);
        PurchaseSell = new EntryPurchaseSellText() { Date = DateTime.Today };
        OnPropertyChanged(nameof(PurchaseSell));
        ReceiptPayments.Clear();
    }
    void removeReceiptPayment(object o) {
        var e = (EntryReceiptPayment)o;
        ReceiptPayments.Remove(e);
    }
}
