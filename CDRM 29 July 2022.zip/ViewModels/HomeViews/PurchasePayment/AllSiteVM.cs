﻿class AllSiteVM : Notifiable
{
    public DateTime? From { get; set; }
    public DateTime? To { get; set; }
    public byte State { get; set; }
    public int Total { get; set; }
    public List<KeyValueSeries> Data { get; set; }

    public AllSiteVM() {
        To = DateTime.Today;
        From = To.Value.AddYears(-1);
        getEntries();
    }

    public void Refresh() {
        getEntries();
    }
    void getEntries() {
        string query = "";
        if (State == 4 /*All*/) query = $@"SELECT Sites.Name, SUM(Amount) FROM Dues
                                        LEFT JOIN Sites ON Sites.Id = SiteId
                                        WHERE IsSell = 0 AND Date BETWEEN '{From.Value.ToString("yyyy - MM - dd")}' 
                                        AND '{To.Value.ToString("yyyy - MM - dd")}'
                                        GROUP BY Sites.Name";
        else query = @$"SELECT Sites.Name, SUM(Amount) FROM Dues
                        LEFT JOIN Sites ON Sites.Id = SiteId
                        WHERE IsSell = 0 AND IsConstruction = {State} AND 
                        Date BETWEEN '{From.Value.ToString("yyyy-MM-dd")}' AND '{To.Value.ToString("yyyy-MM-dd")}'
                        GROUP BY Sites.Name";
        Data = new List<KeyValueSeries>();
        Total = 0;
        lock (SQL.key) {
            SQL.command.CommandText = query;
            var reader = SQL.command.ExecuteReader();
            while (reader.Read()) {
                var e = new KeyValueSeries() {
                    Key = reader.GetString(0),
                    Value = reader.GetInt32(1)
                };
                Total += e.Value;
                Data.Add(e);
            }
            reader.Close();
            reader.DisposeAsync();
        }
        OnPropertyChanged(nameof(Total));
        OnPropertyChanged(nameof(Data));
    }
}

