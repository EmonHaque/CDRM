﻿class SingleHeadwisePurchaseVM : SinglePurchasePayableBaseVM<Head>
{
    protected override ObservableCollection<Head> source => AppData.heads;
    protected override string datewiseQuery => $@"WITH t AS(
                                        	SELECT Date, SUM(Amount) FROM Dues WHERE HeadId = {Id} AND IsSell = 0
                                        	GROUP BY Date
                                        	ORDER BY Date DESC
                                        	LIMIT {maxDataPoints}
                                        )
                                        SELECT * FROM t ORDER BY Date";
    protected override string monthwiseQuery => $@"WITH t AS(
                                        	SELECT strftime('%Y - %m', Date) Month, SUM(Amount) FROM Dues
                                        	WHERE HeadId = {Id} AND IsSell = 0
                                        	GROUP BY Month
                                        	ORDER BY Month DESC
                                        	LIMIT {maxDataPoints}
                                        )
                                        SELECT * FROM t ORDER BY Month";
}
