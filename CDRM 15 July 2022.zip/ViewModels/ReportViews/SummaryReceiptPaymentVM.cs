﻿class SummaryReceiptPaymentVM : Notifiable
{
    DateTime from, to;
    Type sumType;
    PropertyInfo primaryProperty, secondaryProperty;
    Predicate<SumReceiptPayment> queryCondition;
    Func<SumReceiptPayment, ReceiptPayment, bool> sumCondition;
    List<ReceiptPayment> entries;
    ObservableCollection<SumReceiptPayment> reportables;
    string query;
    public string Query {
        get { return query; }
        set { query = value; Reportables.Refresh(); }
    }
    public int TotalPayment { get; set; }
    public int TotalReceipt { get; set; }
    public int TotalGroup { get; set; }
    public byte Group { get; set; }
    public ICollectionView Reportables { get; set; }

    public SummaryReceiptPaymentVM() {
        entries = new List<ReceiptPayment>();
        reportables = new ObservableCollection<SumReceiptPayment>();
        from = to = DateTime.Today;
        sumType = typeof(ReceiptPayment);
        Reportables = CollectionViewSource.GetDefaultView(reportables);
        Reportables.GroupDescriptions.Add(new PropertyGroupDescription(nameof(SumReceiptPayment.PrimaryGroup)));
        Reportables.Filter = filter;
        Reportables.CollectionChanged += onCollectionChanged;
        SummaryPurchaseSellVM.Refreshed += onRefreshed;
    }

    public void Refresh() {
        BusyWindow.Activate(SummaryReceiptPayment.Left, SummaryReceiptPayment.Top, SummaryReceiptPayment.Width,
            SummaryReceiptPayment.Height, "Refreshing");
        getEntries();
        setCondition();
        makeSummary();
        BusyWindow.Terminate();
    }
    public void SortParticulars() => sort(nameof(SumReceiptPayment.PrimaryGroup), nameof(SumReceiptPayment.SecondaryGroup));
    public void SortPayments() => sort(nameof(SumReceiptPayment.Payment), nameof(SumReceiptPayment.TotalPayment));
    public void SortReceipts() => sort(nameof(SumReceiptPayment.Receipt), nameof(SumReceiptPayment.TotalReceipt));

    bool filter(object o) {
        if (string.IsNullOrWhiteSpace(Query)) return true;
        return queryCondition.Invoke((SumReceiptPayment)o);
    }
    ListSortDirection getDirection(string primaryProperty) {
        var direction = primaryProperty.Equals(nameof(SumReceiptPayment.PrimaryGroup)) ?
            ListSortDirection.Ascending :
            ListSortDirection.Descending;
        var description = Reportables.SortDescriptions.FirstOrDefault(x => x.PropertyName.Equals(primaryProperty));
        if (description.PropertyName is not null) {
            direction = description.Direction == ListSortDirection.Descending ?
                ListSortDirection.Ascending :
                ListSortDirection.Descending;
        }
        return direction;
    }
    void sort(string directionalProperty, string property) {
        if (Reportables.IsEmpty) return;
        var direction = getDirection(directionalProperty);
        using (Reportables.DeferRefresh()) {
            Reportables.SortDescriptions.Clear();
            if (directionalProperty.Equals(nameof(SumReceiptPayment.PrimaryGroup))) {
                Reportables.SortDescriptions.Add(new SortDescription(directionalProperty, direction));
                Reportables.SortDescriptions.Add(new SortDescription(property, direction));
            }
            else {
                Reportables.SortDescriptions.Add(new SortDescription(property, direction));
                Reportables.SortDescriptions.Add(new SortDescription(directionalProperty, direction));
            }
        }
    }
    void setCondition() {
        var month = sumType.GetProperty(nameof(ReceiptPayment.Month));
        var party = sumType.GetProperty(nameof(ReceiptPayment.Party));
        switch (Group) {
            case 0: // Month
                primaryProperty = month;
                secondaryProperty = party;
                sumCondition = (s, d) => s.PrimaryGroup.Equals(d.Month) && s.SecondaryGroup.Equals(d.Party);
                queryCondition = x => x.SecondaryGroup.Contains(Query, StringComparison.InvariantCultureIgnoreCase);
                break;
            default: // Party
                primaryProperty = party;
                secondaryProperty = month;
                sumCondition = (s, d) => s.PrimaryGroup.Equals(d.Party) && s.SecondaryGroup.Equals(d.Month);
                queryCondition = x => x.PrimaryGroup.Contains(Query, StringComparison.InvariantCultureIgnoreCase);
                break;
        }
    }
    void onRefreshed(ReportDates d) {
        from = d.From;
        to = d.To;
        Refresh();
    }
    void onCollectionChanged(object? sender, NotifyCollectionChangedEventArgs e) {
        TotalPayment = TotalReceipt = 0;
        foreach (SumReceiptPayment s in Reportables) {
            TotalPayment += s.Payment;
            TotalReceipt += s.Receipt;
        }
        TotalGroup = Reportables.Groups.Count;
        OnPropertyChanged(nameof(TotalPayment));
        OnPropertyChanged(nameof(TotalReceipt));
        OnPropertyChanged(nameof(TotalGroup));
    }
    void makeSummary() {
        List<SumReceiptPayment> sums = new();
        SumReceiptPayment group = null;
        foreach (var e in entries) {
            group = sums.FirstOrDefault(x => sumCondition.Invoke(x, e));
            if (group is null) {
                group = new SumReceiptPayment() {
                    PrimaryGroup = primaryProperty.GetValue(e, null).ToString(),
                    SecondaryGroup = secondaryProperty.GetValue(e, null).ToString(),
                    Payment = e.Payment,
                    Receipt = e.Receipt,
                    Count = 1,
                    Entries = new List<RPToolTipEntry>()
                };
                sums.Add(group);
            }
            else {
                group.Receipt += e.Receipt;
                group.Payment += e.Payment;
                group.Count++;
            }
            group.Entries.Add(new RPToolTipEntry() {
                Date = e.Date,
                Payment = e.Payment,
                Receipt = e.Receipt,
                IsCash = e.IsCash,
                Head = e.Head
            });
        }
        foreach (var item in sums) {
            int currentReceipt = 0;
            int currentPayment = 0;
            var groups = sums.Where(x => x.PrimaryGroup.Equals(item.PrimaryGroup)).ToList();
            if(groups.Count > 0) {
                foreach (var g in groups) {
                    currentPayment += g.Payment;
                    currentReceipt += g.Receipt;
                }
                item.TotalReceipt = currentReceipt;
                item.TotalPayment = currentPayment;
            }
            else {
                item.TotalReceipt = item.Receipt;
                item.TotalPayment = item.Payment;
            }
        }

        Reportables.CollectionChanged -= onCollectionChanged;

        TotalReceipt = TotalPayment = 0;
        reportables.Clear();
        foreach (var item in sums) {
            TotalPayment += item.Payment;
            TotalReceipt += item.Receipt;
            reportables.Add(item);
        }
        Reportables.CollectionChanged += onCollectionChanged;
        TotalGroup = Reportables.Groups.Count;

        OnPropertyChanged(nameof(TotalPayment));
        OnPropertyChanged(nameof(TotalReceipt));
        OnPropertyChanged(nameof(TotalGroup));
    }
    void getEntries() {
        entries.Clear();
        lock (SQL.key) {
            SQL.command.CommandText = $@"SELECT Date, pa.Name, he.Name, coalesce(Narration, ''), strftime('%Y - %m', Date),
                                        	CASE WHEN IsReceipt=0 THEN Amount ELSE 0 END,
                                        	CASE WHEN IsReceipt=1 THEN Amount ELSE 0 END,
                                        IsCash
                                        FROM ReceiptPayments rp
                                        LEFT JOIN Parties pa ON pa.Id = rp.PartyId
                                        LEFT JOIN Heads he ON he.Id = rp.HeadId
                                        WHERE Date BETWEEN '{from.ToString("yyyy-MM-dd")}' AND '{to.ToString("yyyy-MM-dd")}'";
            var reader = SQL.command.ExecuteReader();
            while (reader.Read()) {
                var e = new ReceiptPayment() {
                    Date = reader.GetDateTime(0),
                    Party = reader.GetString(1),
                    Head = reader.GetString(2),
                    Narration = reader.GetString(3),
                    Month = reader.GetString(4),
                    Payment = reader.GetInt32(5),
                    Receipt = reader.GetInt32(6),
                    IsCash = reader.GetByte(7)
                };
                entries.Add(e);
                
            }
            reader.Close();
            reader.DisposeAsync();
        }
    }
}
