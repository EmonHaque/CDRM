﻿class EditSubHeadVM : EditBaseVM<SubHead>
{
    protected override CollectionViewSource cvs => new CollectionViewSource() {
        Source = AppData.subHeads,
        IsLiveSortingRequested = true,
        LiveSortingProperties = { nameof(IHaveName.Name) }
    };
    public EditSubHeadVM() {
        Edited = new SubHead();
    }
    protected override void insert() {
        lock (SQL.key) {
            SQL.command.CommandText = $"UPDATE SubHeads SET Name = @Name WHERE Id = {Selected.Id}";
            SQL.command.Parameters.AddWithValue("@Name", Edited.Name);
            SQL.command.ExecuteNonQuery();
            SQL.command.Parameters.Clear();
        }
        Selected.Name = Edited.Name;
        Selected.OnPropertyChanged(nameof(SubHead.Name));
    }
}
