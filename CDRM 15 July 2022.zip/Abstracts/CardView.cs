﻿abstract class CardView : View
{
    public abstract string Header { get; }
    public override FrameworkElement container => card;
    Card card;
    public CardView() {
        card = new Card() { Header = Header };
        AddVisualChild(card);
        KeyboardNavigation.SetTabNavigation(this, KeyboardNavigationMode.Cycle);
        FocusManager.SetIsFocusScope(this, true);
    }
    protected void setContent(FrameworkElement element) => card.Content = element;
    protected void addActions(ActionButton action) {
        card.AddActions(action);
    }
}
