﻿class EditReceiptPayment : Grid
{
    List<ValidationError> errors;
    DayPicker date;
    SuggestBox party, head;
    TextBlock partyAddressBlock, partyPhoneBlock;
    Run partyAddress, partyPhone;
    EditText amount, narration;
    MultiState isCash, isReceipt;
    ActionButton update;
    EntryReceiptPaymentText originalEntry, entry;
    public EntryReceiptPaymentText Entry {
        get { return entry; }
        set {
            entry = value;
            originalEntry = entry.Clone();
            DataContext = value;
        }
    }
    public event Action<IHaveTitle> Updated;

    public EditReceiptPayment() {
        date = new DayPicker() {
            Hint = "Date",
            DateFormat = "dd/MM/yyyy"
        };
        isReceipt = new MultiState() {
            Icons = new string[] { Icons.Payment, Icons.Receipt },
            Texts = new string[] { "Payment", "Receipt" },
            IsIconInfront = true,
            Margin = new Thickness(5, 5, 0, 0),
            VerticalAlignment = VerticalAlignment.Center
        };
        isCash = new MultiState() {
            Icons = new string[] { Icons.Cash, Icons.Phone, Icons.Noncash },
            Texts = new string[] { "Cash", "Mobile", "Discount" },
            IsIconInfront = true,
            Margin = new Thickness(5, 5, 5, 0),
            VerticalAlignment = VerticalAlignment.Center
        };
        amount = new EditText() {
            Icon = Icons.Amount,
            Hint = "Amount"
        };
        Grid.SetColumn(isReceipt, 1);
        Grid.SetColumn(isCash, 2);
        Grid.SetColumn(amount, 3);
        var dateAmountGrid = new Grid() {
            ColumnDefinitions = {
                new ColumnDefinition(){ Width = new GridLength(2, GridUnitType.Star)},
                new ColumnDefinition(),
                new ColumnDefinition(),
                new ColumnDefinition(){ Width = new GridLength(1.55, GridUnitType.Star)}
            },
            Children = { date, isReceipt, isCash, amount }
        };
        head = new SuggestBox() {
            IsRequired = true,
            Icon = Icons.ControlHead,
            Hint = "Head",
            Source = AppData.heads
        };
        party = new SuggestBox() {
            IsRequired = true,
            Icon = Icons.Tenant,
            Hint = "Party",
            Source = AppData.parties
        };
        partyAddress = new Run();
        partyPhone = new Run();
        partyAddressBlock = new TextBlock() {
            Margin = new Thickness(5, 5, 0, 5),
            Inlines = { "Address: ", partyAddress }
        };
        partyPhoneBlock = new TextBlock() {
            Margin = new Thickness(5, 5, 0, 10),
            Inlines = { "Phone: ", partyPhone }
        };
        narration = new EditText() {
            Margin = new Thickness(0, 15, 0, 0),
            IsMultiline = true,
            Icon = Icons.Description,
            Hint = "Narration"
        };
        update = new ActionButton() {
            Icon = Icons.Checked,
            ToolTip = "Update",
            Command = onUpdateEntry,
            Width = 14,
            Height = 14,
            Margin = new Thickness(2, 5, 0, 0),
            HorizontalAlignment = HorizontalAlignment.Left
        };
        RowDefinitions.Add(new RowDefinition() { Height = GridLength.Auto });
        RowDefinitions.Add(new RowDefinition() { Height = GridLength.Auto });
        RowDefinitions.Add(new RowDefinition() { Height = GridLength.Auto });
        RowDefinitions.Add(new RowDefinition() { Height = GridLength.Auto });
        RowDefinitions.Add(new RowDefinition() { Height = GridLength.Auto });
        RowDefinitions.Add(new RowDefinition());
        RowDefinitions.Add(new RowDefinition() { Height = GridLength.Auto });

        SetRow(head, 1);
        SetRow(party, 2);
        SetRow(partyAddressBlock, 3);
        SetRow(partyPhoneBlock, 4);
        SetRow(narration, 5);
        SetRow(update, 6);

        Children.Add(dateAmountGrid);
        Children.Add(head);
        Children.Add(party);
        Children.Add(partyAddressBlock);
        Children.Add(partyPhoneBlock);
        Children.Add(narration);
        Children.Add(update);
        bind();
    }

    void bind() {
        DataContext = Entry;
        date.SetBinding(DayPicker.SelectedDateProperty, new Binding(nameof(Entry.Date)));
        party.SetBinding(SuggestBox.TextProperty, new Binding(nameof(Entry.Party)));
        head.SetBinding(SuggestBox.TextProperty, new Binding(nameof(Entry.Head)));
        amount.SetBinding(EditText.TextProperty, new Binding(nameof(Entry.Amount)));
        narration.SetBinding(EditText.TextProperty, new Binding(nameof(Entry.Narration)));
        isCash.SetBinding(MultiState.StateProperty, new Binding(nameof(Entry.IsCash)));
        isReceipt.SetBinding(MultiState.StateProperty, new Binding(nameof(Entry.IsReceipt)));
    }
    void onUpdateEntry() {
        if (!isValid()) {
            var errorDialog = new ErrorDialog(EditEntry.Left, EditEntry.Top, EditEntry.Width, EditEntry.Height, errors);
            errorDialog.ShowDialog();
            return;
        }
        if (isEqual()) return;
        
        if (!doesExist()) {
            foreach (var e in errors) {
                switch (e.Head) {
                    case "Head": AppData.InsertHead(entry.Head.Trim()); break;
                    case "Party": {
                            var dialog = new CreatePartyDialog(EditEntry.Left, EditEntry.Top, EditEntry.Width, EditEntry.Height, entry.Party);
                            dialog.ShowDialog();
                            var (address, phone) = dialog.GetAddressAndPhone();
                            var party = new Party() {
                                Name = entry.Party.Trim(),
                                Address = address.Trim(),
                                Phone = phone?.Trim()
                            };
                            AppData.InsertParty(party);
                        }
                        break;
                }
            }
        }

        Updated?.Invoke(entry);
        originalEntry = entry.Clone();
    }

    bool doesExist() {
        bool doesExist = true;
        if (!AppData.HasParty(entry.Party)) {
            errors.Add(new ValidationError() {
                Head = "Party",
                Error = Constants.DoesntExist
            });
            doesExist = false;
        }
        if (!AppData.HasHead(entry.Head)) {
            errors.Add(new ValidationError() {
                Head = "Head",
                Error = Constants.DoesntExist
            });
            doesExist = false;
        }
        return doesExist;
    }
    bool isEqual() {
        if (originalEntry.IsReceipt != entry.IsReceipt) {
            if (originalEntry.IsReceipt == 0) entry.Title = "Receipt";
            else entry.Title = "Payment";
            return false;
        }
        if (originalEntry.Date != entry.Date) return false;
        if (originalEntry.IsCash != entry.IsCash) return false;
        if (!originalEntry.Head.Equals(entry.Head, StringComparison.InvariantCultureIgnoreCase)) return false;
        if (!originalEntry.Party.Equals(entry.Party, StringComparison.InvariantCultureIgnoreCase)) return false;
        if (!originalEntry.Narration.Equals(entry.Narration, StringComparison.InvariantCultureIgnoreCase)) return false;

        double originalAmount, editedAmount;
        double.TryParse(originalEntry.Amount, out originalAmount);
        double.TryParse(entry.Amount, out editedAmount);
        if (originalAmount != editedAmount) return false;

        return true;
    }
    bool isValid() {
        bool isValid = true;
        errors = new List<ValidationError>();
        if (entry.Date is null) {
            errors.Add(new ValidationError() {
                Head = nameof(entry.Date),
                Error = Constants.CannotBeEmpty
            });
            isValid = false;
        }
        if (string.IsNullOrWhiteSpace(entry.Party)) {
            errors.Add(new ValidationError() {
                Head = nameof(entry.Party),
                Error = Constants.CannotBeEmpty
            });
            isValid = false;
        }
        if (string.IsNullOrWhiteSpace(entry.Head)) {
            errors.Add(new ValidationError() {
                Head = nameof(entry.Head),
                Error = Constants.CannotBeEmpty
            });
            isValid = false;
        }

        if (string.IsNullOrWhiteSpace(entry.Amount)) {
            errors.Add(new ValidationError() {
                Head = nameof(entry.Amount),
                Error = Constants.CannotBeEmpty
            });
            isValid = false;
        }
        return isValid;
    }
}
