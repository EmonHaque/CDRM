﻿class EditNameControl<T> : StackPanel
{
    TextBlock name;
    TextBox editedName;
    ActionButton edit, cancel, save;
    StackPanel buttonStack;

    #region DependencyProperties
    public new static readonly DependencyProperty NameProperty;
    public static readonly DependencyProperty EditedNameProperty;
    public static readonly DependencyProperty IsOnEditProperty;
    static EditNameControl() {
        NameProperty = DependencyProperty.Register("Name", typeof(string), typeof(EditNameControl<T>));
        EditedNameProperty = DependencyProperty.Register("EditedName", typeof(string), typeof(EditNameControl<T>), new FrameworkPropertyMetadata() {
            DefaultValue = null,
            BindsTwoWayByDefault = true
        });
        IsOnEditProperty = DependencyProperty.Register("IsOnEdit", typeof(bool), typeof(EditNameControl<T>), new FrameworkPropertyMetadata() {
            DefaultValue = false,
            BindsTwoWayByDefault = true
        });
    }
    public new string Name {
        get { return (string)GetValue(NameProperty); }
        set { SetValue(NameProperty, value); }
    }
    public bool IsOnEdit {
        get { return (bool)GetValue(IsOnEditProperty); }
        set { SetValue(IsOnEditProperty, value); }
    }
    public string EditedName {
        get { return (string)GetValue(EditedNameProperty); }
        set { SetValue(EditedNameProperty, value); }
    }
    #endregion

    public EditNameControl() {
        VerticalAlignment = VerticalAlignment.Center;
        Background = Brushes.Transparent;
        edit = new ActionButton() {
            ToolTip = "Edit",
            Icon = Icons.Pencil,
            HorizontalAlignment = HorizontalAlignment.Right,
            Visibility = Visibility.Hidden,
            Command = setEdit
        };
        cancel = new ActionButton() {
            ToolTip = "Cancel",
            Icon = Icons.Close,
            HorizontalAlignment = HorizontalAlignment.Right,
            Visibility = Visibility.Collapsed,
            Command = cancelEdit
        };
        save = new ActionButton() {
            Margin = new Thickness(0, 0, 5, 0),
            ToolTip = "Save",
            Icon = Icons.Checked,
            HorizontalAlignment = HorizontalAlignment.Right,
            Visibility = Visibility.Collapsed,
            Command = saveEdit
        };
        buttonStack = new StackPanel() {
            Orientation = Orientation.Horizontal,
            HorizontalAlignment = HorizontalAlignment.Right,
            Children = { edit, save, cancel }
        };

        name = new TextBlock() { HorizontalAlignment = HorizontalAlignment.Center };
        editedName = new TextBox() {
            TextAlignment = TextAlignment.Center,
            BorderThickness = new Thickness(0, 0, 0, 0.5),
            Visibility = Visibility.Collapsed
        };

        Children.Add(buttonStack);
        Children.Add(name);
        Children.Add(editedName);

        name.SetBinding(TextBlock.TextProperty, new Binding(nameof(Name)) { Source = this });
        editedName.SetBinding(TextBox.TextProperty, new Binding(nameof(EditedName)) { Source = this, UpdateSourceTrigger = UpdateSourceTrigger.PropertyChanged });
    }

    void setEdit() {
        if (string.IsNullOrWhiteSpace(Name)) return;
        IsOnEdit = true;
        editedName.Text = Name;
        name.Visibility = Visibility.Collapsed;
        edit.Visibility = Visibility.Collapsed;
        editedName.Visibility = Visibility.Visible;
        cancel.Visibility = Visibility.Visible;
        save.Visibility = Visibility.Visible;
    }
    void cancelEdit() {
        if (!EditedName.Equals(Name)) EditedName = Name;
        resetVisibility();
    }
    void saveEdit() {
        List<ValidationError> errors = new();
        if (string.IsNullOrWhiteSpace(EditedName)) {
            errors.Add(new ValidationError() {
                Head = "Name",
                Error = "cannot be empty"
            });
        }
        if (errors.Count > 0) {
            var errorDialog = new ErrorDialog(EditBase<T>.Left, EditBase<T>.Top, EditBase<T>.Width, EditBase<T>.Height, errors);
            errorDialog.ShowDialog();
            return;
        }
        resetVisibility();
    }
    void resetVisibility() {
        IsOnEdit = false;
        editedName.Visibility = Visibility.Collapsed;
        cancel.Visibility = Visibility.Collapsed;
        save.Visibility = Visibility.Collapsed;
        name.Visibility = Visibility.Visible;
        edit.Visibility = Visibility.Hidden;
    }
    protected override void OnMouseEnter(MouseEventArgs e) {
        base.OnMouseEnter(e);
        if (!IsOnEdit) edit.Visibility = Visibility.Visible;
    }
    protected override void OnMouseLeave(MouseEventArgs e) {
        base.OnMouseLeave(e);
        if (!IsOnEdit) edit.Visibility = Visibility.Hidden;
    }
}
