﻿class EditEntryControl : Grid
{
    public static double Top { get; set; }
    public static double Left { get; set; }
    public new static double Width { get; set; }
    public new static double Height { get; set; }

    EditReceiptPayment receiptPayment;
    EditPurchaseSell purchaseSell;

    #region DependencyProperties
    public static readonly DependencyProperty EntryProperty;
    public static readonly DependencyProperty EntryEditedProperty;
    static EditEntryControl() {
        EntryProperty = DependencyProperty.Register("Entry", typeof(IHaveTitle), typeof(EditEntryControl),
            new PropertyMetadata() {
                DefaultValue = null,
                PropertyChangedCallback = (d, e) => {
                    var o = (EditEntryControl)d;
                    if (e.NewValue is null) {
                        o.purchaseSell.Visibility = Visibility.Hidden;
                        o.receiptPayment.Visibility = Visibility.Hidden;
                        return;
                    }
                    if (e.NewValue is EntryPurchaseSellText) {
                        o.receiptPayment.Visibility = Visibility.Hidden;
                        o.purchaseSell.Visibility = Visibility.Visible;
                        o.purchaseSell.Entry = (EntryPurchaseSellText)e.NewValue;
                    }
                    else {
                        o.purchaseSell.Visibility = Visibility.Hidden;
                        o.receiptPayment.Visibility = Visibility.Visible;
                        o.receiptPayment.Entry = (EntryReceiptPaymentText)e.NewValue;
                    }
                }
            });

        EntryEditedProperty = DependencyProperty.Register("EntryEdited", typeof(IHaveTitle), typeof(EditEntryControl));
    }
    public IHaveTitle Entry {
        get { return (IHaveTitle)GetValue(EntryProperty); }
        set { SetValue(EntryProperty, value); }
    }
    public IHaveTitle EntryEdited {
        get { return (IHaveTitle)GetValue(EntryEditedProperty); }
        set { SetValue(EntryEditedProperty, value); }
    }
    #endregion

    public EditEntryControl() {
        Margin = new Thickness(0, 5, 0, 0);
        receiptPayment = new EditReceiptPayment();
        purchaseSell = new EditPurchaseSell();
        Children.Add(receiptPayment);
        Children.Add(purchaseSell);
        purchaseSell.Visibility = Visibility.Hidden;
        receiptPayment.Visibility = Visibility.Hidden;
        Loaded += onLoaded;
        Unloaded += onUnloaded;

    }

    void onLoaded(object sender, RoutedEventArgs e) {
        receiptPayment.Updated += onUpdate;
        purchaseSell.Updated += onUpdate;
        App.Current.MainWindow.LocationChanged += onRelocate;
    }
    void onUnloaded(object sender, RoutedEventArgs e) {
        receiptPayment.Updated -= onUpdate;
        purchaseSell.Updated -= onUpdate;
        App.Current.MainWindow.LocationChanged -= onRelocate;
    }
    void onUpdate(IHaveTitle o) => EntryEdited = o;

    void onRelocate(object? sender, EventArgs e) => updatePosition();
    protected override void OnRenderSizeChanged(SizeChangedInfo sizeInfo) {
        base.OnRenderSizeChanged(sizeInfo);
        updatePosition();
    }
    void updatePosition() {
        var position = PointToScreen(new Point(0, 0));
        var dpi = VisualTreeHelper.GetDpi(this);
        position.X /= dpi.DpiScaleX;
        position.Y /= dpi.DpiScaleY;

        Left = position.X - 7;
        Top = position.Y - 5;
        Width = ActualWidth + 14;
        Height = ActualHeight + 10;
    }
}
