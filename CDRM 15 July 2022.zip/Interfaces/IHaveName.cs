﻿interface IHaveName
{
    string Name { get; set; }
}
