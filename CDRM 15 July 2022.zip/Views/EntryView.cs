﻿class EntryView : View
{
    override public string Icon => Icons.Add;
    public override FrameworkElement container => grid;
    Grid grid;
    public EntryView() {
        var input = new InputEntry();
        var list = new ListEntries();
        Grid.SetColumn(list, 1);
        grid = new Grid() {
            ColumnDefinitions = {
                new ColumnDefinition(),
                new ColumnDefinition()
            },
            Children = { input, list }
        };
        AddVisualChild(grid);
    }
}
