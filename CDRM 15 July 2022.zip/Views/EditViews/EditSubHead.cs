﻿class EditSubHead : EditBase<SubHead>
{
    public override string Header => "Subhead";
    public override string Icon => Icons.Head;

    EditSubHeadVM vm = new();
    EditNameControl<SubHead> name = new();
    protected override IEdit<SubHead> viewModel => vm;
    protected override FrameworkElement editElement => name;

    protected override void bind() {
        base.bind();
        name.SetBinding(EditNameControl<SubHead>.NameProperty, new Binding($"{nameof(vm.Selected)}.{nameof(Unit.Name)}"));
        name.SetBinding(EditNameControl<SubHead>.EditedNameProperty, new Binding($"{nameof(vm.Edited)}.{nameof(Unit.Name)}"));
        name.SetBinding(EditNameControl<SubHead>.IsOnEditProperty, new Binding(nameof(vm.IsOnEdit)));
    }
}
