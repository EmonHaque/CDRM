﻿class ReportView : ViewContainer
{
    override public string Icon => Icons.Ledger;

    public ReportView() {        
        Children.Add(new SummaryViews());
        Children.Add(new ReportParty());
    }
}

class SummaryViews : View
{
    override public string Icon => Icons.Sigma;
    public override FrameworkElement container => grid;
    Grid grid;
    public SummaryViews() : base() {
        var purchaseSell = new SummaryPurchaseSell();
        var transactions = new ViewContainer(NavPosition.Bottom) {
            Children = {
                new SummaryReceiptPayment(),
                new SummaryDue()
            }
        };

        Grid.SetColumn(transactions, 1);
        grid = new Grid() {
            ColumnDefinitions = {
                    new ColumnDefinition(){Width = new GridLength(2.5, GridUnitType.Star)},
                    new ColumnDefinition(),
                },
            Children = { purchaseSell, transactions }
        };
        AddVisualChild(grid);
    }
}
