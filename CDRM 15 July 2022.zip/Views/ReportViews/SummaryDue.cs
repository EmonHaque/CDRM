﻿class SummaryDue : CardView
{
    public override string Header => "Outstanding";
    public override string Icon => Icons.HandCoin;
}
