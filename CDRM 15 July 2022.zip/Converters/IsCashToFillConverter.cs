﻿class IsCashToFillConverter : IValueConverter
{
    public object Convert(object value, Type targetType, object parameter, CultureInfo culture) {
        var id = (byte)value;
        switch (id) {
            case 0: return new SolidColorBrush(Colors.LightGreen);
            case 1: return new SolidColorBrush(Colors.Yellow);
            default: return new SolidColorBrush(Colors.Coral);
        }
    }

    public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture) {
        throw new NotImplementedException();
    }
}
