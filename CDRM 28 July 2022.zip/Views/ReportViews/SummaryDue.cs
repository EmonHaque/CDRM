﻿class SummaryDue : CardView
{
    public override string Header => "Due / Settled";
    public override string Icon => Icons.HandCoin;

    public static double Top { get; set; }
    public static double Left { get; set; }
    public new static double Width { get; set; }
    public new static double Height { get; set; }

    DependencyPropertyDescriptor biStateDescriptor;
    Grid container;
    EditText query;
    BiState isSettled;
    ActionButton refresh;
    ListBox entries;
    TextBlock totalPaid, totalBalance;
    SortToggle paid, balance;
    ColumnDefinition balanceHeaderColumn, balanceFooterColumn;
    Run noOfParties;
    SummaryDueVM vm;

    public override void OnFirstSight() {
        base.OnFirstSight();
        vm = new SummaryDueVM();
        DataContext = vm;
        initializeUI();
        bind();
        vm.CoordinateRequested += onCoordinateRequest;
        Loaded += onLoaded;  // if you hook it in onLoaded, it remains null in vm
        Unloaded += onUnloaded;
    }
    void onLoaded(object sender, RoutedEventArgs e) {
        biStateDescriptor = DependencyPropertyDescriptor.FromProperty(BiState.IsTrueProperty, typeof(BiState));
        biStateDescriptor.AddValueChanged(isSettled, onStateChanged);
    }
    void onUnloaded(object sender, RoutedEventArgs e) {
        vm.CoordinateRequested -= onCoordinateRequest; 
        biStateDescriptor.RemoveValueChanged(isSettled, onStateChanged);
    }
    void onCoordinateRequest() => updatePosition();
    void onStateChanged(object? sender, EventArgs e) {
        if (isSettled.IsTrue) {
            balanceHeaderColumn.Width = new GridLength(0);
            balanceFooterColumn.Width = new GridLength(0);
        }
        else {
            balanceHeaderColumn.Width = new GridLength(Constants.AmountColumnWidth);
            balanceFooterColumn.Width = new GridLength(Constants.AmountColumnWidth);
        }
    }
    void initializeUI() {
        #region 1st Row
        query = new EditText() {
            Hint = "Search",
            Icon = Icons.Search,
            IsTrimBottomRequested = true
        };
        isSettled = new BiState() {
            Margin = new Thickness(0, 5, 0, 0),
            Text = "is settled?"
        };
        refresh = new ActionButton() {
            Icon = Icons.Refresh,
            Margin = new Thickness(5, 5, 0, 0),
            Command = vm.Refresh
        };
        Grid.SetColumn(isSettled, 1);
        Grid.SetColumn(refresh, 2);
        var topGrid = new Grid() {
            Margin = new Thickness(0,5,0,0),
            ColumnDefinitions = {
                new ColumnDefinition(),
                new ColumnDefinition(){Width = GridLength.Auto},
                new ColumnDefinition(){Width = GridLength.Auto}
            },
            Children = { query, isSettled, refresh }
        };
        #endregion

        #region Header
        var party = new SortToggle() {
            Text = "Party",
            Icon = Icons.SortSwap,
            Command = vm.SortName
        };
        paid = new SortToggle() {
            Text = "Paid",
            Icon = Icons.SortSwap,
            IsRightAligned = true,
            Command = vm.SortPaid
        };
        balance = new SortToggle() {
            Text = "Due",
            Icon = Icons.SortSwap,
            IsRightAligned = true,
            Command = vm.SortBalance
        };
        Grid.SetColumn(paid, 1);
        Grid.SetColumn(balance, 2);

        balanceHeaderColumn = new ColumnDefinition() { Width = new GridLength(Constants.AmountColumnWidth) };
        var headerGrid = new Grid() {
            Margin = new Thickness(0, 0, Constants.LeadgerRightMargin, 1),
            ColumnDefinitions = {
                new ColumnDefinition(),
                new ColumnDefinition() { Width = new GridLength(Constants.AmountColumnWidth) },
                balanceHeaderColumn
            },
            Children = { party, paid, balance }
        };
        var header = new Border() {
            Margin = new Thickness(5, 0, 0, 5),
            Padding = new Thickness(3, 0, 0, 0),
            BorderThickness = new Thickness(0, 0, 0, Constants.BottomLineThickness),
            BorderBrush = Brushes.LightGray,
            Child = headerGrid
        };
        #endregion

        entries = new ListBox() {
            ItemTemplateSelector = new PartyTransactionSelector(),
            Resources = {
                {
                    typeof(ScrollViewer),
                    new Style() {
                        Setters = {
                            new Setter(ScrollViewer.HorizontalScrollBarVisibilityProperty, ScrollBarVisibility.Disabled),
                            new Setter(ScrollViewer.TemplateProperty, new LedgerScrollTemplate())
                        }
                    }
                }
            }
        };

        #region footer
        noOfParties = new Run();
        var text = new TextBlock() { Inlines = { "Total of ", noOfParties } };
        totalPaid = new TextBlock() { HorizontalAlignment = HorizontalAlignment.Right };
        totalBalance = new TextBlock() { HorizontalAlignment = HorizontalAlignment.Right };
        Grid.SetColumn(totalPaid, 1);
        Grid.SetColumn(totalBalance, 2);

        balanceFooterColumn = new ColumnDefinition() { Width = new GridLength(Constants.AmountColumnWidth) };
        var footerGrid = new Grid() {
            Margin = new Thickness(0, 0, Constants.LeadgerRightMargin, 0),
            ColumnDefinitions = {
                new ColumnDefinition(),
                new ColumnDefinition() { Width = new GridLength(Constants.AmountColumnWidth) },
                balanceFooterColumn
            },
            Children = { text, totalPaid, totalBalance }
        };
        var footer = new Border() {
            Margin = new Thickness(5, 5, 0, 0),
            Padding = new Thickness(3, 0, 0, 0),
            BorderThickness = new Thickness(0, Constants.BottomLineThickness, 0, 0),
            BorderBrush = Brushes.LightGray,
            Child = footerGrid
        };
        #endregion

        Grid.SetRow(header, 1);
        Grid.SetRow(entries, 2);
        Grid.SetRow(footer, 3);
        container = new Grid() {
            RowDefinitions = {
                new RowDefinition(){Height = GridLength.Auto},
                new RowDefinition(){Height = GridLength.Auto},
                new RowDefinition(),
                new RowDefinition(){Height = GridLength.Auto},
            },
            Children = { topGrid, header, entries, footer }
        };
        setContent(container);
    }
    void bind() {
        entries.SetBinding(ListBox.ItemsSourceProperty, new Binding(nameof(vm.Reportables)));
        noOfParties.SetBinding(Run.TextProperty, new Binding("Items.Count") { Source = entries, Mode = BindingMode.OneWay });
        query.SetBinding(EditText.TextProperty, new Binding(nameof(vm.Query)) { Mode = BindingMode.OneWayToSource });
        isSettled.SetBinding(BiState.IsTrueProperty, new Binding(nameof(vm.IsSettled)));
        totalPaid.SetBinding(TextBlock.TextProperty, new Binding(nameof(vm.TotalPaid)) { StringFormat = Constants.NumberFormat });
        totalBalance.SetBinding(TextBlock.TextProperty, new Binding(nameof(vm.TotalBalance)) { StringFormat = Constants.NumberFormat });
    }

    void updatePosition() {
        var dpi = VisualTreeHelper.GetDpi(this);
        var topLeft = container.TranslatePoint(new Point(), this);
        var position = PointToScreen(topLeft);

        position.X /= dpi.DpiScaleX;
        position.Y /= dpi.DpiScaleY;

        Top = position.Y - 5;
        Left = position.X - 5;
        Width = container.ActualWidth + 10;
        Height = container.ActualHeight + 10;
    }
}
