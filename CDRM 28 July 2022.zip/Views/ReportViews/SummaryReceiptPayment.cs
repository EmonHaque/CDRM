﻿class SummaryReceiptPayment : CardView
{
    public override string Header => "Payment / Receipt";
    public override string Icon => Icons.HandClap;

    public static double Top { get; set; }
    public static double Left { get; set; }
    public new static double Width { get; set; }
    public new static double Height { get; set; }
    public static bool IsHidden { get; set; }

    DependencyPropertyDescriptor expandStateDescriptor;
    Grid container;
    MultiState groupBy;
    ExpanderState expandState;
    ActionButton refresh;
    EditText search;
    TextBlock totalPayment, totalReceipt;
    Run totalSummaryEntries, totalSummaryGroups, groupName;
    ListBox summaryEntries;
    SummaryReceiptPaymentVM vm;

    public override void OnFirstSight() {
        base.OnFirstSight();
        vm = new SummaryReceiptPaymentVM();
        DataContext = vm;
        initializeUI();
        bind();

        vm.CoordinateRequested += onCoordinateRequest; // if you hook it in onLoaded, it remains null in vm
        Loaded += onLoaded;
        Unloaded += onUnloaded;
    }
    void onLoaded(object sender, RoutedEventArgs e) {
        expandStateDescriptor = DependencyPropertyDescriptor.FromProperty(ExpanderState.IsTrueProperty, typeof(ExpanderState));
        expandStateDescriptor.AddValueChanged(expandState, onIsExpandedChanged);
        IsVisibleChanged += onVisibilityChanged;
    }
    void onUnloaded(object sender, RoutedEventArgs e) {
        vm.CoordinateRequested -= onCoordinateRequest;
        Loaded -= onLoaded;
        Unloaded -= onUnloaded;
        expandStateDescriptor.RemoveValueChanged(expandState, onIsExpandedChanged);
        IsVisibleChanged -= onVisibilityChanged;
    }
    void onCoordinateRequest() => updatePosition();
    void onIsExpandedChanged(object? sender, EventArgs e) {
        var items = Helper.FindVisualChildren<GroupItem>(summaryEntries);
        if (expandState.IsTrue) {
            foreach (GroupItem item in items) item.Tag = true;
            expandState.ToolTip = "Collapse";
        }
        else {
            foreach (GroupItem item in items) item.Tag = false;
            expandState.ToolTip = "Expand";
        }
    }
    void onVisibilityChanged(object sender, DependencyPropertyChangedEventArgs e) => IsHidden = !IsVisible;
    void initializeUI() {
        expandState = new ExpanderState() { ToolTip = "Expand" };
        groupBy = new MultiState() {
            Margin = new Thickness(0,0,5,0),
            Tips = new string[] {"month", "party"},
            Icons = new string[] { Icons.Calendar, Icons.Tenant }
        };
        refresh = new ActionButton() {
            Icon = Icons.Refresh,
            ToolTip = refresh,
            Command = () => {
                vm.Refresh();
                groupName.Text = groupBy.Tips[groupBy.State];
            }
        };
        search = new EditText() {
            Hint = "Search",
            Icon = Icons.Search,
            IsTrimBottomRequested = true
        };
        Grid.SetColumn(expandState, 1);
        Grid.SetColumn(groupBy, 2);
        Grid.SetColumn(refresh, 3);
        var topGrid = new Grid() {
            ColumnDefinitions = {
                new ColumnDefinition(),
                new ColumnDefinition(){Width = GridLength.Auto},
                
                new ColumnDefinition(){Width = GridLength.Auto},
                new ColumnDefinition(){Width = GridLength.Auto}
            },
            Children = { search, expandState, groupBy, refresh }
        };

        #region header
        var summaryParticulars = new SortToggle() {
            Text = "Particulars",
            Icon = Icons.SortSwap,
            Command = vm.SortParticulars
        };
        var summaryPPayment = new SortToggle() {
            Text = "Payment",
            Icon = Icons.SortSwap,
            IsRightAligned = true,
            Command = vm.SortPayments
        };
        var summaryReceipt = new SortToggle() {
            Text = "Receipt",
            Icon = Icons.SortSwap,
            IsRightAligned = true,
            Command = vm.SortReceipts
        };
        Grid.SetColumn(summaryPPayment, 1);
        Grid.SetColumn(summaryReceipt, 2);
        var headerGrid = new Grid() {
            Margin = new Thickness(0, 0, Constants.LeadgerRightMargin, 1),
            ColumnDefinitions = {
                new ColumnDefinition(),
                new ColumnDefinition() { Width = new GridLength(Constants.AmountColumnWidth) },
                new ColumnDefinition() { Width = new GridLength(Constants.AmountColumnWidth) }
            },
            Children = { summaryParticulars, summaryPPayment, summaryReceipt }
        };
        var header = new Border() {
            Margin = new Thickness(5, 0, 0, 5),
            Padding = new Thickness(3, 0, 0, 0),
            BorderThickness = new Thickness(0, 0, 0, Constants.BottomLineThickness),
            BorderBrush = Brushes.LightGray,
            Child = headerGrid
        };
        #endregion

        summaryEntries = new ListBox() {
            ItemTemplate = new RPSumEntryTemplate(),
            GroupStyle = {
                new GroupStyle() {
                    ContainerStyle = new Style(typeof(GroupItem)) {
                        Setters = {
                            new Setter(GroupItem.TemplateProperty, new RPGroupTemplate(groupBy))
                        }
                    }
                }
            },
            Resources = {
                {
                    typeof(ScrollViewer),
                    new Style() {
                        Setters = {
                            new Setter(ScrollViewer.HorizontalScrollBarVisibilityProperty, ScrollBarVisibility.Disabled),
                            new Setter(ScrollViewer.TemplateProperty, new LedgerScrollTemplate(false))
                        }
                    }
                }
            }
        };

        #region footer
        totalSummaryEntries = new Run();
        totalSummaryGroups = new Run();
        groupName = new Run() { Text = "month" };
        var entryBlock = new TextBlock() { Inlines = { "Total of ", totalSummaryEntries, " entries in ", totalSummaryGroups, " ", groupName } };
        totalPayment = new TextBlock() { HorizontalAlignment = HorizontalAlignment.Right };
        totalReceipt = new TextBlock() { HorizontalAlignment = HorizontalAlignment.Right };
        Grid.SetColumn(totalPayment, 1);
        Grid.SetColumn(totalReceipt, 2);
        var footerGrid = new Grid() {
            Margin = new Thickness(0, 0, Constants.LeadgerRightMargin, 0),
            ColumnDefinitions = {
                new ColumnDefinition(),
                new ColumnDefinition() { Width = new GridLength(Constants.AmountColumnWidth) },
                new ColumnDefinition() { Width = new GridLength(Constants.AmountColumnWidth) }
            },
            Children = { entryBlock, totalPayment, totalReceipt }
        };
        var footer = new Border() {
            Margin = new Thickness(5, 5, 0, 0),
            Padding = new Thickness(3, 0, 0, 0),
            BorderThickness = new Thickness(0, Constants.BottomLineThickness, 0, 0),
            BorderBrush = Brushes.LightGray,
            Child = footerGrid
        };
        #endregion

        Grid.SetRow(header, 1);
        Grid.SetRow(summaryEntries, 2);
        Grid.SetRow(footer, 3);

        container = new Grid() {
            Margin = new Thickness(0,5,0,0),
            RowDefinitions = {
                new RowDefinition(){ Height = GridLength.Auto},
                new RowDefinition(){ Height = GridLength.Auto},
                new RowDefinition(),
                new RowDefinition(){ Height = GridLength.Auto}
            },
            Children = {topGrid, header, summaryEntries, footer }
        };
        setContent(container);
    }
    void bind() {
        summaryEntries.SetBinding(ListBox.ItemsSourceProperty, new Binding(nameof(vm.Reportables)));
        totalPayment.SetBinding(TextBlock.TextProperty, new Binding(nameof(vm.TotalPayment)) { StringFormat = Constants.NumberFormat});
        totalReceipt.SetBinding(TextBlock.TextProperty, new Binding(nameof(vm.TotalReceipt)) { StringFormat = Constants.NumberFormat });
        totalSummaryEntries.SetBinding(Run.TextProperty, new Binding("Items.Count") { Source = summaryEntries, Mode = BindingMode.OneWay });
        totalSummaryGroups.SetBinding(Run.TextProperty, new Binding(nameof(vm.TotalGroup)));
        groupBy.SetBinding(MultiState.StateProperty, new Binding(nameof(vm.Group)) { Mode = BindingMode.OneWayToSource });
        search.SetBinding(EditText.TextProperty, new Binding(nameof(vm.Query)));
    }
    void updatePosition() {
        var dpi = VisualTreeHelper.GetDpi(this);
        var topLeft = container.TransformToAncestor(this).Transform(new Point(0, 0));
        var position = PointToScreen(topLeft);

        position.X /= dpi.DpiScaleX;
        position.Y /= dpi.DpiScaleY;

        Top = position.Y - 10;
        Left = position.X - 5;
        Width = container.ActualWidth + 10;
        Height = container.ActualHeight + 15;
    }
}
