﻿class SinglePartyTransaction : SinglePurchasePayables<Party>
{
    public override string Icon => Icons.Tenant;

    SinglePartyTransactionVM viewModel = new();
    PinLineBarChart pbc = new();
    protected override SinglePurchasePayableBaseVM<Party> vm => viewModel;
    protected override string hint => "Party";
}
