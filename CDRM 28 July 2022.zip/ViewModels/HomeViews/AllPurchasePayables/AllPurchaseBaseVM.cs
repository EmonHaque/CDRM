﻿abstract class AllPurchaseBaseVM : Notifiable
{
    string query;
    public string Query {
        get { return query; }
        set { query = value; Data?.Refresh(); }
    }
    object selected;
    public object Selected {
        get { return selected; }
        set { selected = value; onSelectedChanged(); }
    }

    public ReportDates Dates { get; set; }
    public ICollectionView Data { get; set; }
    protected abstract string command { get; }

    public AllPurchaseBaseVM() {
        Dates = new ReportDates() {
            From = DateTime.Today.AddYears(-1),
            To = DateTime.Today
        };
        getEntries();
    }

    public void Refresh() => getEntries();
    protected abstract void onSelectedChanged();
    public virtual void SortPurchase() {
        if (Data is null) return;
        if (Data.SortDescriptions.Count > 0) {
            var direction = Data.SortDescriptions.First().Direction;
            if (direction == ListSortDirection.Descending) {
                using (Data.DeferRefresh()) {
                    Data.SortDescriptions.Clear();
                    Data.SortDescriptions.Add(new SortDescription(nameof(KeyValueSeries.Value), ListSortDirection.Ascending));
                }
            }
            else {
                using (Data.DeferRefresh()) {
                    Data.SortDescriptions.Clear();
                    Data.SortDescriptions.Add(new SortDescription(nameof(KeyValueSeries.Value), ListSortDirection.Descending));
                }
            }
        }
        else {
            Data.SortDescriptions.Add(new SortDescription(nameof(KeyValueSeries.Value), ListSortDirection.Descending));
        }
    }
    protected virtual bool filter(object o) {
        if (string.IsNullOrWhiteSpace(Query)) return true;
        return ((KeyValueSeries)o).Key.Contains(Query, StringComparison.InvariantCultureIgnoreCase);
    }
    protected virtual object getData(SqliteDataReader reader) {
        var kvs = new KeyValueSeries() {
            Key = reader.GetString(0),
            Value = reader.GetInt32(1)
        };
        return kvs;
    }
    protected virtual void getEntries() {
        var data = new List<object>();
        lock (SQL.key) {
            SQL.command.CommandText = command;
            var reader = SQL.command.ExecuteReader();
            while (reader.Read()) 
                data.Add(getData(reader));
            
            reader.Close();
            reader.DisposeAsync();
        }
        Data = CollectionViewSource.GetDefaultView(data);
        Data.Filter = filter;
        OnPropertyChanged(nameof(Data));
    }
}
