﻿class AllHeadwisePurchaseVM : AllPurchaseBaseVM
{
    public static event Action<ReportDates, KeyValueSeries> SelectionChanged;
    protected override string command => $@"SELECT Heads.Name, SUM(Amount) FROM Dues
                                        LEFT JOIN Heads ON Heads.Id = Dues.HeadId
                                        WHERE IsSell = 0 AND 
                                        Date BETWEEN '{Dates.From.Value.ToString("yyyy-MM-dd")}' AND '{Dates.To.Value.ToString("yyyy-MM-dd")}'
                                        GROUP BY Heads.Name";
    protected override void onSelectedChanged() {
        SelectionChanged?.Invoke(Dates, (KeyValueSeries)Selected);
    }
}
