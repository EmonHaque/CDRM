﻿abstract class SinglePurchasePayableBaseVM<T> : Notifiable where T : IHaveName
{
    CollectionViewSource selectionSource;
    protected int maxDataPoints = 15;
    protected int purchase, paid;
    string query;
    public string Query {
        get { return query; }
        set { query = value; SelectionView?.Refresh(); }
    }
    int? id;
    public int? Id {
        get { return id; }
        set { id = value; getEntries(); }
    }
    public byte State { get; set; }
    //public string Total { get; set; }
    public ICollectionView SelectionView { get; }
    public List<object> Data { get; set; }
    public virtual string Total => $"Total {purchase.ToString("N0")}";
    protected abstract ObservableCollection<T> source { get; }
    protected abstract string datewiseQuery { get; }
    protected abstract string monthwiseQuery { get; }

    public SinglePurchasePayableBaseVM() {
        selectionSource = new CollectionViewSource() { Source = source };
        SelectionView = selectionSource.View;
        SelectionView.Filter = filter;
    }

    public void Refresh() => getEntries();

    protected virtual object getData(SqliteDataReader reader) {
        var kvs = new KeyValueSeries() {
            Key = reader.GetString(0),
            Value = reader.GetInt32(1)
        };
        purchase += kvs.Value;
        return kvs;
    }
    bool filter(object o) {
        if (string.IsNullOrWhiteSpace(Query)) return true;
        return ((T)o).Name.Contains(Query, StringComparison.InvariantCultureIgnoreCase);
    }
    void getEntries() {
        int count;
        count = purchase = paid = 0;
        Data = new List<object>();
        if (Id is null) {
            OnPropertyChanged(nameof(Data));
            OnPropertyChanged(nameof(Total));
            return;
        }
        lock (SQL.key) {
            SQL.command.CommandText = State == 0? datewiseQuery : monthwiseQuery;
            var reader = SQL.command.ExecuteReader();
            while (reader.Read()) {
                Data.Add(getData(reader));
                count++;
            }
            reader.Close();
            reader.DisposeAsync();
        }
        //if(T is Party) {

        //}
        //else {

        //}
        //Total = @"Purchase: " + purchase.ToString("N0") + ", paid " + paid.ToString("N0") + " in " +
        //            count.ToString() + (State == 0 ? " days" : " months");
        OnPropertyChanged(nameof(Total));
        OnPropertyChanged(nameof(Data));
    }
}
