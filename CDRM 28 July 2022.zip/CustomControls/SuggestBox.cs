﻿class SuggestBox : Grid
{
    static bool isFocusingInput; // this is to avoid weird effect on MouseOver. When you move mouse too fast on multiple controls, all of their input gets focus and cursor blinks all over at the same time
    TextBlock hint;
    TextBox input;
    Separator separator;
    Path leftIcon, invalidIcon, validIcon;

    TranslateTransform translateHint;
    ScaleTransform scaleHint;
    DoubleAnimation translateHintAnim, scaleHintAnim;
    ColorAnimation brushAnim;
    SolidColorBrush brush;
    Color normalColor, highlightColor;
    bool isHintMoved, isQueryableInput;
    Popup popup;
    ListBox list;
    ICollectionView source;
    bool isRequired;
    public bool IsRequired {
        get { return isRequired; }
        set {
            isRequired = value;
            if (value) {
                SetColumnSpan(input, 1);
                invalidIcon.Visibility = Visibility.Visible;
            }
            else {
                SetColumnSpan(input, 2);
                invalidIcon.Visibility = Visibility.Collapsed;
            }
        }
    }
    public string Icon { get; set; }
    public string Hint { get; set; }
    public Action LostFocusAction { get; set; }

    public SuggestBox() {
        Focusable = true;
        Margin = Constants.ControlMargin;
        normalColor = Colors.LightGray;
        highlightColor = Colors.CornflowerBlue;
        brush = new SolidColorBrush(normalColor);

        initializeControl();

        RowDefinitions.Add(new RowDefinition() /*{ Height = GridLength.Auto }*/);
        RowDefinitions.Add(new RowDefinition() /*{ Height = GridLength.Auto }*/);
        ColumnDefinitions.Add(new ColumnDefinition() { Width = GridLength.Auto });
        ColumnDefinitions.Add(new ColumnDefinition());
        ColumnDefinitions.Add(new ColumnDefinition() { Width = GridLength.Auto });

        Children.Add(leftIcon);
        Children.Add(input);
        Children.Add(hint);
        Children.Add(invalidIcon);
        Children.Add(validIcon);
        Children.Add(separator);

        initializeAnimations();

        list = new ListBox() {
            HorizontalContentAlignment = HorizontalAlignment.Stretch,
            ItemsSource = source,
            DisplayMemberPath = nameof(IHaveName.Name)
        };
        double th = Constants.BottomLineThickness;
        popup = new Popup() {
            AllowsTransparency = true,
            HorizontalOffset = 2,
            VerticalOffset = 5,
            MaxHeight = 200,
            MinWidth = 200,
            StaysOpen = false,
            PlacementTarget = input,
            Child = new Border() {
                Background = Constants.Background,
                BorderThickness = new Thickness(th, th, th, th),
                CornerRadius = new CornerRadius(5),
                BorderBrush = Brushes.LightGray,
                Padding = new Thickness(5, 5, 3, 5),
                Child = list
            }
        };
        Loaded += onLoaded;
        Unloaded += onUnloaded;
    }

    void onLoaded(object sender, RoutedEventArgs e) {
        hint.Text = Hint;
        if (Icon != null) {
            leftIcon.Data = Geometry.Parse(Icon);
            leftIcon.Visibility = Visibility.Visible;
        }
        input.SetBinding(TextBox.TextProperty, new Binding(nameof(Text)) {
            Source = this,
            UpdateSourceTrigger = UpdateSourceTrigger.PropertyChanged
        });

        list.KeyUp += setTextOnEnter;
        list.MouseLeftButtonUp += setTextOnClick;

        input.PreviewKeyUp += onBoxKeyUp;
        input.PreviewKeyDown += onBoxKeyDown;
    }
    void onUnloaded(object sender, RoutedEventArgs e) {
        list.KeyUp -= setTextOnEnter;
        list.MouseLeftButtonUp -= setTextOnClick;
        input.KeyUp -= onBoxKeyUp;
        input.KeyDown -= onBoxKeyDown;
    }
    void initializeControl() {
        translateHint = new TranslateTransform();
        scaleHint = new ScaleTransform();

        hint = new TextBlock {
            Padding = new Thickness(5, 0, 5, 0),
            HorizontalAlignment = HorizontalAlignment.Left,
            VerticalAlignment = VerticalAlignment.Center,
            RenderTransform = new TransformGroup {
                Children = { scaleHint, translateHint }
            }
        };
        input = new TextBox {
            BorderThickness = new Thickness(0),
            Margin = Constants.ComboInputBoxMargin,
            VerticalAlignment = VerticalAlignment.Bottom,
            CaretBrush = Brushes.White
        };
        separator = new Separator { Background = brush, Height = Constants.BottomLineThickness };
        leftIcon = new Path {
            Fill = brush,
            Width = 12,
            Height = 12,
            Stretch = Stretch.Uniform,
            HorizontalAlignment = HorizontalAlignment.Left,
            Visibility = Visibility.Collapsed
        };
        invalidIcon = new Path {
            Data = Geometry.Parse(Icons.Info),
            Fill = Brushes.Coral,
            Width = 12,
            Height = 12,
            Stretch = Stretch.Uniform,
            Visibility = Visibility.Collapsed,
            HorizontalAlignment = HorizontalAlignment.Right
        };
        validIcon = new Path {
            Data = Geometry.Parse(Icons.Checked),
            Fill = Brushes.LightGreen,
            Width = 12,
            Height = 12,
            Stretch = Stretch.Uniform,
            Visibility = Visibility.Collapsed
        };

        SetRow(separator, 1);
        SetColumnSpan(separator, 3);
        SetColumn(input, 1);
        SetColumnSpan(input, 2);
        SetColumn(hint, 1);
        SetColumn(invalidIcon, 2);
        SetColumn(validIcon, 2);
    }
    void initializeAnimations() {
        var duration = TimeSpan.FromMilliseconds(250);
        var ease = new CubicEase { EasingMode = EasingMode.EaseInOut };
        scaleHintAnim = new DoubleAnimation {
            Duration = duration,
            EasingFunction = ease
        };
        translateHintAnim = new DoubleAnimation {
            Duration = duration,
            EasingFunction = ease
        };
        brushAnim = new ColorAnimation {
            Duration = duration,
            EasingFunction = ease
        };
    }
    void animateHint() {
        translateHint.BeginAnimation(TranslateTransform.YProperty, translateHintAnim);
        scaleHint.BeginAnimation(ScaleTransform.ScaleYProperty, scaleHintAnim);
        scaleHint.BeginAnimation(ScaleTransform.ScaleXProperty, scaleHintAnim);
    }
    void moveHintUp() {
        isHintMoved = true;
        scaleHintAnim.To = Constants.ScaleHintTo;
        translateHintAnim.To = Constants.UpHintBy;
        animateHint();
    }
    void moveHintDown() {
        isHintMoved = false;
        scaleHintAnim.To = 1;
        translateHintAnim.To = 0;
        animateHint();
    }
    bool filter(object o) {
        if (string.IsNullOrWhiteSpace(input.Text)) return true;
        return ((IHaveName)o).Name.ToLower().Contains(input.Text.ToLower());
    }
    void onBoxKeyDown(object sender, KeyEventArgs e) {
        isQueryableInput = false;
        if (e.Key == Key.Tab) {
            e.Handled = true;
            if (popup.IsOpen) {
                if (list.SelectedIndex == -1)
                    list.SelectedIndex = 0;

                setText();
                popup.IsOpen = false;
            }
            input.MoveFocus(new TraversalRequest(FocusNavigationDirection.Next));
            return;
        }
        if (e.Key == Key.Down) return;

        if (Keyboard.Modifiers == ModifierKeys.Control
            || Keyboard.Modifiers == ModifierKeys.Alt
            || Keyboard.Modifiers == ModifierKeys.Shift) {
            popup.IsOpen = false;
            return;
        }
        //something's wrong below
        int keyValue = (int)e.Key;
        bool isDigit = keyValue >= 0x30 && keyValue <= 0x39; // numbers ok?
        bool isLetter = (e.Key >= Key.A) || (e.Key <= Key.Z); // letters
        bool isNumPad = keyValue >= 0x60 && keyValue <= 0x69; // numpad ok?
        if (isDigit || isLetter || isNumPad || e.Key == Key.Back || e.Key == Key.Space) {
            isQueryableInput = true;
        }
    }
    void onBoxKeyUp(object sender, KeyEventArgs e) {
        if (e.Key == Key.Escape) {
            popup.IsOpen = false;
            return;
        }
        if (isQueryableInput) {
            source.Refresh();
            popup.PlacementRectangle = input.GetRectFromCharacterIndex(input.CaretIndex);
            popup.IsOpen = source.IsEmpty ? false : true;
            isQueryableInput = false;
            return;
        }
        if (e.Key != Key.Down) return;
        if (popup.IsOpen) {
            /*if (list.SelectedIndex == -1)*/
            list.SelectedIndex = 0;
            Keyboard.Focus((ListBoxItem)list.ItemContainerGenerator.ContainerFromItem(list.SelectedItem));
        }
    }
    void setTextOnClick(object sender, MouseButtonEventArgs e) {
        setText();
        input.CaretIndex = input.Text.Length;
        popup.IsOpen = false;
        Keyboard.Focus(this);
    }
    void setTextOnEnter(object sender, KeyEventArgs e) {
        if (e.Key == Key.Escape) {
            popup.IsOpen = false;
            return;
        }
        if (e.Key == Key.Tab || e.Key == Key.Enter) {
            setText();
            input.CaretIndex = input.Text.Length;
            popup.IsOpen = false;
            input.Focus();
            input.MoveFocus(new TraversalRequest(FocusNavigationDirection.Next));
        }

    }
    void setText() {
        if (list.SelectedItem is not null) {
            input.Text = ((IHaveName)list.SelectedItem).Name;
        }
        if (IsRequired) {
            invalidIcon.Visibility = Visibility.Hidden;
            validIcon.Visibility = Visibility.Visible;
        }

        list.SelectedIndex = -1;
    }
    void focusInputBox() {
        if (isFocusingInput) return;
        Dispatcher.InvokeAsync(() => {
            isFocusingInput = true;
            input.Focus();
            input.CaretIndex = input.Text.Length;
            isFocusingInput = false;
        }, DispatcherPriority.Background);
        brushAnim.To = highlightColor;
        brush.BeginAnimation(SolidColorBrush.ColorProperty, brushAnim);
    }

    #region Overrides
    protected override void OnMouseEnter(MouseEventArgs e) {
        if (!string.IsNullOrWhiteSpace(Text)) return;
        if (!isHintMoved) moveHintUp();
        if (!input.IsFocused) focusInputBox();
    }
    protected override void OnPreviewGotKeyboardFocus(KeyboardFocusChangedEventArgs e) {
        if (!isHintMoved) moveHintUp();
        if (!input.IsFocused) focusInputBox();
    }
    protected override void OnPreviewLostKeyboardFocus(KeyboardFocusChangedEventArgs e) {
        if (popup.IsOpen) return;
        bool isBlank = string.IsNullOrWhiteSpace(input.Text);
        if (isBlank && isHintMoved) moveHintDown();
        brushAnim.To = normalColor;
        brush.BeginAnimation(SolidColorBrush.ColorProperty, brushAnim);
        LostFocusAction?.Invoke();
    }
    #endregion

    #region DependencyProperties
    public static readonly DependencyProperty SourceProperty;
    public static readonly DependencyProperty TextProperty;
    
    static SuggestBox() {
        SourceProperty = DependencyProperty.Register("Source", typeof(IEnumerable<IHaveName>), typeof(SuggestBox),
            new PropertyMetadata() {
                DefaultValue = null,
                PropertyChangedCallback = onSourceChanged
            });
        TextProperty = DependencyProperty.Register("Text", typeof(string), typeof(SuggestBox), new FrameworkPropertyMetadata() {
            DefaultValue = null,
            BindsTwoWayByDefault = true,
            PropertyChangedCallback = (d, e) => {
                var o = (SuggestBox)d;
                if (!string.IsNullOrWhiteSpace(o.Text)) {
                    if (!o.isHintMoved) o.moveHintUp();
                }
                else {
                    if (o.input.IsFocused) return;
                    if (o.isHintMoved) o.moveHintDown();
                }
            }
        });
    }

    static void onSourceChanged(DependencyObject d, DependencyPropertyChangedEventArgs e) {
        var o = (SuggestBox)d;
        //if (e.OldValue is not null) { }
        o.source = new CollectionViewSource() { Source = e.NewValue }.View; //CollectionViewSource.GetDefaultView(e.NewValue);
        o.source.Filter = o.filter;
        o.list.ItemsSource = o.source;
    }

    public IEnumerable<IHaveName> Source {
        get { return (IEnumerable<IHaveName>)GetValue(SourceProperty); }
        set { SetValue(SourceProperty, value); }
    }
    public string Text {
        get { return (string)GetValue(TextProperty); }
        set { SetValue(TextProperty, value); }
    }
    #endregion
}