﻿class LedgerPage
{
    double margin, remainingHeight;
    StackPanel header;
    Grid content;
    Border footer, columnNames, pageTotal;
    TextBlock title, period, totalReceipt, totalPayment, footNoteBlock;
    ItemsControl entries;
    ContentControl heightControl;
    Run currentPage, totalPage;

    public FixedPage Page { get; set; }
    public Size PageSize { get; set; }
    public int PageNo { get; set; }
    public string Title { get; set; }
    public string Period { get; set; }
    public int TotalReceipt { get; set; }
    public int TotalPayment { get; set; }
    public ReportEntry LastEntry { get; set; }
    string footNote;
    public string FootNote {
        get { return footNote; }
        set { footNote = value; footNoteBlock.Text = value; measure(); }
    }
    bool isComplete;
    public bool IsComplete {
        get { return isComplete; }
        set {
            isComplete = value;
            entries.UpdateLayout();
            addPageTotals();
        }
    }
    int numberOfPage;
    public int NumberOfPage {
        get { return numberOfPage; }
        set { numberOfPage = value; totalPage.Text = value.ToString(); }
    }

    public LedgerPage(Size pageSize) {
        margin = 96d * 0.7;
        initializeHeader();
        initializeContent();
        initializeFooter();
        PageSize = pageSize;
        PageNo = 1;
        Page = new FixedPage() {
            Width = PageSize.Width,
            Height = PageSize.Height,
            Margin = new Thickness(margin),
            Children = { header, content, footer }
        };
    }
    public LedgerPage(LedgerPage previousPage) : this(previousPage.PageSize) {
        Title = previousPage.Title;
        Period = previousPage.Period;
        PageNo = previousPage.PageNo + 1;
        FootNote = previousPage.FootNote;
        AddEntry(new ReportEntry() {
            Date = previousPage.LastEntry.Date,
            Particulars = "balance b/d",
            ReceivablePayment = previousPage.TotalReceipt,
            PayableReceipt = previousPage.TotalPayment
        });
    }

    void initializeHeader() {
        title = new TextBlock() { FontSize = 16, TextAlignment = TextAlignment.Center };
        period = new TextBlock() { FontSize = 12, TextAlignment = TextAlignment.Center };

        var colDate = new TextBlock() { Text = "Date", HorizontalAlignment = HorizontalAlignment.Left };
        var colParticulars = new TextBlock() { Text = "Particulars", HorizontalAlignment = HorizontalAlignment.Left };
        var colReceipt = new TextBlock() {
            Inlines = { "Payment/", new LineBreak(), "Receivable" },
            TextAlignment = TextAlignment.Right,
            HorizontalAlignment = HorizontalAlignment.Right
        };
        var colPayment = new TextBlock() {
            Inlines = { "Receipt/", new LineBreak(), "Payable" },
            TextAlignment = TextAlignment.Right,
            HorizontalAlignment = HorizontalAlignment.Right
        };
        var colBalance = new TextBlock() {
            Inlines = { "Net", new LineBreak(), "Payable" },
            TextAlignment = TextAlignment.Right,
            HorizontalAlignment = HorizontalAlignment.Right
        };
        Grid.SetColumn(colParticulars, 1);
        Grid.SetColumn(colReceipt, 2);
        Grid.SetColumn(colPayment, 3);
        Grid.SetColumn(colBalance, 4);
        var columnGrid = new Grid() {
            ColumnDefinitions = {
                new ColumnDefinition(){ Width = new GridLength(70) },
                new ColumnDefinition(),
                new ColumnDefinition(){ Width = new GridLength(70) },
                new ColumnDefinition(){ Width = new GridLength(70) },
                new ColumnDefinition(){ Width = new GridLength(70) }
            },
            Children = { colDate, colParticulars, colReceipt, colPayment, colBalance }
        };
        columnNames = new Border() {
            BorderThickness = new Thickness(0, .5, 0, .5),
            BorderBrush = Brushes.Black,
            Child = columnGrid
        };
        header = new StackPanel() {
            Resources = {
                    {
                        typeof(TextBlock),
                        new Style() {
                            Setters = {
                                new Setter(TextBlock.FontWeightProperty, FontWeights.Bold),
                                new Setter(TextBlock.VerticalAlignmentProperty, VerticalAlignment.Center)
                            }
                        }
                    }
                },
            Children = { title, period, columnNames }
        };
    }
    void initializeContent() {
        entries = new ItemsControl() {
            ItemTemplate = new LedgerTemplate(70, 0),
            Background = null,
            Resources = {
                    {
                        typeof(TextBlock),
                        new Style() {
                            Setters = {
                                new Setter(TextBlock.ForegroundProperty, Brushes.Black)
                            }
                        }
                    }
                },
        };
        var totalText = new TextBlock() { Text = "Total", FontWeight = FontWeights.Bold };
        totalReceipt = new TextBlock() {
            FontWeight = FontWeights.Bold,
            HorizontalAlignment = HorizontalAlignment.Right
        };
        totalPayment = new TextBlock() {
            FontWeight = FontWeights.Bold,
            HorizontalAlignment = HorizontalAlignment.Right
        };
        Grid.SetColumn(totalReceipt, 1);
        Grid.SetColumn(totalPayment, 2);
        var totalGrid = new Grid() {
            ColumnDefinitions = {
                    new ColumnDefinition(),
                    new ColumnDefinition(){ Width = new GridLength(70) },
                    new ColumnDefinition(){ Width = new GridLength(70) },
                    new ColumnDefinition(){ Width = new GridLength(70) }
                },
            Children = { totalText, totalReceipt, totalPayment }
        };
        pageTotal = new Border() {
            BorderThickness = new Thickness(0, .5, 0, 0),
            BorderBrush = Brushes.Black,
            Child = totalGrid
        };
        Grid.SetRow(pageTotal, 1);
        content = new Grid() {
            RowDefinitions = {
                    new RowDefinition(){ Height = GridLength.Auto },
                    new RowDefinition(){ Height = GridLength.Auto }
                },
            Children = { entries, pageTotal }
        };
    }
    void initializeFooter() {
        footNoteBlock = new TextBlock();
        currentPage = new Run();
        totalPage = new Run();
        var pageNo = new TextBlock() {
            Inlines = {
                    currentPage,
                    new Run(){Text = "/" },
                    totalPage
                }
        };
        Grid.SetColumn(pageNo, 1);
        var grid = new Grid() {
            ColumnDefinitions = {
                    new ColumnDefinition(),
                    new ColumnDefinition(){ Width = GridLength.Auto }
                },
            Children = { footNoteBlock, pageNo }
        };
        footer = new Border() {
            BorderThickness = new Thickness(0, .5, 0, 0),
            BorderBrush = Brushes.Black,
            Child = grid
        };
    }
    void measure() {
        var availableSize = new Size(PageSize.Width - 2 * margin, PageSize.Height - 2 * margin);
        heightControl = new ContentControl() {
            Width = availableSize.Width,
            ContentTemplate = new LedgerTemplate(70)
        };
        title.Text = Title;
        period.Text = Period;
        currentPage.Text = "Page: " + PageNo;

        double y = 0;
        foreach (FrameworkElement item in Page.Children) {
            item.Width = availableSize.Width;
            item.Measure(availableSize);
            FixedPage.SetTop(item, y);
            y += item.DesiredSize.Height;
        }
        var contentHeight = availableSize.Height - header.DesiredSize.Height - footer.DesiredSize.Height;
        content.Height = contentHeight;
        remainingHeight = contentHeight - pageTotal.DesiredSize.Height;
        FixedPage.SetTop(footer, header.DesiredSize.Height + contentHeight);
    }
    public bool AddEntry(ReportEntry entry) {
        heightControl.Content = entry;
        heightControl.Measure(PageSize);
        heightControl.UpdateLayout();
        remainingHeight -= heightControl.DesiredSize.Height;
        if (remainingHeight < 0) return false;

        entries.Items.Add(entry);
        TotalReceipt += entry.ReceivablePayment;
        TotalPayment += entry.PayableReceipt;
        return true;
    }
    void addPageTotals() {
        totalReceipt.Text = TotalReceipt.ToString(Constants.NumberFormat);
        totalPayment.Text = TotalPayment.ToString(Constants.NumberFormat);
    }
}
