﻿class ListEntryTemplate : DataTemplate
{
    public ListEntryTemplate(Binding command) {
        var grid = new FrameworkElementFactory(typeof(Grid));
        var col1 = new FrameworkElementFactory(typeof(ColumnDefinition));
        var col2 = new FrameworkElementFactory(typeof(ColumnDefinition));
        var col3 = new FrameworkElementFactory(typeof(ColumnDefinition));
        var col4 = new FrameworkElementFactory(typeof(ColumnDefinition));
        var col5 = new FrameworkElementFactory(typeof(ColumnDefinition));
        var col6 = new FrameworkElementFactory(typeof(ColumnDefinition));
        var col7 = new FrameworkElementFactory(typeof(ColumnDefinition));
        var col8 = new FrameworkElementFactory(typeof(ColumnDefinition));
        var col9 = new FrameworkElementFactory(typeof(ColumnDefinition));

        var isConstruction = new FrameworkElementFactory(typeof(PathIcon)) { Name = "isConstruction" };
        var isCash = new FrameworkElementFactory(typeof(PathIcon)) { Name = "isCash" };
        var dateBlock = new FrameworkElementFactory(typeof(TextBlock));
        var partyBlock = new FrameworkElementFactory(typeof(TextBlock));
        var headBlock = new FrameworkElementFactory(typeof(TextBlock));
        var quantityBlock = new FrameworkElementFactory(typeof(TextBlock)) { Name = "qty" };
        var unitBlock = new FrameworkElementFactory(typeof(TextBlock));
        var amountBlock = new FrameworkElementFactory(typeof(TextBlock));
        var button = new FrameworkElementFactory(typeof(DependencyButton<EntryInsert>));

        col1.SetValue(ColumnDefinition.WidthProperty, GridLength.Auto);
        col2.SetValue(ColumnDefinition.WidthProperty, new GridLength(Constants.DateColumnWidth));
        col4.SetValue(ColumnDefinition.SharedSizeGroupProperty, "col5");
        col5.SetValue(ColumnDefinition.SharedSizeGroupProperty, "col6");
        col6.SetValue(ColumnDefinition.SharedSizeGroupProperty, "col7");
        col7.SetValue(ColumnDefinition.WidthProperty, new GridLength(Constants.AmountColumnWidth));
        col8.SetValue(ColumnDefinition.WidthProperty, GridLength.Auto);
        col9.SetValue(ColumnDefinition.WidthProperty, GridLength.Auto);

        dateBlock.SetValue(Grid.ColumnProperty, 1);
        partyBlock.SetValue(Grid.ColumnProperty, 2);
        headBlock.SetValue(Grid.ColumnProperty, 3);
        quantityBlock.SetValue(Grid.ColumnProperty, 4);
        unitBlock.SetValue(Grid.ColumnProperty, 5);
        amountBlock.SetValue(Grid.ColumnProperty, 6);
        isCash.SetValue(Grid.ColumnProperty, 7);
        button.SetValue(Grid.ColumnProperty, 8);

        isConstruction.SetValue(PathIcon.MarginProperty, new Thickness(5, 0, 5, 0));
        isCash.SetValue(PathIcon.MarginProperty, new Thickness(5, 0, 5, 0));
        headBlock.SetValue(TextBlock.MarginProperty, new Thickness(10, 0, 10, 0));
        quantityBlock.SetValue(TextBlock.MarginProperty, new Thickness(5, 0, 0, 0));
        unitBlock.SetValue(TextBlock.MarginProperty, new Thickness(5, 0, 0, 0));

        isConstruction.SetValue(PathIcon.VisibilityProperty, Visibility.Hidden);
        quantityBlock.SetValue(TextBlock.HorizontalAlignmentProperty, HorizontalAlignment.Right);
        amountBlock.SetValue(TextBlock.HorizontalAlignmentProperty, HorizontalAlignment.Right);

        headBlock.SetValue(TextBlock.VerticalAlignmentProperty, VerticalAlignment.Center);
        quantityBlock.SetValue(TextBlock.VerticalAlignmentProperty, VerticalAlignment.Center);
        unitBlock.SetValue(TextBlock.VerticalAlignmentProperty, VerticalAlignment.Center);
        amountBlock.SetValue(TextBlock.VerticalAlignmentProperty, VerticalAlignment.Center);

        partyBlock.SetValue(TextBlock.TextWrappingProperty, TextWrapping.Wrap);
        //won't wrap because of SharedSizeGroupProperty even if you set MaxWidth on that column
        headBlock.SetValue(TextBlock.TextWrappingProperty, TextWrapping.Wrap);

        dateBlock.SetBinding(TextBlock.TextProperty, new Binding(nameof(EntryInsert.Date)) { StringFormat = "dd MMM yyyy" });
        partyBlock.SetBinding(TextBlock.TextProperty, new Binding(nameof(EntryInsert.PartyId)) { Converter = new PartyIdToNameConverter() });
        headBlock.SetBinding(TextBlock.TextProperty, new MultiBinding() {
            Bindings = {
                new Binding(nameof(EntryInsert.HeadId)),
                new Binding(nameof(EntryInsert.SubHeadId))
            },
            Converter = new HeadSubheadToTextConverter()
        });
        quantityBlock.SetBinding(TextBlock.TextProperty, new Binding(nameof(EntryInsert.Quantity)));
        unitBlock.SetBinding(TextBlock.TextProperty, new Binding(nameof(EntryInsert.UnitId)) { Converter = new UnitIdToNameConverter() });
        amountBlock.SetBinding(TextBlock.TextProperty, new Binding(nameof(EntryInsert.Amount)) { StringFormat = "N0" });

        button.SetValue(DependencyButton<EntryInsert>.WidthProperty, 12d);
        button.SetValue(DependencyButton<EntryInsert>.HeightProperty, 12d);
        button.SetValue(DependencyButton<EntryInsert>.MarginProperty, new Thickness(0, 2, 0, 2));
        button.SetValue(DependencyButton<EntryInsert>.IconProperty, Icons.Minus);
        button.SetBinding(DependencyButton<EntryInsert>.CommandProperty, command);
        button.SetBinding(DependencyButton<EntryInsert>.ParameterProperty, new Binding("."));

        isCash.SetBinding(PathIcon.IconProperty, new Binding(nameof(EntryInsert.IsCash)) { Converter = Converters.isCash2Icon });
        isCash.SetBinding(PathIcon.FillProperty, new Binding(nameof(EntryInsert.IsCash)) { Converter = Converters.isCash2Fill });
        isConstruction.SetBinding(PathIcon.IconProperty, new Binding(nameof(EntryInsert.IsConstruction)) { Converter = Converters.isContruction2Icon });

        grid.AppendChild(col1);
        grid.AppendChild(col2);
        grid.AppendChild(col3);
        grid.AppendChild(col4);
        grid.AppendChild(col5);
        grid.AppendChild(col6);
        grid.AppendChild(col7);
        grid.AppendChild(col8);
        grid.AppendChild(col9);
        grid.AppendChild(isConstruction);
        grid.AppendChild(dateBlock);
        grid.AppendChild(partyBlock);
        grid.AppendChild(headBlock);
        grid.AppendChild(quantityBlock);
        grid.AppendChild(unitBlock);
        grid.AppendChild(amountBlock);
        grid.AppendChild(isCash);
        grid.AppendChild(button);

        VisualTree = grid;

        Triggers.Add(new DataTrigger() {
            Binding = new Binding(nameof(EntryInsert.Quantity)),
            Value = 0d,
            Setters = {
                new Setter(TextBlock.TextProperty, "", "qty")
            }
        });
        Triggers.Add(new DataTrigger() {
            Binding = new Binding(nameof(EntryInsert.IsTopLevel)),
            Value = true,
            Setters = {
                new Setter(PathIcon.VisibilityProperty, Visibility.Visible, "isConstruction"),
                new Setter(PathIcon.VisibilityProperty, Visibility.Hidden, "isCash")
            }
        });
    }
}
