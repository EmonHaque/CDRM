﻿class SiteIdToNameConverter : IValueConverter
{
    public object Convert(object value, Type targetType, object parameter, CultureInfo culture) {
        int id = (int)value;
        //if (id == 0) return "";
        switch (id) {
            case int.MaxValue: return "Payment";
            case int.MaxValue - 1: return "Receipt";
            default: return AppData.sites.First(x => x.Id == id).Name;
        }

    }

    public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture) {
        throw new NotImplementedException();
    }
}
